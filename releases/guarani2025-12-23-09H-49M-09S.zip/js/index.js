/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/autofill/autofill.ts":
/*!**********************************!*\
  !*** ./src/autofill/autofill.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillCursada: () => (/* binding */ AutofillCursada),
/* harmony export */   AutofillFinal: () => (/* binding */ AutofillFinal),
/* harmony export */   BaseAutofill: () => (/* binding */ BaseAutofill)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
/* harmony import */ var _guarani_StudentCursada__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../guarani/StudentCursada */ "./src/guarani/StudentCursada.ts");
/* harmony import */ var _guarani_StudentFinal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../guarani/StudentFinal */ "./src/guarani/StudentFinal.ts");



function dniMatcher(student, data) {
    const matches = data.rows.filter((s) => s.get("dni") == student.dni);
    if (matches.length === 1) {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(matches[0]);
    }
    else {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(matches);
    }
}
class BaseAutofill {
    constructor(parser, subjectName) {
        this.parser = parser;
        this.subjectName = subjectName;
    }
    parse(csv) {
        const result = this.parser.parse(csv);
        return result;
    }
    autofill(rowsElement, autofillData, overwrite, matcher = dniMatcher) {
        const students = this.getStudents(rowsElement);
        const unmatched = [];
        for (let student of students) {
            const studentFormEmpty = student.isEmpty;
            if (!overwrite && !studentFormEmpty) {
                student.markAlreadyFilledStudent();
                continue;
            }
            const studentDataResult = matcher(student, autofillData);
            studentDataResult.doRight((studentData) => {
                this.autofillStudent(student, studentData);
                if (studentFormEmpty) {
                    student.markFilledStudent();
                }
                else {
                    student.markOverwrittenStudent();
                }
            });
            studentDataResult.doLeft((matches) => {
                if (studentFormEmpty) {
                    student.markUnmatchedStudent(matches);
                    unmatched.push(student.dni);
                }
                else {
                    student.markAlreadyFilledStudent();
                }
            });
        }
        return unmatched;
    }
    autofillStudent(student, studentData) {
        this.parser.config.dataColumns.forEach((column) => {
            if (studentData.has(column)) {
                const autofillValue = this.convertValues(studentData.get(column), column);
                const element = student.getFillableFieldElement(column);
                element.value = autofillValue;
                var event = new Event("change");
                element.dispatchEvent(event);
            }
        });
    }
    convertValues(value, column) {
        // TODO test alternative
        if (column in this.parser.config.values) {
            return this.parser.config.values[column][value];
        }
        else {
            return value;
        }
    }
}
class AutofillCursada extends BaseAutofill {
    constructor() {
        super(...arguments);
        this.operationType = "cursada";
    }
    getStudents(rowsElement) {
        return Array.from(rowsElement.map(r => new _guarani_StudentCursada__WEBPACK_IMPORTED_MODULE_1__.StudentCursada(r)));
    }
}
class AutofillFinal extends BaseAutofill {
    constructor() {
        super(...arguments);
        this.operationType = "final";
    }
    getStudents(rowsElement) {
        return Array.from(rowsElement.map(r => new _guarani_StudentFinal__WEBPACK_IMPORTED_MODULE_2__.StudentFinal(r)));
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_config_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_config_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillConfigUI: () => (/* binding */ AutofillConfigUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _autofill_overwrite_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./autofill_overwrite_ui */ "./src/autofill_ui/autofill_overwrite_ui.ts");
/* harmony import */ var _autofill_result_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./autofill_result_ui */ "./src/autofill_ui/autofill_result_ui.ts");
/* harmony import */ var _autofill_input_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./autofill_input_ui */ "./src/autofill_ui/autofill_input_ui.ts");




class AutofillConfigUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(autofill, onParseCallback, settings) {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<div id="autofillConfig" ></div>`);
        const inputCSV = settings.getAutofillData(autofill.operationType, autofill.subjectName);
        const autofillResultUI = new _autofill_result_ui__WEBPACK_IMPORTED_MODULE_2__.AutofillResultUI(5);
        const inputUpdate = (inputCSV) => {
            settings.setAutofillData(autofill.operationType, autofill.subjectName, inputCSV);
            settings.save();
            this.data = autofill.parse(inputCSV);
            autofillResultUI.update(this.data);
            onParseCallback(this.data);
        };
        const inputUI = new _autofill_input_ui__WEBPACK_IMPORTED_MODULE_3__.AutofillInputUI(inputCSV, inputUpdate, autofill.parser.config.keyColumns, autofill.parser.config.dataColumns);
        const autofillOverwriteConfigUI = new _autofill_overwrite_ui__WEBPACK_IMPORTED_MODULE_1__.AutofillOverwriteConfigUI(settings);
        (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.appendChildren)(this.root, [autofillOverwriteConfigUI.root, inputUI.root, autofillResultUI.root]);
        inputUpdate(inputCSV);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_input_ui.ts":
/*!**********************************************!*\
  !*** ./src/autofill_ui/autofill_input_ui.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillInputUI: () => (/* binding */ AutofillInputUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class AutofillInputUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(inputCSV, changeCallback, keyColumns, dataColumns) {
        super();
        this.root = document.createElement("div");
        this.root.id = "autofillInputUI";
        const labelTitle = `El formato de entrada es de un CSV, con campos separados por el carácter ';'.\nSe requiere como mínimo una columna de identificación y una columna de datos:\n
      Columnas de identificación: ${keyColumns}.
      Columnas de datos: ${dataColumns}.
      `;
        const label = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<label for="autofillInput" style="display:block" title="${labelTitle}">Carga de CSV para autollenado 🛈:</label>`);
        const autofillDataInput = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`
        <textarea type="text" name="autofill" 
        id="autofillInput">${inputCSV}</textarea>`);
        this.root.appendChild(label);
        this.root.appendChild(autofillDataInput);
        autofillDataInput.onchange = e => changeCallback(autofillDataInput.value);
        autofillDataInput.addEventListener('input', e => changeCallback(autofillDataInput.value));
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_overwrite_ui.ts":
/*!**************************************************!*\
  !*** ./src/autofill_ui/autofill_overwrite_ui.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillOverwriteConfigUI: () => (/* binding */ AutofillOverwriteConfigUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class AutofillOverwriteConfigUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(settings) {
        super();
        this.settings = settings;
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<div id="autofillOverwrite"></div>`);
        const labelTitle = "Sobreescribir valores (notas, condición, fecha, etc) existentes al rellenar.";
        const label = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<label title="${labelTitle}" style="display:inline;">Sobreescribir valores: </label>`);
        const checkbox = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<input type="checkbox" id="autofillOverwriteCheckbox"/>`);
        checkbox.checked = this.settings.overwriteOnAutofill;
        checkbox.onchange = (e) => {
            this.settings.overwriteOnAutofill = checkbox.checked;
            this.settings.save();
        };
        this.root.appendChild(label);
        this.root.appendChild(checkbox);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_result_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_result_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillResultUI: () => (/* binding */ AutofillResultUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");


function rowToString(row, index) {
    const data = Array.from((0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.mapMap)(row, (k, v) => [k, `${k}=${v}`]).values()).join(", ");
    return `${index}: ${data}`;
}
function autofillDataToString(rows) {
    let asStr = rows.map((v, i, a) => rowToString(v, i));
    return asStr.join("\n");
}
class AutofillResultUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(maxRows = 5) {
        super();
        this.maxRows = maxRows;
        this.root = document.createElement("div");
        this.result = document.createElement("textarea");
        this.status = document.createElement("span");
        const autofillDataViewerLabel = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<p style="display:block">Resultado de la carga: </p>`);
        autofillDataViewerLabel.appendChild(this.status);
        this.result.id = "autofillResult";
        this.result.disabled = true;
        this.root.appendChild(autofillDataViewerLabel);
        this.root.appendChild(this.result);
    }
    update(result) {
        result.doLeft(error => {
            this.result.value = error;
            this.status.innerText = "❌";
        });
        result.doRight(csv => {
            const shortRows = csv.rows.slice(0, Math.min(this.maxRows, csv.rows.length));
            this.result.value = `${autofillDataToString(shortRows)}`;
            this.status.innerText = `✅ (Filas: ${csv.rows.length}, Columnas: ${csv.header.length})`;
        });
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_status_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_status_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillStatsUI: () => (/* binding */ AutofillStatsUI),
/* harmony export */   ColumnStatusUI: () => (/* binding */ ColumnStatusUI),
/* harmony export */   CounterUI: () => (/* binding */ CounterUI),
/* harmony export */   ProgressUI: () => (/* binding */ ProgressUI),
/* harmony export */   StudentChangeUI: () => (/* binding */ StudentChangeUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class CounterUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor() {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span class="counterUI">  </span>`);
        this.count = document.createElement("span");
        this.icon = document.createElement("span");
        this.icon.innerHTML = " ●";
        this.root.appendChild(this.count);
        this.root.appendChild(this.icon);
    }
    update(count, total) {
        this.count.innerHTML = `${count}/${total}`;
        const rate = count / total;
        const hue = (rate * 120).toString(10);
        this.icon.style.color = `hsl(${hue},70%,35%)`;
    }
}
class ProgressUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(id, label, title) {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span id="statsUIComplete" class="progressUI" >  </span>`);
        this.root.title = title;
        this.root.id = id;
        const labelElement = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span> ${label} </span>`);
        this.count = new CounterUI();
        this.root.appendChild(labelElement);
        this.root.appendChild(this.count.root);
    }
    update(count, total) {
        this.count.update(count, total);
    }
}
class StudentChangeUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(rows_element, autofill) {
        super();
        this.rows_element = rows_element;
        this.autofill = autofill;
        rows_element.forEach((e) => {
            const inputs = e.querySelectorAll("input, select");
            inputs.forEach((i) => {
                i.addEventListener("change", () => {
                    this.onStudentChange();
                }, true);
                i.addEventListener("keyup", () => {
                    this.onStudentChange();
                }, true);
            });
        });
    }
    getStudents() {
        return this.autofill.getStudents(this.rows_element);
    }
}
class AutofillStatsUI extends StudentChangeUI {
    constructor(rows_element, autofill) {
        super(rows_element, autofill);
        this.root = document.createElement("span");
        this.fieldCounters = new Map();
        this.root.id = "statsUI";
        this.countComplete = new ProgressUI("statsUIComplete", "Completo", "Estudiantes con información completa (no considera el campo observaciones)");
        this.countNonEmpty = new ProgressUI("statsUINonEmpty", "Con datos", "Estudiantes con información algún dato completado, pero no todos (no considera el campo observaciones)");
        this.root.appendChild(this.countNonEmpty.root);
        this.root.appendChild(this.countComplete.root);
        // force update the first time
        this.onStudentChange();
    }
    onStudentChange() {
        const students = this.autofill.getStudents(this.rows_element);
        const total = students.length;
        const nonEmpty = students.filter((s) => !(s.isEmpty)).length;
        const complete = students.filter((s) => s.isFull).length;
        this.countNonEmpty.update(nonEmpty, total);
        this.countComplete.update(complete, total);
    }
}
class ColumnStatusUI extends StudentChangeUI {
    constructor(rows_element, autofill, field, header) {
        super(rows_element, autofill);
        this.field = field;
        this.header = header;
        // create CounterUI objects for each field/column
        // const headerElements = Array.from(
        //   document
        //     .getElementById("renglones")
        //     .querySelector("thead")
        //     .querySelectorAll("th")
        // );
        // const fieldToIndex = { fecha: 3, nota: 4, resultado: 5, condicion: 6 };
        // const header = headerElements[fieldToIndex[f]]
        // this.fieldCounters.set(f, counterUI);
        this.counterUI = new CounterUI();
        const container = document.createElement("div");
        header.appendChild(container);
        container.appendChild(this.counterUI.root);
        this.onStudentChange();
    }
    onStudentChange() {
        const students = this.getStudents();
        const count = students.map((s) => {
            return s.getFillableField(this.field) !== "" ? 1 : 0;
        }).reduce((a, b) => a + b, 0);
        // console.log(students)
        this.counterUI.update(count, students.length);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_ui.ts":
/*!****************************************!*\
  !*** ./src/autofill_ui/autofill_ui.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillUI: () => (/* binding */ AutofillUI),
/* harmony export */   addAutofillUI: () => (/* binding */ addAutofillUI)
/* harmony export */ });
/* harmony import */ var _autofill_config_ui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./autofill_config_ui */ "./src/autofill_ui/autofill_config_ui.ts");
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _autofill_status_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./autofill_status_ui */ "./src/autofill_ui/autofill_status_ui.ts");



function shortenToolButtonsNames() {
    const autocomplete = document.getElementById("js-colapsar-autocompletar");
    if (autocomplete) {
        autocomplete.children[1].innerHTML = "Autocompletar básico";
    }
    const scale = document.getElementById("ver_escala_regularidad");
    if (scale) {
        scale.innerHTML = "Glosario";
    }
}
class AutofillUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.UI {
    constructor(rowsElement, autofill, settings) {
        super();
        this.rowsElement = rowsElement;
        this.autofill = autofill;
        // Create a bar above main form
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillBar"> </div>`);
        // add a container with the autofill config, a toggle button to open/close it, and an autofill button to operate it
        const toggleButton = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<button id="autofillAdvanced" class="btn btn-small" href="#" title="Cargar los datos en formato csv para la materia actual desde donde se obtienen los datos para rellenar."><i   class="icon-wrench"></i> Configurar autocompletado </button>`);
        const autofillStartButton = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<button type='button' class="btn btn-small" title="Autocompletar el formulario en base a los datos en formato csv cargados en la configuración"> 📝 Autocompletar </button>`);
        autofillStartButton.onclick = () => {
            autofillConfigUI.data.doRight((csv) => {
                const unmatched = this.autofill.autofill(rowsElement, csv, settings.overwriteOnAutofill);
                var save_button = document.getElementById("js-btn-guardar");
                save_button.disabled = false;
                console.log("enabling save button");
                // const allUnmatched = getSettings(SettingsKeys.Unmatched) as Array<object>;
                // const newUnmatched = new Set(allUnmatched.concat(unmatched));
                // setSettings(SettingsKeys.Unmatched, Array.from(newUnmatched));
            });
        };
        const config = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillConfigContainer" style="display:none;"> </div>`);
        const controls = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillControlsContainer"> </div>`);
        toggleButton.onclick = () => {
            (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.toggleElement)(config, "block");
        };
        const statsUI = new _autofill_status_ui__WEBPACK_IMPORTED_MODULE_2__.AutofillStatsUI(rowsElement, autofill);
        controls.appendChild(statsUI.root);
        controls.appendChild(toggleButton);
        controls.appendChild(autofillStartButton);
        this.root.appendChild(controls);
        this.root.appendChild(config);
        const autofillConfigUI = new _autofill_config_ui__WEBPACK_IMPORTED_MODULE_0__.AutofillConfigUI(autofill, result => {
            result.doLeft(error => {
                autofillStartButton.disabled = true;
            });
            result.doRight(csv => {
                autofillStartButton.disabled = false;
            });
        }, settings);
        config.appendChild(autofillConfigUI.root);
    }
}
function addAutofillUI(rows, settings, autofill) {
    const autofillUI = new AutofillUI(rows, autofill, settings);
    const renglones = document.getElementById("renglones");
    renglones.parentElement.insertBefore(autofillUI.root, renglones);
    shortenToolButtonsNames();
}


/***/ }),

/***/ "./src/form_renglones.ts":
/*!*******************************!*\
  !*** ./src/form_renglones.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   when_form_renglones_ready: () => (/* binding */ when_form_renglones_ready),
/* harmony export */   when_renglones_changes: () => (/* binding */ when_renglones_changes)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");

const form_renglones_selector = ".form-renglones";
function failed_callback(timeout) {
    console.log(`GUARANI-CHROME: after waiting for ${timeout}, assuming there's no form in page.`);
}
function when_form_renglones_ready(callback, timeout = 5000, additional_wait = 10) {
    const formCallback = () => {
        const form_renglones = document.querySelector(form_renglones_selector);
        callback(form_renglones);
    };
    const failCallback = () => { failed_callback(timeout); };
    const waitCallback = () => { setTimeout(formCallback, additional_wait); };
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.waitForElement)(form_renglones_selector, waitCallback, timeout, undefined, failCallback);
}
// function when_form_renglones_ready_old(listeners){
//     const columna = document.querySelector("#columna_1");
//       if (!columna) {
//         console.log("#Columna_1 not found; not a students form.")
//         return  
//     }
//     console.log("Registering to add save button")
//     console.log(columna)
//     observe(columna,when_columna_changes,{childList:true,subtree:true },disableAfterFirst=false,params=listeners)
//   }
// function when_columna_changes(observer,listeners){
//   const renglones = document.querySelector("#renglones");
//   if (renglones) {
//     console.log("renglones found; adding mutation observer")
//     console.log(renglones)
//     observer.disconnect()
//     observe(renglones,when_renglones_changes,{ subtree: true,childList:true },true,listeners)        
//   }
// }
function when_renglones_changes(observer, listeners) {
    const form_renglones = document.querySelector(".form-renglones");
    if (form_renglones) {
        console.log("GUARANI-CHROME: Form renglones found; adding button");
        observer.disconnect();
        listeners.forEach(listener => listener(form_renglones));
    }
    else {
        console.log("GUARANI-CHROME: Form renglones not found");
        // console.log(document.querySelector("#renglones"))        
    }
}


/***/ }),

/***/ "./src/guarani/Student.ts":
/*!********************************!*\
  !*** ./src/guarani/Student.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Student: () => (/* binding */ Student)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class Student {
    getFillableFieldElement(name) {
        const i = this.fillableFieldsNames.indexOf(name);
        return this.fillableFieldsElements[i];
    }
    getFillableField(name) {
        const i = this.fillableFieldsNames.indexOf(name);
        return this.fillableFields[i];
    }
    constructor(row) {
        this.row = row;
        this.addResultEmojiElement();
    }
    addResultEmojiElement() {
        if (this.emojiElement) {
            // don't create element if it already exists
            return;
        }
        const alumnoDiv = this.row.querySelector(".ficha-alumno").children[1];
        const emojiElement = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span class="${Student.EmojiClass}"> <span>`);
        alumnoDiv.appendChild(emojiElement);
    }
    get emojiElement() {
        return this.row.querySelector(Student.EmojiSelector);
    }
    get dniElement() {
        return this.row.querySelector(Student.elementSelectors.dni);
    }
    get dni() { return this.dniElement.innerText.split(" ")[1]; }
    get nombreElement() {
        return this.row.querySelector(Student.elementSelectors.nombre);
    }
    get nombre() {
        return this.nombreElement.innerText;
    }
    get fechaElement() {
        return this.row.querySelector(Student.elementSelectors.fecha);
    }
    get fecha() {
        return this.fechaElement.value;
    }
    set fecha(v) {
        this.fechaElement.value = v;
    }
    get nota() {
        const v = this.notaElement.value;
        // nota uses - as no value
        return (v === "-") ? "" : v;
    }
    set nota(v) {
        // nota uses - as no value
        v = (v === "") ? "-" : v;
        this.notaElement.value = v;
    }
    get resultadoElement() {
        return this.row.querySelector(Student.elementSelectors.resultado);
    }
    get resultado() {
        return this.resultadoElement.value;
    }
    set resultado(v) {
        this.resultadoElement.value = v;
    }
    addToStudentTitle(message) {
        function appendToTitle(element, s) {
            element.title = `${element.title}${s}`;
        }
        appendToTitle(this.nombreElement, `\n Autofill: ${message}`);
        appendToTitle(this.dniElement, `\n Autofill: ${message}`);
        appendToTitle(this.emojiElement, `\n Autofill: ${message}`);
    }
    setStudentClass(klass) {
        this.row.classList.remove(...this.row.classList);
        this.row.classList.add(klass);
    }
    markFilledStudent() {
        this.setStudentClass("autofilledStudent");
        this.addEmojiStudent("✅");
        this.addToStudentTitle("ha sido completado automaticamente");
    }
    markOverwrittenStudent() {
        this.setStudentClass("modifiedStudent");
        this.addEmojiStudent("✏️");
        this.addToStudentTitle("ha sido editado automáticamente");
    }
    markUnmatchedStudent(matches) {
        this.setStudentClass("unmatchedStudent");
        this.addEmojiStudent("❌");
        this.addToStudentTitle("no se pudo encontrar en el csv");
    }
    addEmojiStudent(emoji) {
        this.emojiElement.innerText = `${this.emojiElement.innerText}${emoji}`;
    }
    markAlreadyFilledStudent() {
        this.setStudentClass("alreadyFilledStudent");
        this.addEmojiStudent("⚠️");
        this.addToStudentTitle("No se modificó porque ya tenía valores cargados");
    }
    get emptyFields() {
        return this.fillableFields.filter(f => f === "");
    }
    get isFull() {
        return this.emptyFields.length === 0;
    }
    get isEmpty() {
        return this.emptyFields.length == this.fillableFields.length;
    }
}
Student.EmojiClass = "result-emoji";
Student.EmojiSelector = `.${Student.EmojiClass}`;
Student.elementSelectors = {
    dni: ".identificacion",
    nombre: ".nombre",
    fecha: ".fecha",
    resultado: ".resultado",
    condicion: ".condicion",
    observacion: ".observacion",
};


/***/ }),

/***/ "./src/guarani/StudentCursada.ts":
/*!***************************************!*\
  !*** ./src/guarani/StudentCursada.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StudentCursada: () => (/* binding */ StudentCursada)
/* harmony export */ });
/* harmony import */ var _Student__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Student */ "./src/guarani/Student.ts");

class StudentCursada extends _Student__WEBPACK_IMPORTED_MODULE_0__.Student {
    constructor() {
        super(...arguments);
        this.fillableFieldsElements = [this.notaElement, this.fechaElement, this.resultadoElement, this.condicionElement];
    }
    get condicionElement() {
        return this.row.querySelector(StudentCursada.elementSelectors.condicion);
    }
    get condicion() {
        return this.condicionElement.value;
    }
    set condicion(v) {
        this.condicionElement.value = v;
    }
    get observacionElement() {
        return this.row.querySelector(StudentCursada.elementSelectors.observacion);
    }
    get observacion() {
        return this.observacionElement.value;
    }
    set observacion(v) {
        this.observacionElement.value = v;
    }
    asDict() {
        return {
            dni: this.dni,
            nombre: this.nombre,
            fecha: this.fecha,
            nota: this.nota,
            resultado: this.resultado,
            condicion: this.condicion,
            observacion: this.observacion
        };
    }
    get notaElement() {
        return this.row.querySelector(".nota_cursada");
    }
    get fillableFieldsNames() {
        return ["nota", "fecha", "resultado", "condicion"];
    }
    get fillableFields() {
        return [this.nota, this.fecha, this.resultado, this.condicion];
    }
}


/***/ }),

/***/ "./src/guarani/StudentFinal.ts":
/*!*************************************!*\
  !*** ./src/guarani/StudentFinal.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StudentFinal: () => (/* binding */ StudentFinal)
/* harmony export */ });
/* harmony import */ var _Student__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Student */ "./src/guarani/Student.ts");

class StudentFinal extends _Student__WEBPACK_IMPORTED_MODULE_0__.Student {
    constructor() {
        super(...arguments);
        this.fillableFieldsElements = [this.notaElement, this.fechaElement, this.resultadoElement];
    }
    get notaElement() {
        return this.row.querySelector(".nota");
    }
    get fillableFieldsNames() {
        return ["nota", "fecha", "resultado"];
    }
    get fillableFields() {
        return [this.nota, this.fecha, this.resultado];
    }
}


/***/ }),

/***/ "./src/input/CSVCursadaConfig.ts":
/*!***************************************!*\
  !*** ./src/input/CSVCursadaConfig.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSVCursadaConfig: () => (/* binding */ CSVCursadaConfig)
/* harmony export */ });
/* harmony import */ var _parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parser */ "./src/input/parser.ts");

class CSVCursadaConfig extends _parser__WEBPACK_IMPORTED_MODULE_0__.CSVConfig {
    constructor() {
        super(...arguments);
        this.id = "cursada";
        this.dataColumns = ["fecha", "condicion", "nota", "resultado"];
        this.keyColumns = ["dni", "nombre"];
        this.csvSeparator = ";";
        this.values = {
            nota: {
                "U": "U",
                "D": "D",
                "A": "A",
                "-": "",
            },
            resultado: {
                "Ausente": "U",
                "Reprobado": "R",
                "Aprobado": "A",
                "-": "",
            },
            condicion: {
                "Abandono": "2",
                "Aprobado": "175",
                "Desaprobado": "174",
                "Insuficiente": "3",
                "Libre": "1",
                "No Promociono": "107",
                "Promociono": "5",
                "Regular": "4",
                "-": "",
            }
        };
    }
}


/***/ }),

/***/ "./src/input/CSVFinalConfig.ts":
/*!*************************************!*\
  !*** ./src/input/CSVFinalConfig.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSVFinalConfig: () => (/* binding */ CSVFinalConfig)
/* harmony export */ });
/* harmony import */ var _parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parser */ "./src/input/parser.ts");

class CSVFinalConfig extends _parser__WEBPACK_IMPORTED_MODULE_0__.CSVConfig {
    constructor() {
        super(...arguments);
        this.id = "final";
        this.dataColumns = ["fecha", "nota", "resultado"];
        this.keyColumns = ["dni", "nombre"];
        this.csvSeparator = ";";
        this.values = {
            nota: {
                "0": "0",
                "1": "1",
                "2": "2",
                "3": "3",
                "4": "4",
                "5": "5",
                "6": "6",
                "7": "7",
                "8": "8",
                "9": "9",
                "10": "10",
                "-": "",
            },
            resultado: {
                "Ausente": "U",
                "Reprobado": "R",
                "Aprobado": "A",
                "-": "",
            },
        };
    }
}


/***/ }),

/***/ "./src/input/csv.ts":
/*!**************************!*\
  !*** ./src/input/csv.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSV: () => (/* binding */ CSV),
/* harmony export */   CSVParseError: () => (/* binding */ CSVParseError),
/* harmony export */   parseCSV: () => (/* binding */ parseCSV),
/* harmony export */   validateCSV: () => (/* binding */ validateCSV)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");

function validateCSV(input, separator = ";") {
    return input.trim().length > 0;
}
function toEntries(a) {
    return a.map((value, index) => [index, value]);
}
class CSVParseError extends Error {
    constructor(message) {
        super(message);
        this.name = 'CSVParseError';
    }
}
class CSV {
    constructor(rows, header) {
        this.rows = rows;
        this.header = header;
    }
}
function parseCSV(input, separator = ";\t", normalize_header = false) {
    input = input.trim();
    if (input === "") {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(new CSV([], []));
    }
    const lines = input.split(/\r\n|\n/).map(r => r.trim());
    const nonemptyLines = lines.filter(r => r.length > 0);
    const splitLines = nonemptyLines.map((l) => l.split(separator));
    const basicHeader = splitLines.shift();
    const header = normalize_header ? basicHeader.map(h => h.trim().toLowerCase()) : basicHeader;
    const rows = [];
    for (const [i, values] of toEntries(splitLines)) {
        if (header.length != values.length) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`Number of values in row ${i} does not match number of values in header.\nHeader: "${header}"\nRow ${i}: "${values}"`);
        }
        const row = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.dictFromLists)(header, values);
        rows.push(row);
    }
    return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(new CSV(rows, header));
}
// parseCSV("dni;h1\n23;v1\n  \n  \n")


/***/ }),

/***/ "./src/input/parser.ts":
/*!*****************************!*\
  !*** ./src/input/parser.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillParser: () => (/* binding */ AutofillParser),
/* harmony export */   CSVConfig: () => (/* binding */ CSVConfig)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
/* harmony import */ var _csv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./csv */ "./src/input/csv.ts");


class CSVConfig {
}
function checkValues(column, values, rows) {
    const rowsWithNumber = rows.map((v, i, a) => [v, i + 2]);
    const rowsWithWrongValues = rowsWithNumber.filter(([s, i], j) => !values.includes(s.get(column)));
    return rowsWithWrongValues.length === 0
        ? new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.None()
        : new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Some(rowsWithWrongValues);
}
function printRow(rowIndex, separator) {
    const [row, index] = rowIndex;
    return `Fila ${index}: ${Array.from(row.values()).join(separator)}`;
}
function printAutofillData(data, header, separator) {
    let headerRow = header.join(separator);
    let rows = data.map(r => printRow(r, separator)).join("\n");
    return `${headerRow}\n${rows}\n`;
}
class AutofillParser {
    constructor(config) {
        this.config = config;
    }
    parse(data) {
        const parseResult = (0,_csv__WEBPACK_IMPORTED_MODULE_1__.parseCSV)(data, this.config.csvSeparator, true);
        if (parseResult.isLeft()) {
            return parseResult;
        }
        const csv = parseResult.get();
        const keyColumnsPresent = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.intersection)(this.config.keyColumns, csv.header);
        if (keyColumnsPresent.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El CSV no contiene ninguna de las columnas necesarias para identificar estudiantes. \n - Columnas de identificación: ${this.config.keyColumns}. \n - Columnas del csv: ${csv.header}`);
        }
        const dataColumnsPresent = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.intersection)(this.config.dataColumns, csv.header);
        if (dataColumnsPresent.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El CSV no contiene ninguna columna de datos relevante para el llenado. \n - Columnas de datos: ${this.config.dataColumns}.\n - Columnas del csv: ${csv.header}`);
        }
        if (csv.rows.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El csv solo contiene un encabezado, y no contiene datos.\n - Encabezado: ${csv.header}`);
        }
        for (const [key, values] of Object.entries(this.config.values)) {
            if (csv.header.includes(key)) {
                const validValues = Object.keys(values);
                const valueCheck = checkValues(key, validValues, csv.rows);
                if (valueCheck.isSome()) {
                    let rowsWithErrors = valueCheck.get();
                    return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`La columna ${key} contiene valores inválidos. Valores válidos: ${validValues}.\n Filas con valores inválidos:\n${printAutofillData(rowsWithErrors, csv.header, this.config.csvSeparator)}`);
                }
            }
        }
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(csv);
    }
}


/***/ }),

/***/ "./src/save_button.ts":
/*!****************************!*\
  !*** ./src/save_button.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addSaveButton: () => (/* binding */ addSaveButton)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");

//import { when_form_renglones_ready } from "./form_renglones";
function addSaveButton(form_renglones) {
    const basic_save_button = document.querySelector("#js-btn-guardar");
    const save_button = document.createElement("input");
    save_button.type = "submit";
    save_button.value = "Guardar";
    save_button.classList.add("btn", "btn-info", "btn-small", "pull-right");
    save_button.id = "js-btn-guardar";
    save_button.onclick = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    form_renglones.appendChild(save_button);
    const update = function () { save_button.disabled = basic_save_button.disabled; };
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.observe)(basic_save_button, update, { attributes: true, subtree: true, childList: true, }, false);
}
//when_form_renglones_ready(add_save_button)


/***/ }),

/***/ "./src/settings.ts":
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Settings: () => (/* binding */ Settings)
/* harmony export */ });
class Settings {
    static CheckVersion(callback) {
        chrome.storage.local.get(Settings.Keys.Version, settings => {
            const currentVersion = this.defaultSettings[Settings.Keys.Version];
            const settingsVersion = settings[Settings.Keys.Version];
            if (settingsVersion != currentVersion) {
                // if versions don`t match, clear local storage and restart settings to prevent errors
                console.log(`GUARANI-CHROME: New version ${currentVersion} found, deleting settings from ${settingsVersion} `);
                chrome.storage.local.clear();
                chrome.storage.sync.clear();
                chrome.storage.local.set({ [Settings.Keys.Version]: currentVersion });
            }
            callback();
        });
    }
    static RestoreFromStorage(callback) {
        console.log(`GUARANI-CHROME: Initializing settings... `);
        this.CheckVersion(() => {
            // console.log(`Initialized with settings: ${Object.entries(v)}`)
            chrome.storage.local.get(Settings.defaultSettings, values => {
                const s = new Settings(values[Settings.Keys.Theme], values[Settings.Keys.OverwriteOnAutofill], values[Settings.Keys.AutofillDataCSV], values[Settings.Keys.Version]);
                callback(s);
            });
        });
    }
    constructor(theme = "dark", overwriteOnAutofill = true, autofillData, version) {
        this.theme = theme;
        this.overwriteOnAutofill = overwriteOnAutofill;
        this.autofillData = autofillData;
        this.version = version;
    }
    save(callback = () => { }) {
        const s = {
            [Settings.Keys.Theme]: this.theme,
            [Settings.Keys.OverwriteOnAutofill]: this.overwriteOnAutofill,
            [Settings.Keys.AutofillDataCSV]: this.autofillData,
            [Settings.Keys.Version]: this.version
        };
        chrome.storage.local.set(s).then(() => callback());
    }
    getDataID(operation, subject) {
        return `${operation}_${subject}`;
    }
    getAutofillData(operation, subject = "") {
        var _a;
        return (_a = this.autofillData[this.getDataID(operation, subject)]) !== null && _a !== void 0 ? _a : "";
    }
    setAutofillData(operation, subject, data) {
        this.autofillData[this.getDataID(operation, subject)] = data;
    }
}
Settings.Keys = {
    // MissingStudents:"missingStudents",
    Theme: "theme",
    OverwriteOnAutofill: "overwriteOnAutofill",
    AutofillDataCSV: "autofillDataCSV",
    Version: "version"
    // Unmatched:"unmatched"
};
Settings.defaultSettings = {
    [Settings.Keys.Theme]: "dark",
    [Settings.Keys.OverwriteOnAutofill]: false,
    [Settings.Keys.AutofillDataCSV]: {},
    [Settings.Keys.Version]: "2"
    // [Settings2.Keys.Unmatched]:[],
};


/***/ }),

/***/ "./src/themes.ts":
/*!***********************!*\
  !*** ./src/themes.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initializeThemeChooser: () => (/* binding */ initializeThemeChooser)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/utils */ "./src/utils/utils.ts");


function addCSS(href) {
    const trueHref = chrome.runtime.getURL(href);
    var link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', trueHref);
    link.setAttribute('type', "text/css");
    // link.setAttribute('disabled', "disabled");
    document.head.appendChild(link);
    return link;
}
class ThemesUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(themes, settings) {
        super();
        this.themes = themes;
        this.settings = settings;
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<select type="text" name="theme" id="theme">
    <option value="light">Claro 🌕</option>
    <option value="dark">Oscuro 🌑</option>
    </select>`);
        this.root.value = settings.theme;
        this.root.addEventListener('change', (event) => this.updateTheme());
        this.updateTheme();
    }
    updateTheme() {
        const newTheme = this.root.value;
        console.log(`GUARANI-CHROME: Changing theme to "${newTheme}"`);
        this.settings.theme = newTheme;
        this.settings.save();
        //disable all themes
        this.themes.forEach((v, k) => v.disabled = true);
        //enable just this one
        if (this.themes.has(newTheme)) {
            this.themes.get(newTheme).disabled = false;
        }
    }
}
function initializeThemeChooser(settings) {
    console.log(`GUARANI-CHROME: initializing theme chooser`);
    const themeURLs = new Map(Object.entries({ "dark": "themes/dark.css",
        "light": "themes/light.css"
    }));
    const themes = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.mapValues)(themeURLs, addCSS);
    // wait a bit for css files to load before creating ThemesUI
    window.setTimeout(() => {
        const themesUI = new ThemesUI(themes, settings);
        let notifications = document.querySelector(".notificaciones");
        if (notifications) {
            notifications.appendChild(themesUI.root);
        }
        else {
            console.log(`GUARANI-CHROME: Did not find element ".notificaciones" to append the theme chooser`);
        }
    }, 100);
}


/***/ }),

/***/ "./src/utils/dom_utils.ts":
/*!********************************!*\
  !*** ./src/utils/dom_utils.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UI: () => (/* binding */ UI),
/* harmony export */   appendChildren: () => (/* binding */ appendChildren),
/* harmony export */   cleanPropagate: () => (/* binding */ cleanPropagate),
/* harmony export */   fromHTML: () => (/* binding */ fromHTML),
/* harmony export */   observe: () => (/* binding */ observe),
/* harmony export */   propagateOnChange: () => (/* binding */ propagateOnChange),
/* harmony export */   ready: () => (/* binding */ ready),
/* harmony export */   toggleElement: () => (/* binding */ toggleElement),
/* harmony export */   waitForElement: () => (/* binding */ waitForElement)
/* harmony export */ });
class UI {
}
function ready(fn) {
    if (document.readyState !== 'loading') {
        fn();
        return;
    }
    document.addEventListener('DOMContentLoaded', fn);
}
function observe(element, f, config = { subtree: true, childList: true, attributes: true }, disableAfterFirst = true, params = []) {
    const mutationObserver = new MutationObserver(() => {
        if (disableAfterFirst) {
            mutationObserver.disconnect();
        }
        f(mutationObserver, params);
    });
    mutationObserver.observe(element, config);
    return mutationObserver;
}
function toggleElement(el, display = "block") {
    if (el.style.display === "none") {
        el.style.display = display;
    }
    else {
        el.style.display = "none";
    }
}
function fromHTML(html, trim = true) {
    // Process the HTML string.
    html = trim ? html : html.trim();
    if (!html)
        return null;
    // Then set up a new template element.
    const template = document.createElement('template');
    template.innerHTML = html;
    const result = template.content.children;
    // Then return either an HTMLElement or HTMLCollection,
    // based on whether the input HTML had one or more roots.
    if (result.length !== 1)
        throw Error(`fromHTML must create one and only one element (possibly with many children, found ${result})`);
    return result[0];
}
function appendChildren(root, children) {
    children.forEach(child => root.appendChild(child));
}
function waitForElement(selector, callback, checkFrequencyInMs = 10, timeoutInMs = 15000, failure_callback = undefined) {
    var startTimeInMs = Date.now();
    (function loopSearch() {
        const element = document.querySelector(selector);
        if (element) {
            callback(element);
        }
        else {
            setTimeout(function () {
                const elapsed = Date.now() - startTimeInMs;
                if (timeoutInMs && elapsed > timeoutInMs) {
                    if (failure_callback) {
                        failure_callback();
                    }
                }
                else {
                    loopSearch();
                }
            }, checkFrequencyInMs);
        }
    })();
}
function propagateOnChange(element) {
    var event = new Event('change', { bubbles: true });
    element.dispatchEvent(event);
}
function cleanPropagate(e) {
    e.value = "";
    propagateOnChange(e);
}


/***/ }),

/***/ "./src/utils/utils.ts":
/*!****************************!*\
  !*** ./src/utils/utils.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Left: () => (/* binding */ Left),
/* harmony export */   None: () => (/* binding */ None),
/* harmony export */   Optional: () => (/* binding */ Optional),
/* harmony export */   Right: () => (/* binding */ Right),
/* harmony export */   Some: () => (/* binding */ Some),
/* harmony export */   dictFromLists: () => (/* binding */ dictFromLists),
/* harmony export */   intersection: () => (/* binding */ intersection),
/* harmony export */   mapKeys: () => (/* binding */ mapKeys),
/* harmony export */   mapMap: () => (/* binding */ mapMap),
/* harmony export */   mapValues: () => (/* binding */ mapValues),
/* harmony export */   zip: () => (/* binding */ zip)
/* harmony export */ });
const zip = (a, b) => a.map((k, i) => [k, b[i]]);
function intersection(a, b) { return a.filter(value => b.includes(value)); }
function dictFromLists(keys, vals) {
    const dict = new Map();
    zip(keys, vals).forEach(kv => {
        const [k, v] = kv;
        dict.set(k, v);
    });
    return dict;
}
class Optional {
}
class Some extends Optional {
    constructor(x) {
        super();
        this.x = x;
    }
    get() { return this.x; }
    map(f) { return new Some(f(this.x)); }
    flatMap(f) { return f(this.x); }
    doSome(f) { f(this.x); }
    doNone(f) { }
    isNone() { return false; }
    isSome() { return true; }
}
class None extends Optional {
    map(f) { return f(this); }
    flatMap(f) { this; }
    doSome(f) { }
    doNone(f) { f(); }
    isNone() { return true; }
    isSome() { return false; }
}
class Left {
    constructor(val) {
        this._val = val;
    }
    isLeft() {
        return true;
    }
    isRight() {
        return false;
    }
    do(fL, fR) {
        return this.doLeft(fL);
    }
    doLeft(f) {
        f(this._val);
        return this;
    }
    doRight(f) {
        return this;
    }
    chainAny(fL, fR) {
        return fL(this._val);
    }
    map() {
        // Left is the sad path
        // so we do nothing
        return this;
    }
    join() {
        // On the sad path, we don't
        // do anything with join
        return this;
    }
    chain() {
        // Boring sad path,
        // do nothing.
        return this;
    }
    get() {
        return this._val;
    }
    toString() {
        const str = this._val.toString();
        return `Left(${str})`;
    }
}
/**
*Right represents the happy path
*/
class Right {
    constructor(val) {
        this._val = val;
    }
    isLeft() {
        return false;
    }
    isRight() {
        return true;
    }
    do(fL, fR) {
        return this.doRight(fR);
    }
    doLeft(f) {
        return this;
    }
    doRight(f) {
        f(this._val);
        return this;
    }
    chainAny(fL, fR) {
        return this.chain(fR);
    }
    map(fn) {
        return new Right(fn(this._val));
    }
    join() {
        if ((this._val instanceof Left)
            || (this._val instanceof Right)) {
            return this._val;
        }
        return this;
    }
    chain(fn) {
        return fn(this._val);
    }
    get() {
        return this._val;
    }
    toString() {
        const str = this._val.toString();
        return `Right(${str})`;
    }
}
function mapValues(map, fn) {
    return new Map(Array.from(map, ([key, value]) => [key, fn(value)]));
}
function mapKeys(map, fn) {
    return new Map(Array.from(map, ([key, value]) => [fn(key), value]));
}
function mapMap(map, fn) {
    return new Map(Array.from(map, ([key, value]) => fn(key, value)));
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/* harmony import */ var _save_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./save_button */ "./src/save_button.ts");
/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./themes */ "./src/themes.ts");
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _form_renglones__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./form_renglones */ "./src/form_renglones.ts");
/* harmony import */ var _autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./autofill_ui/autofill_ui */ "./src/autofill_ui/autofill_ui.ts");
/* harmony import */ var _autofill_autofill__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./autofill/autofill */ "./src/autofill/autofill.ts");
/* harmony import */ var _input_parser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input/parser */ "./src/input/parser.ts");
/* harmony import */ var _input_CSVCursadaConfig__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input/CSVCursadaConfig */ "./src/input/CSVCursadaConfig.ts");
/* harmony import */ var _input_CSVFinalConfig__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./input/CSVFinalConfig */ "./src/input/CSVFinalConfig.ts");
/* harmony import */ var _autofill_ui_autofill_status_ui__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./autofill_ui/autofill_status_ui */ "./src/autofill_ui/autofill_status_ui.ts");











var PageType;
(function (PageType) {
    PageType[PageType["Cursada"] = 0] = "Cursada";
    PageType[PageType["Final"] = 1] = "Final";
    PageType[PageType["Other"] = 2] = "Other";
})(PageType || (PageType = {}));
function detectPageTypeByURL() {
    if (window.location.host.includes("localhost")) {
        if (window.location.pathname.endsWith("cursada.html")) {
            return PageType.Cursada;
        }
        if (window.location.pathname.endsWith("final.html")) {
            return PageType.Final;
        }
        return PageType.Other;
    }
    const url = window.location.toString();
    if (window.location.pathname.startsWith("/cursada/edicion")) {
        return PageType.Cursada;
    }
    if (window.location.pathname.startsWith("/notas_mesa_examen/edicion")) {
        return PageType.Final;
    }
    return PageType.Other;
}
function detectPageTypeByElements() {
    const cabeceraElement = document.getElementById("cabecera");
    if (!cabeceraElement) {
        return PageType.Other;
    }
    const titleElementContainer = cabeceraElement.querySelector("h2");
    if (!titleElementContainer) {
        return PageType.Other;
    }
    const titleElement = titleElementContainer.children[0];
    switch (titleElement.innerText) {
        case "Carga de notas de cursada": return PageType.Cursada;
        case "Carga de notas a mesa de examen": return PageType.Final;
        default: return PageType.Other;
    }
}
function getSubjectName() {
    const divCabecera = document.getElementById("js-colapsar-detalles-zona");
    const nameSpan = divCabecera.children[0].children[0];
    return nameSpan.innerText;
}
function addColumnCounters(rows, autofill, fieldToIndex) {
    const headerElements = Array.from(document
        .getElementById("renglones")
        .querySelector("thead")
        .querySelectorAll("th"));
    const columnsStatusUIs = Object.entries(fieldToIndex).map((e, i, a) => {
        const [key, value] = e;
        const header = headerElements[value];
        return new _autofill_ui_autofill_status_ui__WEBPACK_IMPORTED_MODULE_10__.ColumnStatusUI(rows, autofill, key, header);
    });
    return columnsStatusUIs;
}
function addPageSpecificUI(settings) {
    switch (detectPageTypeByURL()) {
        case PageType.Cursada: {
            (0,_form_renglones__WEBPACK_IMPORTED_MODULE_4__.when_form_renglones_ready)((form_renglones) => {
                const table = form_renglones.children[1];
                const table_body = table.children[1];
                const rows = Array.from(table_body.rows);
                const subjectName = getSubjectName();
                console.log(`GUARANI-CHROME: Se detectó página de carga de notas de CURSADA de la materia ${subjectName}`);
                const autofill = new _autofill_autofill__WEBPACK_IMPORTED_MODULE_6__.AutofillCursada(new _input_parser__WEBPACK_IMPORTED_MODULE_7__.AutofillParser(new _input_CSVCursadaConfig__WEBPACK_IMPORTED_MODULE_8__.CSVCursadaConfig()), subjectName);
                const fieldToIndex = { "fecha": 3, "nota": 4, "resultado": 5, "condicion": 6 };
                addColumnCounters(rows, autofill, fieldToIndex);
                (0,_autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_5__.addAutofillUI)(rows, settings, autofill);
                (0,_save_button__WEBPACK_IMPORTED_MODULE_1__.addSaveButton)(form_renglones);
            }, 4000, 10);
            break;
        }
        case PageType.Final: {
            (0,_form_renglones__WEBPACK_IMPORTED_MODULE_4__.when_form_renglones_ready)((form_renglones) => {
                const table = form_renglones.children[1];
                const table_body = table.children[1];
                const rows = Array.from(table_body.rows);
                const subjectName = getSubjectName();
                console.log(`GUARANI-CHROME: Se detectó página de carga de notas de FINAL de la materia ${subjectName}`);
                const autofill = new _autofill_autofill__WEBPACK_IMPORTED_MODULE_6__.AutofillFinal(new _input_parser__WEBPACK_IMPORTED_MODULE_7__.AutofillParser(new _input_CSVFinalConfig__WEBPACK_IMPORTED_MODULE_9__.CSVFinalConfig()), subjectName);
                const fieldToIndex = { "fecha": 3, "nota": 4, "resultado": 5 };
                addColumnCounters(rows, autofill, fieldToIndex);
                (0,_autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_5__.addAutofillUI)(rows, settings, autofill);
            }, 4000, 10);
            break;
        }
        default: console.log("GUARANI-CHROME: No se detectó un tipo de página especial.");
    }
}
_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.RestoreFromStorage(s => {
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_3__.ready)(() => (0,_themes__WEBPACK_IMPORTED_MODULE_2__.initializeThemeChooser)(s));
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_3__.waitForElement)("#cabecera", () => {
        addPageSpecificUI(s);
    });
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE2QztBQUNjO0FBQ0o7QUFDdkQ7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7QUFDQSxtQkFBbUIsOENBQUk7QUFDdkI7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELG1FQUFjO0FBQ2pFO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsK0RBQVk7QUFDL0Q7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFGa0U7QUFDRTtBQUNaO0FBQ0Y7QUFDL0MsK0JBQStCLGdEQUFFO0FBQ3hDO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQSxxQ0FBcUMsaUVBQWdCO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLCtEQUFlO0FBQzNDLDhDQUE4Qyw2RUFBeUI7QUFDdkUsUUFBUSxnRUFBYztBQUN0QjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QmtEO0FBQzNDLDhCQUE4QixnREFBRTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHVHQUF1RztBQUN2RyxvQ0FBb0MsV0FBVztBQUMvQywyQkFBMkIsWUFBWTtBQUN2QztBQUNBLHNCQUFzQiwwREFBUSw0REFBNEQsV0FBVztBQUNyRyxrQ0FBa0MsMERBQVE7QUFDMUM7QUFDQSw2QkFBNkIsU0FBUztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQmtEO0FBQzNDLHdDQUF3QyxnREFBRTtBQUNqRDtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQSxzQkFBc0IsMERBQVEsa0JBQWtCLFdBQVcsd0JBQXdCO0FBQ25GLHlCQUF5QiwwREFBUTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJrRDtBQUNWO0FBQ3hDO0FBQ0EsNEJBQTRCLG9EQUFNLHVCQUF1QixFQUFFLEdBQUcsRUFBRTtBQUNoRSxjQUFjLE1BQU0sSUFBSSxLQUFLO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTywrQkFBK0IsZ0RBQUU7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLDBEQUFRO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxtQ0FBbUMsZ0NBQWdDO0FBQ25FLGlEQUFpRCxnQkFBZ0IsY0FBYyxrQkFBa0I7QUFDakcsU0FBUztBQUNUO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNrRDtBQUMzQyx3QkFBd0IsZ0RBQUU7QUFDakM7QUFDQTtBQUNBLG9CQUFvQiwwREFBUTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxNQUFNLEdBQUcsTUFBTTtBQUNqRDtBQUNBO0FBQ0EsdUNBQXVDLElBQUk7QUFDM0M7QUFDQTtBQUNPLHlCQUF5QixnREFBRTtBQUNsQztBQUNBO0FBQ0Esb0JBQW9CLDBEQUFRO0FBQzVCO0FBQ0E7QUFDQSw2QkFBNkIsMERBQVEsV0FBVyxPQUFPO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyw4QkFBOEIsZ0RBQUU7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekd3RDtBQUNVO0FBQ1g7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyx5QkFBeUIsZ0RBQUU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwwREFBUTtBQUM1QjtBQUNBLDZCQUE2QiwwREFBUTtBQUNyQyxvQ0FBb0MsMERBQVE7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsdUJBQXVCLDBEQUFRLHdEQUF3RDtBQUN2Rix5QkFBeUIsMERBQVE7QUFDakM7QUFDQSxZQUFZLCtEQUFhO0FBQ3pCO0FBQ0EsNEJBQTRCLGdFQUFlO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsaUVBQWdCO0FBQ3JEO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQzdEbUQ7QUFDbkQ7QUFDQTtBQUNBLHFEQUFxRCxRQUFRO0FBQzdEO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQyxpQ0FBaUM7QUFDakMsSUFBSSxnRUFBYztBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2Qyw2QkFBNkI7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBLGtEQUFrRCw4QkFBOEI7QUFDaEY7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLDJEQUEyRDtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUM4QztBQUN2QztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QiwwREFBUSxpQkFBaUIsbUJBQW1CO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLGNBQWMsRUFBRSxFQUFFO0FBQ2pEO0FBQ0EsMERBQTBELFFBQVE7QUFDbEUsdURBQXVELFFBQVE7QUFDL0QseURBQXlELFFBQVE7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLDRCQUE0QixFQUFFLE1BQU07QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixtQkFBbUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3RIb0M7QUFDN0IsNkJBQTZCLDZDQUFPO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUNvQztBQUM3QiwyQkFBMkIsNkNBQU87QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZxQztBQUM5QiwrQkFBK0IsOENBQVM7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDbENxQztBQUM5Qiw2QkFBNkIsOENBQVM7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0I0RDtBQUNyRCwwQ0FBMEM7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHVDQUF1QztBQUM5QztBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qiw4Q0FBSSw0QkFBNEIsR0FBRyx1REFBdUQsT0FBTyxTQUFTLEVBQUUsS0FBSyxPQUFPO0FBQy9JO0FBQ0Esb0JBQW9CLDJEQUFhO0FBQ2pDO0FBQ0E7QUFDQSxlQUFlLCtDQUFLO0FBQ3BCO0FBQ0EsaUJBQWlCLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDZ0Q7QUFDdkM7QUFDMUI7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyw4Q0FBSTtBQUNsQixjQUFjLDhDQUFJO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixNQUFNLElBQUkseUNBQXlDO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxVQUFVLElBQUksS0FBSztBQUNqQztBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsOENBQVE7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsMERBQVk7QUFDOUM7QUFDQSx1QkFBdUIsOENBQUkseUhBQXlILHVCQUF1QiwyQkFBMkIsV0FBVztBQUNqTjtBQUNBLG1DQUFtQywwREFBWTtBQUMvQztBQUNBLHVCQUF1Qiw4Q0FBSSxtR0FBbUcsd0JBQXdCLDBCQUEwQixXQUFXO0FBQzNMO0FBQ0E7QUFDQSx1QkFBdUIsOENBQUksNkVBQTZFLFdBQVc7QUFDbkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsOENBQUksZUFBZSxLQUFLLCtDQUErQyxZQUFZLG9DQUFvQyx3RUFBd0U7QUFDOU47QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRDRDO0FBQzVDLFdBQVcsNEJBQTRCO0FBQ2hDO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsNEJBQTRCO0FBQ3REO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakMsSUFBSSx5REFBTyw4QkFBOEIsbURBQW1EO0FBQzVGO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ2hCTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxnQkFBZ0IsZ0NBQWdDLGlCQUFpQjtBQUM1SDtBQUNBO0FBQ0EsMkNBQTJDLHlDQUF5QztBQUNwRjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELGtCQUFrQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixVQUFVLEdBQUcsUUFBUTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRWlEO0FBQ1A7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsZ0RBQUU7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELFNBQVM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsK0NBQStDO0FBQy9DO0FBQ0EsS0FBSztBQUNMLG1CQUFtQix1REFBUztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RE87QUFDUDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sd0NBQXdDLGtEQUFrRDtBQUNqRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5R0FBeUcsT0FBTztBQUNoSDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsS0FBSztBQUNMO0FBQ087QUFDUCxzQ0FBc0MsZUFBZTtBQUNyRDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRU87QUFDQSw4QkFBOEI7QUFDOUI7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ087QUFDUDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1osYUFBYTtBQUNiLGlCQUFpQjtBQUNqQixnQkFBZ0I7QUFDaEI7QUFDQSxlQUFlO0FBQ2YsZUFBZTtBQUNmO0FBQ087QUFDUCxhQUFhO0FBQ2IsaUJBQWlCO0FBQ2pCO0FBQ0EsZ0JBQWdCO0FBQ2hCLGVBQWU7QUFDZixlQUFlO0FBQ2Y7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixJQUFJO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLElBQUk7QUFDNUI7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTs7Ozs7OztVQ3RJQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05zQztBQUNRO0FBQ0k7QUFDUTtBQUNHO0FBQ0g7QUFDVztBQUNyQjtBQUNZO0FBQ0o7QUFDVTtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyw0QkFBNEI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLDRFQUFjO0FBQ2pDLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwwRUFBeUI7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0R0FBNEcsWUFBWTtBQUN4SCxxQ0FBcUMsK0RBQWUsS0FBSyx5REFBYyxLQUFLLHFFQUFnQjtBQUM1Rix1Q0FBdUM7QUFDdkM7QUFDQSxnQkFBZ0IsdUVBQWE7QUFDN0IsZ0JBQWdCLDJEQUFhO0FBQzdCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxZQUFZLDBFQUF5QjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBLDBHQUEwRyxZQUFZO0FBQ3RILHFDQUFxQyw2REFBYSxLQUFLLHlEQUFjLEtBQUssaUVBQWM7QUFDeEYsdUNBQXVDO0FBQ3ZDO0FBQ0EsZ0JBQWdCLHVFQUFhO0FBQzdCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQVE7QUFDUixJQUFJLHVEQUFLLE9BQU8sK0RBQXNCO0FBQ3RDLElBQUksZ0VBQWM7QUFDbEI7QUFDQSxLQUFLO0FBQ0wsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsL2F1dG9maWxsLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsX3VpL2F1dG9maWxsX2NvbmZpZ191aS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9hdXRvZmlsbF91aS9hdXRvZmlsbF9pbnB1dF91aS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9hdXRvZmlsbF91aS9hdXRvZmlsbF9vdmVyd3JpdGVfdWkudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvYXV0b2ZpbGxfdWkvYXV0b2ZpbGxfcmVzdWx0X3VpLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsX3VpL2F1dG9maWxsX3N0YXR1c191aS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9hdXRvZmlsbF91aS9hdXRvZmlsbF91aS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9mb3JtX3Jlbmdsb25lcy50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9ndWFyYW5pL1N0dWRlbnQudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvZ3VhcmFuaS9TdHVkZW50Q3Vyc2FkYS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9ndWFyYW5pL1N0dWRlbnRGaW5hbC50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9pbnB1dC9DU1ZDdXJzYWRhQ29uZmlnLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2lucHV0L0NTVkZpbmFsQ29uZmlnLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2lucHV0L2Nzdi50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9pbnB1dC9wYXJzZXIudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvc2F2ZV9idXR0b24udHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvc2V0dGluZ3MudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvdGhlbWVzLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL3V0aWxzL2RvbV91dGlscy50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy91dGlscy91dGlscy50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExlZnQsIFJpZ2h0IH0gZnJvbSBcIi4uL3V0aWxzL3V0aWxzXCI7XG5pbXBvcnQgeyBTdHVkZW50Q3Vyc2FkYSB9IGZyb20gXCIuLi9ndWFyYW5pL1N0dWRlbnRDdXJzYWRhXCI7XG5pbXBvcnQgeyBTdHVkZW50RmluYWwgfSBmcm9tIFwiLi4vZ3VhcmFuaS9TdHVkZW50RmluYWxcIjtcbmZ1bmN0aW9uIGRuaU1hdGNoZXIoc3R1ZGVudCwgZGF0YSkge1xuICAgIGNvbnN0IG1hdGNoZXMgPSBkYXRhLnJvd3MuZmlsdGVyKChzKSA9PiBzLmdldChcImRuaVwiKSA9PSBzdHVkZW50LmRuaSk7XG4gICAgaWYgKG1hdGNoZXMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmlnaHQobWF0Y2hlc1swXSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gbmV3IExlZnQobWF0Y2hlcyk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEJhc2VBdXRvZmlsbCB7XG4gICAgY29uc3RydWN0b3IocGFyc2VyLCBzdWJqZWN0TmFtZSkge1xuICAgICAgICB0aGlzLnBhcnNlciA9IHBhcnNlcjtcbiAgICAgICAgdGhpcy5zdWJqZWN0TmFtZSA9IHN1YmplY3ROYW1lO1xuICAgIH1cbiAgICBwYXJzZShjc3YpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5wYXJzZXIucGFyc2UoY3N2KTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgYXV0b2ZpbGwocm93c0VsZW1lbnQsIGF1dG9maWxsRGF0YSwgb3ZlcndyaXRlLCBtYXRjaGVyID0gZG5pTWF0Y2hlcikge1xuICAgICAgICBjb25zdCBzdHVkZW50cyA9IHRoaXMuZ2V0U3R1ZGVudHMocm93c0VsZW1lbnQpO1xuICAgICAgICBjb25zdCB1bm1hdGNoZWQgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgc3R1ZGVudCBvZiBzdHVkZW50cykge1xuICAgICAgICAgICAgY29uc3Qgc3R1ZGVudEZvcm1FbXB0eSA9IHN0dWRlbnQuaXNFbXB0eTtcbiAgICAgICAgICAgIGlmICghb3ZlcndyaXRlICYmICFzdHVkZW50Rm9ybUVtcHR5KSB7XG4gICAgICAgICAgICAgICAgc3R1ZGVudC5tYXJrQWxyZWFkeUZpbGxlZFN0dWRlbnQoKTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHN0dWRlbnREYXRhUmVzdWx0ID0gbWF0Y2hlcihzdHVkZW50LCBhdXRvZmlsbERhdGEpO1xuICAgICAgICAgICAgc3R1ZGVudERhdGFSZXN1bHQuZG9SaWdodCgoc3R1ZGVudERhdGEpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmF1dG9maWxsU3R1ZGVudChzdHVkZW50LCBzdHVkZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgaWYgKHN0dWRlbnRGb3JtRW1wdHkpIHtcbiAgICAgICAgICAgICAgICAgICAgc3R1ZGVudC5tYXJrRmlsbGVkU3R1ZGVudCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3R1ZGVudC5tYXJrT3ZlcndyaXR0ZW5TdHVkZW50KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBzdHVkZW50RGF0YVJlc3VsdC5kb0xlZnQoKG1hdGNoZXMpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoc3R1ZGVudEZvcm1FbXB0eSkge1xuICAgICAgICAgICAgICAgICAgICBzdHVkZW50Lm1hcmtVbm1hdGNoZWRTdHVkZW50KG1hdGNoZXMpO1xuICAgICAgICAgICAgICAgICAgICB1bm1hdGNoZWQucHVzaChzdHVkZW50LmRuaSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzdHVkZW50Lm1hcmtBbHJlYWR5RmlsbGVkU3R1ZGVudCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bm1hdGNoZWQ7XG4gICAgfVxuICAgIGF1dG9maWxsU3R1ZGVudChzdHVkZW50LCBzdHVkZW50RGF0YSkge1xuICAgICAgICB0aGlzLnBhcnNlci5jb25maWcuZGF0YUNvbHVtbnMuZm9yRWFjaCgoY29sdW1uKSA9PiB7XG4gICAgICAgICAgICBpZiAoc3R1ZGVudERhdGEuaGFzKGNvbHVtbikpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhdXRvZmlsbFZhbHVlID0gdGhpcy5jb252ZXJ0VmFsdWVzKHN0dWRlbnREYXRhLmdldChjb2x1bW4pLCBjb2x1bW4pO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSBzdHVkZW50LmdldEZpbGxhYmxlRmllbGRFbGVtZW50KGNvbHVtbik7XG4gICAgICAgICAgICAgICAgZWxlbWVudC52YWx1ZSA9IGF1dG9maWxsVmFsdWU7XG4gICAgICAgICAgICAgICAgdmFyIGV2ZW50ID0gbmV3IEV2ZW50KFwiY2hhbmdlXCIpO1xuICAgICAgICAgICAgICAgIGVsZW1lbnQuZGlzcGF0Y2hFdmVudChldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb252ZXJ0VmFsdWVzKHZhbHVlLCBjb2x1bW4pIHtcbiAgICAgICAgLy8gVE9ETyB0ZXN0IGFsdGVybmF0aXZlXG4gICAgICAgIGlmIChjb2x1bW4gaW4gdGhpcy5wYXJzZXIuY29uZmlnLnZhbHVlcykge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VyLmNvbmZpZy52YWx1ZXNbY29sdW1uXVt2YWx1ZV07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQXV0b2ZpbGxDdXJzYWRhIGV4dGVuZHMgQmFzZUF1dG9maWxsIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5vcGVyYXRpb25UeXBlID0gXCJjdXJzYWRhXCI7XG4gICAgfVxuICAgIGdldFN0dWRlbnRzKHJvd3NFbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKHJvd3NFbGVtZW50Lm1hcChyID0+IG5ldyBTdHVkZW50Q3Vyc2FkYShyKSkpO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbEZpbmFsIGV4dGVuZHMgQmFzZUF1dG9maWxsIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5vcGVyYXRpb25UeXBlID0gXCJmaW5hbFwiO1xuICAgIH1cbiAgICBnZXRTdHVkZW50cyhyb3dzRWxlbWVudCkge1xuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShyb3dzRWxlbWVudC5tYXAociA9PiBuZXcgU3R1ZGVudEZpbmFsKHIpKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZnJvbUhUTUwsIGFwcGVuZENoaWxkcmVuLCBVSSB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IEF1dG9maWxsT3ZlcndyaXRlQ29uZmlnVUkgfSBmcm9tIFwiLi9hdXRvZmlsbF9vdmVyd3JpdGVfdWlcIjtcbmltcG9ydCB7IEF1dG9maWxsUmVzdWx0VUkgfSBmcm9tIFwiLi9hdXRvZmlsbF9yZXN1bHRfdWlcIjtcbmltcG9ydCB7IEF1dG9maWxsSW5wdXRVSSB9IGZyb20gXCIuL2F1dG9maWxsX2lucHV0X3VpXCI7XG5leHBvcnQgY2xhc3MgQXV0b2ZpbGxDb25maWdVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3RvcihhdXRvZmlsbCwgb25QYXJzZUNhbGxiYWNrLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnJvb3QgPSBmcm9tSFRNTChgPGRpdiBpZD1cImF1dG9maWxsQ29uZmlnXCIgPjwvZGl2PmApO1xuICAgICAgICBjb25zdCBpbnB1dENTViA9IHNldHRpbmdzLmdldEF1dG9maWxsRGF0YShhdXRvZmlsbC5vcGVyYXRpb25UeXBlLCBhdXRvZmlsbC5zdWJqZWN0TmFtZSk7XG4gICAgICAgIGNvbnN0IGF1dG9maWxsUmVzdWx0VUkgPSBuZXcgQXV0b2ZpbGxSZXN1bHRVSSg1KTtcbiAgICAgICAgY29uc3QgaW5wdXRVcGRhdGUgPSAoaW5wdXRDU1YpID0+IHtcbiAgICAgICAgICAgIHNldHRpbmdzLnNldEF1dG9maWxsRGF0YShhdXRvZmlsbC5vcGVyYXRpb25UeXBlLCBhdXRvZmlsbC5zdWJqZWN0TmFtZSwgaW5wdXRDU1YpO1xuICAgICAgICAgICAgc2V0dGluZ3Muc2F2ZSgpO1xuICAgICAgICAgICAgdGhpcy5kYXRhID0gYXV0b2ZpbGwucGFyc2UoaW5wdXRDU1YpO1xuICAgICAgICAgICAgYXV0b2ZpbGxSZXN1bHRVSS51cGRhdGUodGhpcy5kYXRhKTtcbiAgICAgICAgICAgIG9uUGFyc2VDYWxsYmFjayh0aGlzLmRhdGEpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBpbnB1dFVJID0gbmV3IEF1dG9maWxsSW5wdXRVSShpbnB1dENTViwgaW5wdXRVcGRhdGUsIGF1dG9maWxsLnBhcnNlci5jb25maWcua2V5Q29sdW1ucywgYXV0b2ZpbGwucGFyc2VyLmNvbmZpZy5kYXRhQ29sdW1ucyk7XG4gICAgICAgIGNvbnN0IGF1dG9maWxsT3ZlcndyaXRlQ29uZmlnVUkgPSBuZXcgQXV0b2ZpbGxPdmVyd3JpdGVDb25maWdVSShzZXR0aW5ncyk7XG4gICAgICAgIGFwcGVuZENoaWxkcmVuKHRoaXMucm9vdCwgW2F1dG9maWxsT3ZlcndyaXRlQ29uZmlnVUkucm9vdCwgaW5wdXRVSS5yb290LCBhdXRvZmlsbFJlc3VsdFVJLnJvb3RdKTtcbiAgICAgICAgaW5wdXRVcGRhdGUoaW5wdXRDU1YpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGZyb21IVE1MLCBVSSB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmV4cG9ydCBjbGFzcyBBdXRvZmlsbElucHV0VUkgZXh0ZW5kcyBVSSB7XG4gICAgY29uc3RydWN0b3IoaW5wdXRDU1YsIGNoYW5nZUNhbGxiYWNrLCBrZXlDb2x1bW5zLCBkYXRhQ29sdW1ucykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnJvb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICB0aGlzLnJvb3QuaWQgPSBcImF1dG9maWxsSW5wdXRVSVwiO1xuICAgICAgICBjb25zdCBsYWJlbFRpdGxlID0gYEVsIGZvcm1hdG8gZGUgZW50cmFkYSBlcyBkZSB1biBDU1YsIGNvbiBjYW1wb3Mgc2VwYXJhZG9zIHBvciBlbCBjYXLDoWN0ZXIgJzsnLlxcblNlIHJlcXVpZXJlIGNvbW8gbcOtbmltbyB1bmEgY29sdW1uYSBkZSBpZGVudGlmaWNhY2nDs24geSB1bmEgY29sdW1uYSBkZSBkYXRvczpcXG5cbiAgICAgIENvbHVtbmFzIGRlIGlkZW50aWZpY2FjacOzbjogJHtrZXlDb2x1bW5zfS5cbiAgICAgIENvbHVtbmFzIGRlIGRhdG9zOiAke2RhdGFDb2x1bW5zfS5cbiAgICAgIGA7XG4gICAgICAgIGNvbnN0IGxhYmVsID0gZnJvbUhUTUwoYDxsYWJlbCBmb3I9XCJhdXRvZmlsbElucHV0XCIgc3R5bGU9XCJkaXNwbGF5OmJsb2NrXCIgdGl0bGU9XCIke2xhYmVsVGl0bGV9XCI+Q2FyZ2EgZGUgQ1NWIHBhcmEgYXV0b2xsZW5hZG8g8J+biDo8L2xhYmVsPmApO1xuICAgICAgICBjb25zdCBhdXRvZmlsbERhdGFJbnB1dCA9IGZyb21IVE1MKGBcbiAgICAgICAgPHRleHRhcmVhIHR5cGU9XCJ0ZXh0XCIgbmFtZT1cImF1dG9maWxsXCIgXG4gICAgICAgIGlkPVwiYXV0b2ZpbGxJbnB1dFwiPiR7aW5wdXRDU1Z9PC90ZXh0YXJlYT5gKTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKGxhYmVsKTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKGF1dG9maWxsRGF0YUlucHV0KTtcbiAgICAgICAgYXV0b2ZpbGxEYXRhSW5wdXQub25jaGFuZ2UgPSBlID0+IGNoYW5nZUNhbGxiYWNrKGF1dG9maWxsRGF0YUlucHV0LnZhbHVlKTtcbiAgICAgICAgYXV0b2ZpbGxEYXRhSW5wdXQuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCBlID0+IGNoYW5nZUNhbGxiYWNrKGF1dG9maWxsRGF0YUlucHV0LnZhbHVlKSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZnJvbUhUTUwsIFVJIH0gZnJvbSBcIi4uL3V0aWxzL2RvbV91dGlsc1wiO1xuZXhwb3J0IGNsYXNzIEF1dG9maWxsT3ZlcndyaXRlQ29uZmlnVUkgZXh0ZW5kcyBVSSB7XG4gICAgY29uc3RydWN0b3Ioc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICAgICAgICB0aGlzLnJvb3QgPSBmcm9tSFRNTChgPGRpdiBpZD1cImF1dG9maWxsT3ZlcndyaXRlXCI+PC9kaXY+YCk7XG4gICAgICAgIGNvbnN0IGxhYmVsVGl0bGUgPSBcIlNvYnJlZXNjcmliaXIgdmFsb3JlcyAobm90YXMsIGNvbmRpY2nDs24sIGZlY2hhLCBldGMpIGV4aXN0ZW50ZXMgYWwgcmVsbGVuYXIuXCI7XG4gICAgICAgIGNvbnN0IGxhYmVsID0gZnJvbUhUTUwoYDxsYWJlbCB0aXRsZT1cIiR7bGFiZWxUaXRsZX1cIiBzdHlsZT1cImRpc3BsYXk6aW5saW5lO1wiPlNvYnJlZXNjcmliaXIgdmFsb3JlczogPC9sYWJlbD5gKTtcbiAgICAgICAgY29uc3QgY2hlY2tib3ggPSBmcm9tSFRNTChgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGlkPVwiYXV0b2ZpbGxPdmVyd3JpdGVDaGVja2JveFwiLz5gKTtcbiAgICAgICAgY2hlY2tib3guY2hlY2tlZCA9IHRoaXMuc2V0dGluZ3Mub3ZlcndyaXRlT25BdXRvZmlsbDtcbiAgICAgICAgY2hlY2tib3gub25jaGFuZ2UgPSAoZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncy5vdmVyd3JpdGVPbkF1dG9maWxsID0gY2hlY2tib3guY2hlY2tlZDtcbiAgICAgICAgICAgIHRoaXMuc2V0dGluZ3Muc2F2ZSgpO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQobGFiZWwpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQoY2hlY2tib3gpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGZyb21IVE1MLCBVSSB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IG1hcE1hcCB9IGZyb20gXCIuLi91dGlscy91dGlsc1wiO1xuZnVuY3Rpb24gcm93VG9TdHJpbmcocm93LCBpbmRleCkge1xuICAgIGNvbnN0IGRhdGEgPSBBcnJheS5mcm9tKG1hcE1hcChyb3csIChrLCB2KSA9PiBbaywgYCR7a309JHt2fWBdKS52YWx1ZXMoKSkuam9pbihcIiwgXCIpO1xuICAgIHJldHVybiBgJHtpbmRleH06ICR7ZGF0YX1gO1xufVxuZnVuY3Rpb24gYXV0b2ZpbGxEYXRhVG9TdHJpbmcocm93cykge1xuICAgIGxldCBhc1N0ciA9IHJvd3MubWFwKCh2LCBpLCBhKSA9PiByb3dUb1N0cmluZyh2LCBpKSk7XG4gICAgcmV0dXJuIGFzU3RyLmpvaW4oXCJcXG5cIik7XG59XG5leHBvcnQgY2xhc3MgQXV0b2ZpbGxSZXN1bHRVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3RvcihtYXhSb3dzID0gNSkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLm1heFJvd3MgPSBtYXhSb3dzO1xuICAgICAgICB0aGlzLnJvb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICB0aGlzLnJlc3VsdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJ0ZXh0YXJlYVwiKTtcbiAgICAgICAgdGhpcy5zdGF0dXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgY29uc3QgYXV0b2ZpbGxEYXRhVmlld2VyTGFiZWwgPSBmcm9tSFRNTChgPHAgc3R5bGU9XCJkaXNwbGF5OmJsb2NrXCI+UmVzdWx0YWRvIGRlIGxhIGNhcmdhOiA8L3A+YCk7XG4gICAgICAgIGF1dG9maWxsRGF0YVZpZXdlckxhYmVsLmFwcGVuZENoaWxkKHRoaXMuc3RhdHVzKTtcbiAgICAgICAgdGhpcy5yZXN1bHQuaWQgPSBcImF1dG9maWxsUmVzdWx0XCI7XG4gICAgICAgIHRoaXMucmVzdWx0LmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKGF1dG9maWxsRGF0YVZpZXdlckxhYmVsKTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKHRoaXMucmVzdWx0KTtcbiAgICB9XG4gICAgdXBkYXRlKHJlc3VsdCkge1xuICAgICAgICByZXN1bHQuZG9MZWZ0KGVycm9yID0+IHtcbiAgICAgICAgICAgIHRoaXMucmVzdWx0LnZhbHVlID0gZXJyb3I7XG4gICAgICAgICAgICB0aGlzLnN0YXR1cy5pbm5lclRleHQgPSBcIuKdjFwiO1xuICAgICAgICB9KTtcbiAgICAgICAgcmVzdWx0LmRvUmlnaHQoY3N2ID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNob3J0Um93cyA9IGNzdi5yb3dzLnNsaWNlKDAsIE1hdGgubWluKHRoaXMubWF4Um93cywgY3N2LnJvd3MubGVuZ3RoKSk7XG4gICAgICAgICAgICB0aGlzLnJlc3VsdC52YWx1ZSA9IGAke2F1dG9maWxsRGF0YVRvU3RyaW5nKHNob3J0Um93cyl9YDtcbiAgICAgICAgICAgIHRoaXMuc3RhdHVzLmlubmVyVGV4dCA9IGDinIUgKEZpbGFzOiAke2Nzdi5yb3dzLmxlbmd0aH0sIENvbHVtbmFzOiAke2Nzdi5oZWFkZXIubGVuZ3RofSlgO1xuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBmcm9tSFRNTCwgVUkgfSBmcm9tIFwiLi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5leHBvcnQgY2xhc3MgQ291bnRlclVJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnJvb3QgPSBmcm9tSFRNTChgPHNwYW4gY2xhc3M9XCJjb3VudGVyVUlcIj4gIDwvc3Bhbj5gKTtcbiAgICAgICAgdGhpcy5jb3VudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICB0aGlzLmljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgdGhpcy5pY29uLmlubmVySFRNTCA9IFwiIOKXj1wiO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQodGhpcy5jb3VudCk7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZCh0aGlzLmljb24pO1xuICAgIH1cbiAgICB1cGRhdGUoY291bnQsIHRvdGFsKSB7XG4gICAgICAgIHRoaXMuY291bnQuaW5uZXJIVE1MID0gYCR7Y291bnR9LyR7dG90YWx9YDtcbiAgICAgICAgY29uc3QgcmF0ZSA9IGNvdW50IC8gdG90YWw7XG4gICAgICAgIGNvbnN0IGh1ZSA9IChyYXRlICogMTIwKS50b1N0cmluZygxMCk7XG4gICAgICAgIHRoaXMuaWNvbi5zdHlsZS5jb2xvciA9IGBoc2woJHtodWV9LDcwJSwzNSUpYDtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgUHJvZ3Jlc3NVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3RvcihpZCwgbGFiZWwsIHRpdGxlKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucm9vdCA9IGZyb21IVE1MKGA8c3BhbiBpZD1cInN0YXRzVUlDb21wbGV0ZVwiIGNsYXNzPVwicHJvZ3Jlc3NVSVwiID4gIDwvc3Bhbj5gKTtcbiAgICAgICAgdGhpcy5yb290LnRpdGxlID0gdGl0bGU7XG4gICAgICAgIHRoaXMucm9vdC5pZCA9IGlkO1xuICAgICAgICBjb25zdCBsYWJlbEVsZW1lbnQgPSBmcm9tSFRNTChgPHNwYW4+ICR7bGFiZWx9IDwvc3Bhbj5gKTtcbiAgICAgICAgdGhpcy5jb3VudCA9IG5ldyBDb3VudGVyVUkoKTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKGxhYmVsRWxlbWVudCk7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZCh0aGlzLmNvdW50LnJvb3QpO1xuICAgIH1cbiAgICB1cGRhdGUoY291bnQsIHRvdGFsKSB7XG4gICAgICAgIHRoaXMuY291bnQudXBkYXRlKGNvdW50LCB0b3RhbCk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFN0dWRlbnRDaGFuZ2VVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dzX2VsZW1lbnQsIGF1dG9maWxsKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucm93c19lbGVtZW50ID0gcm93c19lbGVtZW50O1xuICAgICAgICB0aGlzLmF1dG9maWxsID0gYXV0b2ZpbGw7XG4gICAgICAgIHJvd3NfZWxlbWVudC5mb3JFYWNoKChlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpbnB1dHMgPSBlLnF1ZXJ5U2VsZWN0b3JBbGwoXCJpbnB1dCwgc2VsZWN0XCIpO1xuICAgICAgICAgICAgaW5wdXRzLmZvckVhY2goKGkpID0+IHtcbiAgICAgICAgICAgICAgICBpLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU3R1ZGVudENoYW5nZSgpO1xuICAgICAgICAgICAgICAgIH0sIHRydWUpO1xuICAgICAgICAgICAgICAgIGkuYWRkRXZlbnRMaXN0ZW5lcihcImtleXVwXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vblN0dWRlbnRDaGFuZ2UoKTtcbiAgICAgICAgICAgICAgICB9LCB0cnVlKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZ2V0U3R1ZGVudHMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmF1dG9maWxsLmdldFN0dWRlbnRzKHRoaXMucm93c19lbGVtZW50KTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQXV0b2ZpbGxTdGF0c1VJIGV4dGVuZHMgU3R1ZGVudENoYW5nZVVJIHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dzX2VsZW1lbnQsIGF1dG9maWxsKSB7XG4gICAgICAgIHN1cGVyKHJvd3NfZWxlbWVudCwgYXV0b2ZpbGwpO1xuICAgICAgICB0aGlzLnJvb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgdGhpcy5maWVsZENvdW50ZXJzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLnJvb3QuaWQgPSBcInN0YXRzVUlcIjtcbiAgICAgICAgdGhpcy5jb3VudENvbXBsZXRlID0gbmV3IFByb2dyZXNzVUkoXCJzdGF0c1VJQ29tcGxldGVcIiwgXCJDb21wbGV0b1wiLCBcIkVzdHVkaWFudGVzIGNvbiBpbmZvcm1hY2nDs24gY29tcGxldGEgKG5vIGNvbnNpZGVyYSBlbCBjYW1wbyBvYnNlcnZhY2lvbmVzKVwiKTtcbiAgICAgICAgdGhpcy5jb3VudE5vbkVtcHR5ID0gbmV3IFByb2dyZXNzVUkoXCJzdGF0c1VJTm9uRW1wdHlcIiwgXCJDb24gZGF0b3NcIiwgXCJFc3R1ZGlhbnRlcyBjb24gaW5mb3JtYWNpw7NuIGFsZ8O6biBkYXRvIGNvbXBsZXRhZG8sIHBlcm8gbm8gdG9kb3MgKG5vIGNvbnNpZGVyYSBlbCBjYW1wbyBvYnNlcnZhY2lvbmVzKVwiKTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKHRoaXMuY291bnROb25FbXB0eS5yb290KTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKHRoaXMuY291bnRDb21wbGV0ZS5yb290KTtcbiAgICAgICAgLy8gZm9yY2UgdXBkYXRlIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIHRoaXMub25TdHVkZW50Q2hhbmdlKCk7XG4gICAgfVxuICAgIG9uU3R1ZGVudENoYW5nZSgpIHtcbiAgICAgICAgY29uc3Qgc3R1ZGVudHMgPSB0aGlzLmF1dG9maWxsLmdldFN0dWRlbnRzKHRoaXMucm93c19lbGVtZW50KTtcbiAgICAgICAgY29uc3QgdG90YWwgPSBzdHVkZW50cy5sZW5ndGg7XG4gICAgICAgIGNvbnN0IG5vbkVtcHR5ID0gc3R1ZGVudHMuZmlsdGVyKChzKSA9PiAhKHMuaXNFbXB0eSkpLmxlbmd0aDtcbiAgICAgICAgY29uc3QgY29tcGxldGUgPSBzdHVkZW50cy5maWx0ZXIoKHMpID0+IHMuaXNGdWxsKS5sZW5ndGg7XG4gICAgICAgIHRoaXMuY291bnROb25FbXB0eS51cGRhdGUobm9uRW1wdHksIHRvdGFsKTtcbiAgICAgICAgdGhpcy5jb3VudENvbXBsZXRlLnVwZGF0ZShjb21wbGV0ZSwgdG90YWwpO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBDb2x1bW5TdGF0dXNVSSBleHRlbmRzIFN0dWRlbnRDaGFuZ2VVSSB7XG4gICAgY29uc3RydWN0b3Iocm93c19lbGVtZW50LCBhdXRvZmlsbCwgZmllbGQsIGhlYWRlcikge1xuICAgICAgICBzdXBlcihyb3dzX2VsZW1lbnQsIGF1dG9maWxsKTtcbiAgICAgICAgdGhpcy5maWVsZCA9IGZpZWxkO1xuICAgICAgICB0aGlzLmhlYWRlciA9IGhlYWRlcjtcbiAgICAgICAgLy8gY3JlYXRlIENvdW50ZXJVSSBvYmplY3RzIGZvciBlYWNoIGZpZWxkL2NvbHVtblxuICAgICAgICAvLyBjb25zdCBoZWFkZXJFbGVtZW50cyA9IEFycmF5LmZyb20oXG4gICAgICAgIC8vICAgZG9jdW1lbnRcbiAgICAgICAgLy8gICAgIC5nZXRFbGVtZW50QnlJZChcInJlbmdsb25lc1wiKVxuICAgICAgICAvLyAgICAgLnF1ZXJ5U2VsZWN0b3IoXCJ0aGVhZFwiKVxuICAgICAgICAvLyAgICAgLnF1ZXJ5U2VsZWN0b3JBbGwoXCJ0aFwiKVxuICAgICAgICAvLyApO1xuICAgICAgICAvLyBjb25zdCBmaWVsZFRvSW5kZXggPSB7IGZlY2hhOiAzLCBub3RhOiA0LCByZXN1bHRhZG86IDUsIGNvbmRpY2lvbjogNiB9O1xuICAgICAgICAvLyBjb25zdCBoZWFkZXIgPSBoZWFkZXJFbGVtZW50c1tmaWVsZFRvSW5kZXhbZl1dXG4gICAgICAgIC8vIHRoaXMuZmllbGRDb3VudGVycy5zZXQoZiwgY291bnRlclVJKTtcbiAgICAgICAgdGhpcy5jb3VudGVyVUkgPSBuZXcgQ291bnRlclVJKCk7XG4gICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIGhlYWRlci5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgICAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQodGhpcy5jb3VudGVyVUkucm9vdCk7XG4gICAgICAgIHRoaXMub25TdHVkZW50Q2hhbmdlKCk7XG4gICAgfVxuICAgIG9uU3R1ZGVudENoYW5nZSgpIHtcbiAgICAgICAgY29uc3Qgc3R1ZGVudHMgPSB0aGlzLmdldFN0dWRlbnRzKCk7XG4gICAgICAgIGNvbnN0IGNvdW50ID0gc3R1ZGVudHMubWFwKChzKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gcy5nZXRGaWxsYWJsZUZpZWxkKHRoaXMuZmllbGQpICE9PSBcIlwiID8gMSA6IDA7XG4gICAgICAgIH0pLnJlZHVjZSgoYSwgYikgPT4gYSArIGIsIDApO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhzdHVkZW50cylcbiAgICAgICAgdGhpcy5jb3VudGVyVUkudXBkYXRlKGNvdW50LCBzdHVkZW50cy5sZW5ndGgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEF1dG9maWxsQ29uZmlnVUkgfSBmcm9tIFwiLi9hdXRvZmlsbF9jb25maWdfdWlcIjtcbmltcG9ydCB7IGZyb21IVE1MLCBVSSwgdG9nZ2xlRWxlbWVudCwgfSBmcm9tIFwiLi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5pbXBvcnQgeyBBdXRvZmlsbFN0YXRzVUkgfSBmcm9tIFwiLi9hdXRvZmlsbF9zdGF0dXNfdWlcIjtcbmZ1bmN0aW9uIHNob3J0ZW5Ub29sQnV0dG9uc05hbWVzKCkge1xuICAgIGNvbnN0IGF1dG9jb21wbGV0ZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwianMtY29sYXBzYXItYXV0b2NvbXBsZXRhclwiKTtcbiAgICBpZiAoYXV0b2NvbXBsZXRlKSB7XG4gICAgICAgIGF1dG9jb21wbGV0ZS5jaGlsZHJlblsxXS5pbm5lckhUTUwgPSBcIkF1dG9jb21wbGV0YXIgYsOhc2ljb1wiO1xuICAgIH1cbiAgICBjb25zdCBzY2FsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidmVyX2VzY2FsYV9yZWd1bGFyaWRhZFwiKTtcbiAgICBpZiAoc2NhbGUpIHtcbiAgICAgICAgc2NhbGUuaW5uZXJIVE1MID0gXCJHbG9zYXJpb1wiO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbFVJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKHJvd3NFbGVtZW50LCBhdXRvZmlsbCwgc2V0dGluZ3MpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5yb3dzRWxlbWVudCA9IHJvd3NFbGVtZW50O1xuICAgICAgICB0aGlzLmF1dG9maWxsID0gYXV0b2ZpbGw7XG4gICAgICAgIC8vIENyZWF0ZSBhIGJhciBhYm92ZSBtYWluIGZvcm1cbiAgICAgICAgdGhpcy5yb290ID0gZnJvbUhUTUwoYDxkaXYgaWQ9XCJhdXRvZmlsbEJhclwiPiA8L2Rpdj5gKTtcbiAgICAgICAgLy8gYWRkIGEgY29udGFpbmVyIHdpdGggdGhlIGF1dG9maWxsIGNvbmZpZywgYSB0b2dnbGUgYnV0dG9uIHRvIG9wZW4vY2xvc2UgaXQsIGFuZCBhbiBhdXRvZmlsbCBidXR0b24gdG8gb3BlcmF0ZSBpdFxuICAgICAgICBjb25zdCB0b2dnbGVCdXR0b24gPSBmcm9tSFRNTChgPGJ1dHRvbiBpZD1cImF1dG9maWxsQWR2YW5jZWRcIiBjbGFzcz1cImJ0biBidG4tc21hbGxcIiBocmVmPVwiI1wiIHRpdGxlPVwiQ2FyZ2FyIGxvcyBkYXRvcyBlbiBmb3JtYXRvIGNzdiBwYXJhIGxhIG1hdGVyaWEgYWN0dWFsIGRlc2RlIGRvbmRlIHNlIG9idGllbmVuIGxvcyBkYXRvcyBwYXJhIHJlbGxlbmFyLlwiPjxpICAgY2xhc3M9XCJpY29uLXdyZW5jaFwiPjwvaT4gQ29uZmlndXJhciBhdXRvY29tcGxldGFkbyA8L2J1dHRvbj5gKTtcbiAgICAgICAgY29uc3QgYXV0b2ZpbGxTdGFydEJ1dHRvbiA9IGZyb21IVE1MKGA8YnV0dG9uIHR5cGU9J2J1dHRvbicgY2xhc3M9XCJidG4gYnRuLXNtYWxsXCIgdGl0bGU9XCJBdXRvY29tcGxldGFyIGVsIGZvcm11bGFyaW8gZW4gYmFzZSBhIGxvcyBkYXRvcyBlbiBmb3JtYXRvIGNzdiBjYXJnYWRvcyBlbiBsYSBjb25maWd1cmFjacOzblwiPiDwn5OdIEF1dG9jb21wbGV0YXIgPC9idXR0b24+YCk7XG4gICAgICAgIGF1dG9maWxsU3RhcnRCdXR0b24ub25jbGljayA9ICgpID0+IHtcbiAgICAgICAgICAgIGF1dG9maWxsQ29uZmlnVUkuZGF0YS5kb1JpZ2h0KChjc3YpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB1bm1hdGNoZWQgPSB0aGlzLmF1dG9maWxsLmF1dG9maWxsKHJvd3NFbGVtZW50LCBjc3YsIHNldHRpbmdzLm92ZXJ3cml0ZU9uQXV0b2ZpbGwpO1xuICAgICAgICAgICAgICAgIHZhciBzYXZlX2J1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwianMtYnRuLWd1YXJkYXJcIik7XG4gICAgICAgICAgICAgICAgc2F2ZV9idXR0b24uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVuYWJsaW5nIHNhdmUgYnV0dG9uXCIpO1xuICAgICAgICAgICAgICAgIC8vIGNvbnN0IGFsbFVubWF0Y2hlZCA9IGdldFNldHRpbmdzKFNldHRpbmdzS2V5cy5Vbm1hdGNoZWQpIGFzIEFycmF5PG9iamVjdD47XG4gICAgICAgICAgICAgICAgLy8gY29uc3QgbmV3VW5tYXRjaGVkID0gbmV3IFNldChhbGxVbm1hdGNoZWQuY29uY2F0KHVubWF0Y2hlZCkpO1xuICAgICAgICAgICAgICAgIC8vIHNldFNldHRpbmdzKFNldHRpbmdzS2V5cy5Vbm1hdGNoZWQsIEFycmF5LmZyb20obmV3VW5tYXRjaGVkKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY29uZmlnID0gZnJvbUhUTUwoYDxkaXYgaWQ9XCJhdXRvZmlsbENvbmZpZ0NvbnRhaW5lclwiIHN0eWxlPVwiZGlzcGxheTpub25lO1wiPiA8L2Rpdj5gKTtcbiAgICAgICAgY29uc3QgY29udHJvbHMgPSBmcm9tSFRNTChgPGRpdiBpZD1cImF1dG9maWxsQ29udHJvbHNDb250YWluZXJcIj4gPC9kaXY+YCk7XG4gICAgICAgIHRvZ2dsZUJ1dHRvbi5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgICAgICAgdG9nZ2xlRWxlbWVudChjb25maWcsIFwiYmxvY2tcIik7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHN0YXRzVUkgPSBuZXcgQXV0b2ZpbGxTdGF0c1VJKHJvd3NFbGVtZW50LCBhdXRvZmlsbCk7XG4gICAgICAgIGNvbnRyb2xzLmFwcGVuZENoaWxkKHN0YXRzVUkucm9vdCk7XG4gICAgICAgIGNvbnRyb2xzLmFwcGVuZENoaWxkKHRvZ2dsZUJ1dHRvbik7XG4gICAgICAgIGNvbnRyb2xzLmFwcGVuZENoaWxkKGF1dG9maWxsU3RhcnRCdXR0b24pO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQoY29udHJvbHMpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQoY29uZmlnKTtcbiAgICAgICAgY29uc3QgYXV0b2ZpbGxDb25maWdVSSA9IG5ldyBBdXRvZmlsbENvbmZpZ1VJKGF1dG9maWxsLCByZXN1bHQgPT4ge1xuICAgICAgICAgICAgcmVzdWx0LmRvTGVmdChlcnJvciA9PiB7XG4gICAgICAgICAgICAgICAgYXV0b2ZpbGxTdGFydEJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJlc3VsdC5kb1JpZ2h0KGNzdiA9PiB7XG4gICAgICAgICAgICAgICAgYXV0b2ZpbGxTdGFydEJ1dHRvbi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIHNldHRpbmdzKTtcbiAgICAgICAgY29uZmlnLmFwcGVuZENoaWxkKGF1dG9maWxsQ29uZmlnVUkucm9vdCk7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGFkZEF1dG9maWxsVUkocm93cywgc2V0dGluZ3MsIGF1dG9maWxsKSB7XG4gICAgY29uc3QgYXV0b2ZpbGxVSSA9IG5ldyBBdXRvZmlsbFVJKHJvd3MsIGF1dG9maWxsLCBzZXR0aW5ncyk7XG4gICAgY29uc3QgcmVuZ2xvbmVzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZW5nbG9uZXNcIik7XG4gICAgcmVuZ2xvbmVzLnBhcmVudEVsZW1lbnQuaW5zZXJ0QmVmb3JlKGF1dG9maWxsVUkucm9vdCwgcmVuZ2xvbmVzKTtcbiAgICBzaG9ydGVuVG9vbEJ1dHRvbnNOYW1lcygpO1xufVxuIiwiaW1wb3J0IHsgd2FpdEZvckVsZW1lbnQgfSBmcm9tIFwiLi91dGlscy9kb21fdXRpbHNcIjtcbmNvbnN0IGZvcm1fcmVuZ2xvbmVzX3NlbGVjdG9yID0gXCIuZm9ybS1yZW5nbG9uZXNcIjtcbmZ1bmN0aW9uIGZhaWxlZF9jYWxsYmFjayh0aW1lb3V0KSB7XG4gICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBhZnRlciB3YWl0aW5nIGZvciAke3RpbWVvdXR9LCBhc3N1bWluZyB0aGVyZSdzIG5vIGZvcm0gaW4gcGFnZS5gKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3aGVuX2Zvcm1fcmVuZ2xvbmVzX3JlYWR5KGNhbGxiYWNrLCB0aW1lb3V0ID0gNTAwMCwgYWRkaXRpb25hbF93YWl0ID0gMTApIHtcbiAgICBjb25zdCBmb3JtQ2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1fcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihmb3JtX3Jlbmdsb25lc19zZWxlY3Rvcik7XG4gICAgICAgIGNhbGxiYWNrKGZvcm1fcmVuZ2xvbmVzKTtcbiAgICB9O1xuICAgIGNvbnN0IGZhaWxDYWxsYmFjayA9ICgpID0+IHsgZmFpbGVkX2NhbGxiYWNrKHRpbWVvdXQpOyB9O1xuICAgIGNvbnN0IHdhaXRDYWxsYmFjayA9ICgpID0+IHsgc2V0VGltZW91dChmb3JtQ2FsbGJhY2ssIGFkZGl0aW9uYWxfd2FpdCk7IH07XG4gICAgd2FpdEZvckVsZW1lbnQoZm9ybV9yZW5nbG9uZXNfc2VsZWN0b3IsIHdhaXRDYWxsYmFjaywgdGltZW91dCwgdW5kZWZpbmVkLCBmYWlsQ2FsbGJhY2spO1xufVxuLy8gZnVuY3Rpb24gd2hlbl9mb3JtX3Jlbmdsb25lc19yZWFkeV9vbGQobGlzdGVuZXJzKXtcbi8vICAgICBjb25zdCBjb2x1bW5hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjb2x1bW5hXzFcIik7XG4vLyAgICAgICBpZiAoIWNvbHVtbmEpIHtcbi8vICAgICAgICAgY29uc29sZS5sb2coXCIjQ29sdW1uYV8xIG5vdCBmb3VuZDsgbm90IGEgc3R1ZGVudHMgZm9ybS5cIilcbi8vICAgICAgICAgcmV0dXJuICBcbi8vICAgICB9XG4vLyAgICAgY29uc29sZS5sb2coXCJSZWdpc3RlcmluZyB0byBhZGQgc2F2ZSBidXR0b25cIilcbi8vICAgICBjb25zb2xlLmxvZyhjb2x1bW5hKVxuLy8gICAgIG9ic2VydmUoY29sdW1uYSx3aGVuX2NvbHVtbmFfY2hhbmdlcyx7Y2hpbGRMaXN0OnRydWUsc3VidHJlZTp0cnVlIH0sZGlzYWJsZUFmdGVyRmlyc3Q9ZmFsc2UscGFyYW1zPWxpc3RlbmVycylcbi8vICAgfVxuLy8gZnVuY3Rpb24gd2hlbl9jb2x1bW5hX2NoYW5nZXMob2JzZXJ2ZXIsbGlzdGVuZXJzKXtcbi8vICAgY29uc3QgcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZW5nbG9uZXNcIik7XG4vLyAgIGlmIChyZW5nbG9uZXMpIHtcbi8vICAgICBjb25zb2xlLmxvZyhcInJlbmdsb25lcyBmb3VuZDsgYWRkaW5nIG11dGF0aW9uIG9ic2VydmVyXCIpXG4vLyAgICAgY29uc29sZS5sb2cocmVuZ2xvbmVzKVxuLy8gICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxuLy8gICAgIG9ic2VydmUocmVuZ2xvbmVzLHdoZW5fcmVuZ2xvbmVzX2NoYW5nZXMseyBzdWJ0cmVlOiB0cnVlLGNoaWxkTGlzdDp0cnVlIH0sdHJ1ZSxsaXN0ZW5lcnMpICAgICAgICBcbi8vICAgfVxuLy8gfVxuZXhwb3J0IGZ1bmN0aW9uIHdoZW5fcmVuZ2xvbmVzX2NoYW5nZXMob2JzZXJ2ZXIsIGxpc3RlbmVycykge1xuICAgIGNvbnN0IGZvcm1fcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5mb3JtLXJlbmdsb25lc1wiKTtcbiAgICBpZiAoZm9ybV9yZW5nbG9uZXMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJHVUFSQU5JLUNIUk9NRTogRm9ybSByZW5nbG9uZXMgZm91bmQ7IGFkZGluZyBidXR0b25cIik7XG4gICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgbGlzdGVuZXJzLmZvckVhY2gobGlzdGVuZXIgPT4gbGlzdGVuZXIoZm9ybV9yZW5nbG9uZXMpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiR1VBUkFOSS1DSFJPTUU6IEZvcm0gcmVuZ2xvbmVzIG5vdCBmb3VuZFwiKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZW5nbG9uZXNcIikpICAgICAgICBcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBmcm9tSFRNTCB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmV4cG9ydCBjbGFzcyBTdHVkZW50IHtcbiAgICBnZXRGaWxsYWJsZUZpZWxkRWxlbWVudChuYW1lKSB7XG4gICAgICAgIGNvbnN0IGkgPSB0aGlzLmZpbGxhYmxlRmllbGRzTmFtZXMuaW5kZXhPZihuYW1lKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsbGFibGVGaWVsZHNFbGVtZW50c1tpXTtcbiAgICB9XG4gICAgZ2V0RmlsbGFibGVGaWVsZChuYW1lKSB7XG4gICAgICAgIGNvbnN0IGkgPSB0aGlzLmZpbGxhYmxlRmllbGRzTmFtZXMuaW5kZXhPZihuYW1lKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsbGFibGVGaWVsZHNbaV07XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKHJvdykge1xuICAgICAgICB0aGlzLnJvdyA9IHJvdztcbiAgICAgICAgdGhpcy5hZGRSZXN1bHRFbW9qaUVsZW1lbnQoKTtcbiAgICB9XG4gICAgYWRkUmVzdWx0RW1vamlFbGVtZW50KCkge1xuICAgICAgICBpZiAodGhpcy5lbW9qaUVsZW1lbnQpIHtcbiAgICAgICAgICAgIC8vIGRvbid0IGNyZWF0ZSBlbGVtZW50IGlmIGl0IGFscmVhZHkgZXhpc3RzXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWx1bW5vRGl2ID0gdGhpcy5yb3cucXVlcnlTZWxlY3RvcihcIi5maWNoYS1hbHVtbm9cIikuY2hpbGRyZW5bMV07XG4gICAgICAgIGNvbnN0IGVtb2ppRWxlbWVudCA9IGZyb21IVE1MKGA8c3BhbiBjbGFzcz1cIiR7U3R1ZGVudC5FbW9qaUNsYXNzfVwiPiA8c3Bhbj5gKTtcbiAgICAgICAgYWx1bW5vRGl2LmFwcGVuZENoaWxkKGVtb2ppRWxlbWVudCk7XG4gICAgfVxuICAgIGdldCBlbW9qaUVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFN0dWRlbnQuRW1vamlTZWxlY3Rvcik7XG4gICAgfVxuICAgIGdldCBkbmlFbGVtZW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yb3cucXVlcnlTZWxlY3RvcihTdHVkZW50LmVsZW1lbnRTZWxlY3RvcnMuZG5pKTtcbiAgICB9XG4gICAgZ2V0IGRuaSgpIHsgcmV0dXJuIHRoaXMuZG5pRWxlbWVudC5pbm5lclRleHQuc3BsaXQoXCIgXCIpWzFdOyB9XG4gICAgZ2V0IG5vbWJyZUVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFN0dWRlbnQuZWxlbWVudFNlbGVjdG9ycy5ub21icmUpO1xuICAgIH1cbiAgICBnZXQgbm9tYnJlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5ub21icmVFbGVtZW50LmlubmVyVGV4dDtcbiAgICB9XG4gICAgZ2V0IGZlY2hhRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudC5lbGVtZW50U2VsZWN0b3JzLmZlY2hhKTtcbiAgICB9XG4gICAgZ2V0IGZlY2hhKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5mZWNoYUVsZW1lbnQudmFsdWU7XG4gICAgfVxuICAgIHNldCBmZWNoYSh2KSB7XG4gICAgICAgIHRoaXMuZmVjaGFFbGVtZW50LnZhbHVlID0gdjtcbiAgICB9XG4gICAgZ2V0IG5vdGEoKSB7XG4gICAgICAgIGNvbnN0IHYgPSB0aGlzLm5vdGFFbGVtZW50LnZhbHVlO1xuICAgICAgICAvLyBub3RhIHVzZXMgLSBhcyBubyB2YWx1ZVxuICAgICAgICByZXR1cm4gKHYgPT09IFwiLVwiKSA/IFwiXCIgOiB2O1xuICAgIH1cbiAgICBzZXQgbm90YSh2KSB7XG4gICAgICAgIC8vIG5vdGEgdXNlcyAtIGFzIG5vIHZhbHVlXG4gICAgICAgIHYgPSAodiA9PT0gXCJcIikgPyBcIi1cIiA6IHY7XG4gICAgICAgIHRoaXMubm90YUVsZW1lbnQudmFsdWUgPSB2O1xuICAgIH1cbiAgICBnZXQgcmVzdWx0YWRvRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudC5lbGVtZW50U2VsZWN0b3JzLnJlc3VsdGFkbyk7XG4gICAgfVxuICAgIGdldCByZXN1bHRhZG8oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlc3VsdGFkb0VsZW1lbnQudmFsdWU7XG4gICAgfVxuICAgIHNldCByZXN1bHRhZG8odikge1xuICAgICAgICB0aGlzLnJlc3VsdGFkb0VsZW1lbnQudmFsdWUgPSB2O1xuICAgIH1cbiAgICBhZGRUb1N0dWRlbnRUaXRsZShtZXNzYWdlKSB7XG4gICAgICAgIGZ1bmN0aW9uIGFwcGVuZFRvVGl0bGUoZWxlbWVudCwgcykge1xuICAgICAgICAgICAgZWxlbWVudC50aXRsZSA9IGAke2VsZW1lbnQudGl0bGV9JHtzfWA7XG4gICAgICAgIH1cbiAgICAgICAgYXBwZW5kVG9UaXRsZSh0aGlzLm5vbWJyZUVsZW1lbnQsIGBcXG4gQXV0b2ZpbGw6ICR7bWVzc2FnZX1gKTtcbiAgICAgICAgYXBwZW5kVG9UaXRsZSh0aGlzLmRuaUVsZW1lbnQsIGBcXG4gQXV0b2ZpbGw6ICR7bWVzc2FnZX1gKTtcbiAgICAgICAgYXBwZW5kVG9UaXRsZSh0aGlzLmVtb2ppRWxlbWVudCwgYFxcbiBBdXRvZmlsbDogJHttZXNzYWdlfWApO1xuICAgIH1cbiAgICBzZXRTdHVkZW50Q2xhc3Moa2xhc3MpIHtcbiAgICAgICAgdGhpcy5yb3cuY2xhc3NMaXN0LnJlbW92ZSguLi50aGlzLnJvdy5jbGFzc0xpc3QpO1xuICAgICAgICB0aGlzLnJvdy5jbGFzc0xpc3QuYWRkKGtsYXNzKTtcbiAgICB9XG4gICAgbWFya0ZpbGxlZFN0dWRlbnQoKSB7XG4gICAgICAgIHRoaXMuc2V0U3R1ZGVudENsYXNzKFwiYXV0b2ZpbGxlZFN0dWRlbnRcIik7XG4gICAgICAgIHRoaXMuYWRkRW1vamlTdHVkZW50KFwi4pyFXCIpO1xuICAgICAgICB0aGlzLmFkZFRvU3R1ZGVudFRpdGxlKFwiaGEgc2lkbyBjb21wbGV0YWRvIGF1dG9tYXRpY2FtZW50ZVwiKTtcbiAgICB9XG4gICAgbWFya092ZXJ3cml0dGVuU3R1ZGVudCgpIHtcbiAgICAgICAgdGhpcy5zZXRTdHVkZW50Q2xhc3MoXCJtb2RpZmllZFN0dWRlbnRcIik7XG4gICAgICAgIHRoaXMuYWRkRW1vamlTdHVkZW50KFwi4pyP77iPXCIpO1xuICAgICAgICB0aGlzLmFkZFRvU3R1ZGVudFRpdGxlKFwiaGEgc2lkbyBlZGl0YWRvIGF1dG9tw6F0aWNhbWVudGVcIik7XG4gICAgfVxuICAgIG1hcmtVbm1hdGNoZWRTdHVkZW50KG1hdGNoZXMpIHtcbiAgICAgICAgdGhpcy5zZXRTdHVkZW50Q2xhc3MoXCJ1bm1hdGNoZWRTdHVkZW50XCIpO1xuICAgICAgICB0aGlzLmFkZEVtb2ppU3R1ZGVudChcIuKdjFwiKTtcbiAgICAgICAgdGhpcy5hZGRUb1N0dWRlbnRUaXRsZShcIm5vIHNlIHB1ZG8gZW5jb250cmFyIGVuIGVsIGNzdlwiKTtcbiAgICB9XG4gICAgYWRkRW1vamlTdHVkZW50KGVtb2ppKSB7XG4gICAgICAgIHRoaXMuZW1vamlFbGVtZW50LmlubmVyVGV4dCA9IGAke3RoaXMuZW1vamlFbGVtZW50LmlubmVyVGV4dH0ke2Vtb2ppfWA7XG4gICAgfVxuICAgIG1hcmtBbHJlYWR5RmlsbGVkU3R1ZGVudCgpIHtcbiAgICAgICAgdGhpcy5zZXRTdHVkZW50Q2xhc3MoXCJhbHJlYWR5RmlsbGVkU3R1ZGVudFwiKTtcbiAgICAgICAgdGhpcy5hZGRFbW9qaVN0dWRlbnQoXCLimqDvuI9cIik7XG4gICAgICAgIHRoaXMuYWRkVG9TdHVkZW50VGl0bGUoXCJObyBzZSBtb2RpZmljw7MgcG9ycXVlIHlhIHRlbsOtYSB2YWxvcmVzIGNhcmdhZG9zXCIpO1xuICAgIH1cbiAgICBnZXQgZW1wdHlGaWVsZHMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZpbGxhYmxlRmllbGRzLmZpbHRlcihmID0+IGYgPT09IFwiXCIpO1xuICAgIH1cbiAgICBnZXQgaXNGdWxsKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5lbXB0eUZpZWxkcy5sZW5ndGggPT09IDA7XG4gICAgfVxuICAgIGdldCBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5lbXB0eUZpZWxkcy5sZW5ndGggPT0gdGhpcy5maWxsYWJsZUZpZWxkcy5sZW5ndGg7XG4gICAgfVxufVxuU3R1ZGVudC5FbW9qaUNsYXNzID0gXCJyZXN1bHQtZW1vamlcIjtcblN0dWRlbnQuRW1vamlTZWxlY3RvciA9IGAuJHtTdHVkZW50LkVtb2ppQ2xhc3N9YDtcblN0dWRlbnQuZWxlbWVudFNlbGVjdG9ycyA9IHtcbiAgICBkbmk6IFwiLmlkZW50aWZpY2FjaW9uXCIsXG4gICAgbm9tYnJlOiBcIi5ub21icmVcIixcbiAgICBmZWNoYTogXCIuZmVjaGFcIixcbiAgICByZXN1bHRhZG86IFwiLnJlc3VsdGFkb1wiLFxuICAgIGNvbmRpY2lvbjogXCIuY29uZGljaW9uXCIsXG4gICAgb2JzZXJ2YWNpb246IFwiLm9ic2VydmFjaW9uXCIsXG59O1xuIiwiaW1wb3J0IHsgU3R1ZGVudCB9IGZyb20gXCIuL1N0dWRlbnRcIjtcbmV4cG9ydCBjbGFzcyBTdHVkZW50Q3Vyc2FkYSBleHRlbmRzIFN0dWRlbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmZpbGxhYmxlRmllbGRzRWxlbWVudHMgPSBbdGhpcy5ub3RhRWxlbWVudCwgdGhpcy5mZWNoYUVsZW1lbnQsIHRoaXMucmVzdWx0YWRvRWxlbWVudCwgdGhpcy5jb25kaWNpb25FbGVtZW50XTtcbiAgICB9XG4gICAgZ2V0IGNvbmRpY2lvbkVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFN0dWRlbnRDdXJzYWRhLmVsZW1lbnRTZWxlY3RvcnMuY29uZGljaW9uKTtcbiAgICB9XG4gICAgZ2V0IGNvbmRpY2lvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29uZGljaW9uRWxlbWVudC52YWx1ZTtcbiAgICB9XG4gICAgc2V0IGNvbmRpY2lvbih2KSB7XG4gICAgICAgIHRoaXMuY29uZGljaW9uRWxlbWVudC52YWx1ZSA9IHY7XG4gICAgfVxuICAgIGdldCBvYnNlcnZhY2lvbkVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFN0dWRlbnRDdXJzYWRhLmVsZW1lbnRTZWxlY3RvcnMub2JzZXJ2YWNpb24pO1xuICAgIH1cbiAgICBnZXQgb2JzZXJ2YWNpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm9ic2VydmFjaW9uRWxlbWVudC52YWx1ZTtcbiAgICB9XG4gICAgc2V0IG9ic2VydmFjaW9uKHYpIHtcbiAgICAgICAgdGhpcy5vYnNlcnZhY2lvbkVsZW1lbnQudmFsdWUgPSB2O1xuICAgIH1cbiAgICBhc0RpY3QoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkbmk6IHRoaXMuZG5pLFxuICAgICAgICAgICAgbm9tYnJlOiB0aGlzLm5vbWJyZSxcbiAgICAgICAgICAgIGZlY2hhOiB0aGlzLmZlY2hhLFxuICAgICAgICAgICAgbm90YTogdGhpcy5ub3RhLFxuICAgICAgICAgICAgcmVzdWx0YWRvOiB0aGlzLnJlc3VsdGFkbyxcbiAgICAgICAgICAgIGNvbmRpY2lvbjogdGhpcy5jb25kaWNpb24sXG4gICAgICAgICAgICBvYnNlcnZhY2lvbjogdGhpcy5vYnNlcnZhY2lvblxuICAgICAgICB9O1xuICAgIH1cbiAgICBnZXQgbm90YUVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFwiLm5vdGFfY3Vyc2FkYVwiKTtcbiAgICB9XG4gICAgZ2V0IGZpbGxhYmxlRmllbGRzTmFtZXMoKSB7XG4gICAgICAgIHJldHVybiBbXCJub3RhXCIsIFwiZmVjaGFcIiwgXCJyZXN1bHRhZG9cIiwgXCJjb25kaWNpb25cIl07XG4gICAgfVxuICAgIGdldCBmaWxsYWJsZUZpZWxkcygpIHtcbiAgICAgICAgcmV0dXJuIFt0aGlzLm5vdGEsIHRoaXMuZmVjaGEsIHRoaXMucmVzdWx0YWRvLCB0aGlzLmNvbmRpY2lvbl07XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgU3R1ZGVudCB9IGZyb20gXCIuL1N0dWRlbnRcIjtcbmV4cG9ydCBjbGFzcyBTdHVkZW50RmluYWwgZXh0ZW5kcyBTdHVkZW50IHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5maWxsYWJsZUZpZWxkc0VsZW1lbnRzID0gW3RoaXMubm90YUVsZW1lbnQsIHRoaXMuZmVjaGFFbGVtZW50LCB0aGlzLnJlc3VsdGFkb0VsZW1lbnRdO1xuICAgIH1cbiAgICBnZXQgbm90YUVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFwiLm5vdGFcIik7XG4gICAgfVxuICAgIGdldCBmaWxsYWJsZUZpZWxkc05hbWVzKCkge1xuICAgICAgICByZXR1cm4gW1wibm90YVwiLCBcImZlY2hhXCIsIFwicmVzdWx0YWRvXCJdO1xuICAgIH1cbiAgICBnZXQgZmlsbGFibGVGaWVsZHMoKSB7XG4gICAgICAgIHJldHVybiBbdGhpcy5ub3RhLCB0aGlzLmZlY2hhLCB0aGlzLnJlc3VsdGFkb107XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ1NWQ29uZmlnIH0gZnJvbSBcIi4vcGFyc2VyXCI7XG5leHBvcnQgY2xhc3MgQ1NWQ3Vyc2FkYUNvbmZpZyBleHRlbmRzIENTVkNvbmZpZyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuaWQgPSBcImN1cnNhZGFcIjtcbiAgICAgICAgdGhpcy5kYXRhQ29sdW1ucyA9IFtcImZlY2hhXCIsIFwiY29uZGljaW9uXCIsIFwibm90YVwiLCBcInJlc3VsdGFkb1wiXTtcbiAgICAgICAgdGhpcy5rZXlDb2x1bW5zID0gW1wiZG5pXCIsIFwibm9tYnJlXCJdO1xuICAgICAgICB0aGlzLmNzdlNlcGFyYXRvciA9IFwiO1wiO1xuICAgICAgICB0aGlzLnZhbHVlcyA9IHtcbiAgICAgICAgICAgIG5vdGE6IHtcbiAgICAgICAgICAgICAgICBcIlVcIjogXCJVXCIsXG4gICAgICAgICAgICAgICAgXCJEXCI6IFwiRFwiLFxuICAgICAgICAgICAgICAgIFwiQVwiOiBcIkFcIixcbiAgICAgICAgICAgICAgICBcIi1cIjogXCJcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXN1bHRhZG86IHtcbiAgICAgICAgICAgICAgICBcIkF1c2VudGVcIjogXCJVXCIsXG4gICAgICAgICAgICAgICAgXCJSZXByb2JhZG9cIjogXCJSXCIsXG4gICAgICAgICAgICAgICAgXCJBcHJvYmFkb1wiOiBcIkFcIixcbiAgICAgICAgICAgICAgICBcIi1cIjogXCJcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb25kaWNpb246IHtcbiAgICAgICAgICAgICAgICBcIkFiYW5kb25vXCI6IFwiMlwiLFxuICAgICAgICAgICAgICAgIFwiQXByb2JhZG9cIjogXCIxNzVcIixcbiAgICAgICAgICAgICAgICBcIkRlc2Fwcm9iYWRvXCI6IFwiMTc0XCIsXG4gICAgICAgICAgICAgICAgXCJJbnN1ZmljaWVudGVcIjogXCIzXCIsXG4gICAgICAgICAgICAgICAgXCJMaWJyZVwiOiBcIjFcIixcbiAgICAgICAgICAgICAgICBcIk5vIFByb21vY2lvbm9cIjogXCIxMDdcIixcbiAgICAgICAgICAgICAgICBcIlByb21vY2lvbm9cIjogXCI1XCIsXG4gICAgICAgICAgICAgICAgXCJSZWd1bGFyXCI6IFwiNFwiLFxuICAgICAgICAgICAgICAgIFwiLVwiOiBcIlwiLFxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENTVkNvbmZpZyB9IGZyb20gXCIuL3BhcnNlclwiO1xuZXhwb3J0IGNsYXNzIENTVkZpbmFsQ29uZmlnIGV4dGVuZHMgQ1NWQ29uZmlnIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5pZCA9IFwiZmluYWxcIjtcbiAgICAgICAgdGhpcy5kYXRhQ29sdW1ucyA9IFtcImZlY2hhXCIsIFwibm90YVwiLCBcInJlc3VsdGFkb1wiXTtcbiAgICAgICAgdGhpcy5rZXlDb2x1bW5zID0gW1wiZG5pXCIsIFwibm9tYnJlXCJdO1xuICAgICAgICB0aGlzLmNzdlNlcGFyYXRvciA9IFwiO1wiO1xuICAgICAgICB0aGlzLnZhbHVlcyA9IHtcbiAgICAgICAgICAgIG5vdGE6IHtcbiAgICAgICAgICAgICAgICBcIjBcIjogXCIwXCIsXG4gICAgICAgICAgICAgICAgXCIxXCI6IFwiMVwiLFxuICAgICAgICAgICAgICAgIFwiMlwiOiBcIjJcIixcbiAgICAgICAgICAgICAgICBcIjNcIjogXCIzXCIsXG4gICAgICAgICAgICAgICAgXCI0XCI6IFwiNFwiLFxuICAgICAgICAgICAgICAgIFwiNVwiOiBcIjVcIixcbiAgICAgICAgICAgICAgICBcIjZcIjogXCI2XCIsXG4gICAgICAgICAgICAgICAgXCI3XCI6IFwiN1wiLFxuICAgICAgICAgICAgICAgIFwiOFwiOiBcIjhcIixcbiAgICAgICAgICAgICAgICBcIjlcIjogXCI5XCIsXG4gICAgICAgICAgICAgICAgXCIxMFwiOiBcIjEwXCIsXG4gICAgICAgICAgICAgICAgXCItXCI6IFwiXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzdWx0YWRvOiB7XG4gICAgICAgICAgICAgICAgXCJBdXNlbnRlXCI6IFwiVVwiLFxuICAgICAgICAgICAgICAgIFwiUmVwcm9iYWRvXCI6IFwiUlwiLFxuICAgICAgICAgICAgICAgIFwiQXByb2JhZG9cIjogXCJBXCIsXG4gICAgICAgICAgICAgICAgXCItXCI6IFwiXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IExlZnQsIFJpZ2h0LCBkaWN0RnJvbUxpc3RzIH0gZnJvbSBcIi4uL3V0aWxzL3V0aWxzXCI7XG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVDU1YoaW5wdXQsIHNlcGFyYXRvciA9IFwiO1wiKSB7XG4gICAgcmV0dXJuIGlucHV0LnRyaW0oKS5sZW5ndGggPiAwO1xufVxuZnVuY3Rpb24gdG9FbnRyaWVzKGEpIHtcbiAgICByZXR1cm4gYS5tYXAoKHZhbHVlLCBpbmRleCkgPT4gW2luZGV4LCB2YWx1ZV0pO1xufVxuZXhwb3J0IGNsYXNzIENTVlBhcnNlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgY29uc3RydWN0b3IobWVzc2FnZSkge1xuICAgICAgICBzdXBlcihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ0NTVlBhcnNlRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBDU1Yge1xuICAgIGNvbnN0cnVjdG9yKHJvd3MsIGhlYWRlcikge1xuICAgICAgICB0aGlzLnJvd3MgPSByb3dzO1xuICAgICAgICB0aGlzLmhlYWRlciA9IGhlYWRlcjtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gcGFyc2VDU1YoaW5wdXQsIHNlcGFyYXRvciA9IFwiO1xcdFwiLCBub3JtYWxpemVfaGVhZGVyID0gZmFsc2UpIHtcbiAgICBpbnB1dCA9IGlucHV0LnRyaW0oKTtcbiAgICBpZiAoaW5wdXQgPT09IFwiXCIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSaWdodChuZXcgQ1NWKFtdLCBbXSkpO1xuICAgIH1cbiAgICBjb25zdCBsaW5lcyA9IGlucHV0LnNwbGl0KC9cXHJcXG58XFxuLykubWFwKHIgPT4gci50cmltKCkpO1xuICAgIGNvbnN0IG5vbmVtcHR5TGluZXMgPSBsaW5lcy5maWx0ZXIociA9PiByLmxlbmd0aCA+IDApO1xuICAgIGNvbnN0IHNwbGl0TGluZXMgPSBub25lbXB0eUxpbmVzLm1hcCgobCkgPT4gbC5zcGxpdChzZXBhcmF0b3IpKTtcbiAgICBjb25zdCBiYXNpY0hlYWRlciA9IHNwbGl0TGluZXMuc2hpZnQoKTtcbiAgICBjb25zdCBoZWFkZXIgPSBub3JtYWxpemVfaGVhZGVyID8gYmFzaWNIZWFkZXIubWFwKGggPT4gaC50cmltKCkudG9Mb3dlckNhc2UoKSkgOiBiYXNpY0hlYWRlcjtcbiAgICBjb25zdCByb3dzID0gW107XG4gICAgZm9yIChjb25zdCBbaSwgdmFsdWVzXSBvZiB0b0VudHJpZXMoc3BsaXRMaW5lcykpIHtcbiAgICAgICAgaWYgKGhlYWRlci5sZW5ndGggIT0gdmFsdWVzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBMZWZ0KGBOdW1iZXIgb2YgdmFsdWVzIGluIHJvdyAke2l9IGRvZXMgbm90IG1hdGNoIG51bWJlciBvZiB2YWx1ZXMgaW4gaGVhZGVyLlxcbkhlYWRlcjogXCIke2hlYWRlcn1cIlxcblJvdyAke2l9OiBcIiR7dmFsdWVzfVwiYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm93ID0gZGljdEZyb21MaXN0cyhoZWFkZXIsIHZhbHVlcyk7XG4gICAgICAgIHJvd3MucHVzaChyb3cpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFJpZ2h0KG5ldyBDU1Yocm93cywgaGVhZGVyKSk7XG59XG4vLyBwYXJzZUNTVihcImRuaTtoMVxcbjIzO3YxXFxuICBcXG4gIFxcblwiKVxuIiwiaW1wb3J0IHsgU29tZSwgTm9uZSwgaW50ZXJzZWN0aW9uLCBMZWZ0LCBSaWdodCwgfSBmcm9tIFwiLi4vdXRpbHMvdXRpbHNcIjtcbmltcG9ydCB7IHBhcnNlQ1NWIH0gZnJvbSBcIi4vY3N2XCI7XG5leHBvcnQgY2xhc3MgQ1NWQ29uZmlnIHtcbn1cbmZ1bmN0aW9uIGNoZWNrVmFsdWVzKGNvbHVtbiwgdmFsdWVzLCByb3dzKSB7XG4gICAgY29uc3Qgcm93c1dpdGhOdW1iZXIgPSByb3dzLm1hcCgodiwgaSwgYSkgPT4gW3YsIGkgKyAyXSk7XG4gICAgY29uc3Qgcm93c1dpdGhXcm9uZ1ZhbHVlcyA9IHJvd3NXaXRoTnVtYmVyLmZpbHRlcigoW3MsIGldLCBqKSA9PiAhdmFsdWVzLmluY2x1ZGVzKHMuZ2V0KGNvbHVtbikpKTtcbiAgICByZXR1cm4gcm93c1dpdGhXcm9uZ1ZhbHVlcy5sZW5ndGggPT09IDBcbiAgICAgICAgPyBuZXcgTm9uZSgpXG4gICAgICAgIDogbmV3IFNvbWUocm93c1dpdGhXcm9uZ1ZhbHVlcyk7XG59XG5mdW5jdGlvbiBwcmludFJvdyhyb3dJbmRleCwgc2VwYXJhdG9yKSB7XG4gICAgY29uc3QgW3JvdywgaW5kZXhdID0gcm93SW5kZXg7XG4gICAgcmV0dXJuIGBGaWxhICR7aW5kZXh9OiAke0FycmF5LmZyb20ocm93LnZhbHVlcygpKS5qb2luKHNlcGFyYXRvcil9YDtcbn1cbmZ1bmN0aW9uIHByaW50QXV0b2ZpbGxEYXRhKGRhdGEsIGhlYWRlciwgc2VwYXJhdG9yKSB7XG4gICAgbGV0IGhlYWRlclJvdyA9IGhlYWRlci5qb2luKHNlcGFyYXRvcik7XG4gICAgbGV0IHJvd3MgPSBkYXRhLm1hcChyID0+IHByaW50Um93KHIsIHNlcGFyYXRvcikpLmpvaW4oXCJcXG5cIik7XG4gICAgcmV0dXJuIGAke2hlYWRlclJvd31cXG4ke3Jvd3N9XFxuYDtcbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbFBhcnNlciB7XG4gICAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIH1cbiAgICBwYXJzZShkYXRhKSB7XG4gICAgICAgIGNvbnN0IHBhcnNlUmVzdWx0ID0gcGFyc2VDU1YoZGF0YSwgdGhpcy5jb25maWcuY3N2U2VwYXJhdG9yLCB0cnVlKTtcbiAgICAgICAgaWYgKHBhcnNlUmVzdWx0LmlzTGVmdCgpKSB7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VSZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY3N2ID0gcGFyc2VSZXN1bHQuZ2V0KCk7XG4gICAgICAgIGNvbnN0IGtleUNvbHVtbnNQcmVzZW50ID0gaW50ZXJzZWN0aW9uKHRoaXMuY29uZmlnLmtleUNvbHVtbnMsIGNzdi5oZWFkZXIpO1xuICAgICAgICBpZiAoa2V5Q29sdW1uc1ByZXNlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IExlZnQoYEVsIENTViBubyBjb250aWVuZSBuaW5ndW5hIGRlIGxhcyBjb2x1bW5hcyBuZWNlc2FyaWFzIHBhcmEgaWRlbnRpZmljYXIgZXN0dWRpYW50ZXMuIFxcbiAtIENvbHVtbmFzIGRlIGlkZW50aWZpY2FjacOzbjogJHt0aGlzLmNvbmZpZy5rZXlDb2x1bW5zfS4gXFxuIC0gQ29sdW1uYXMgZGVsIGNzdjogJHtjc3YuaGVhZGVyfWApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRhdGFDb2x1bW5zUHJlc2VudCA9IGludGVyc2VjdGlvbih0aGlzLmNvbmZpZy5kYXRhQ29sdW1ucywgY3N2LmhlYWRlcik7XG4gICAgICAgIGlmIChkYXRhQ29sdW1uc1ByZXNlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IExlZnQoYEVsIENTViBubyBjb250aWVuZSBuaW5ndW5hIGNvbHVtbmEgZGUgZGF0b3MgcmVsZXZhbnRlIHBhcmEgZWwgbGxlbmFkby4gXFxuIC0gQ29sdW1uYXMgZGUgZGF0b3M6ICR7dGhpcy5jb25maWcuZGF0YUNvbHVtbnN9LlxcbiAtIENvbHVtbmFzIGRlbCBjc3Y6ICR7Y3N2LmhlYWRlcn1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY3N2LnJvd3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IExlZnQoYEVsIGNzdiBzb2xvIGNvbnRpZW5lIHVuIGVuY2FiZXphZG8sIHkgbm8gY29udGllbmUgZGF0b3MuXFxuIC0gRW5jYWJlemFkbzogJHtjc3YuaGVhZGVyfWApO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVzXSBvZiBPYmplY3QuZW50cmllcyh0aGlzLmNvbmZpZy52YWx1ZXMpKSB7XG4gICAgICAgICAgICBpZiAoY3N2LmhlYWRlci5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsaWRWYWx1ZXMgPSBPYmplY3Qua2V5cyh2YWx1ZXMpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlQ2hlY2sgPSBjaGVja1ZhbHVlcyhrZXksIHZhbGlkVmFsdWVzLCBjc3Yucm93cyk7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlQ2hlY2suaXNTb21lKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJvd3NXaXRoRXJyb3JzID0gdmFsdWVDaGVjay5nZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBMZWZ0KGBMYSBjb2x1bW5hICR7a2V5fSBjb250aWVuZSB2YWxvcmVzIGludsOhbGlkb3MuIFZhbG9yZXMgdsOhbGlkb3M6ICR7dmFsaWRWYWx1ZXN9LlxcbiBGaWxhcyBjb24gdmFsb3JlcyBpbnbDoWxpZG9zOlxcbiR7cHJpbnRBdXRvZmlsbERhdGEocm93c1dpdGhFcnJvcnMsIGNzdi5oZWFkZXIsIHRoaXMuY29uZmlnLmNzdlNlcGFyYXRvcil9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgUmlnaHQoY3N2KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBvYnNlcnZlIH0gZnJvbSBcIi4vdXRpbHMvZG9tX3V0aWxzXCI7XG4vL2ltcG9ydCB7IHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkgfSBmcm9tIFwiLi9mb3JtX3Jlbmdsb25lc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIGFkZFNhdmVCdXR0b24oZm9ybV9yZW5nbG9uZXMpIHtcbiAgICBjb25zdCBiYXNpY19zYXZlX2J1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjanMtYnRuLWd1YXJkYXJcIik7XG4gICAgY29uc3Qgc2F2ZV9idXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW5wdXRcIik7XG4gICAgc2F2ZV9idXR0b24udHlwZSA9IFwic3VibWl0XCI7XG4gICAgc2F2ZV9idXR0b24udmFsdWUgPSBcIkd1YXJkYXJcIjtcbiAgICBzYXZlX2J1dHRvbi5jbGFzc0xpc3QuYWRkKFwiYnRuXCIsIFwiYnRuLWluZm9cIiwgXCJidG4tc21hbGxcIiwgXCJwdWxsLXJpZ2h0XCIpO1xuICAgIHNhdmVfYnV0dG9uLmlkID0gXCJqcy1idG4tZ3VhcmRhclwiO1xuICAgIHNhdmVfYnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7IHRvcDogMCwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgIH07XG4gICAgZm9ybV9yZW5nbG9uZXMuYXBwZW5kQ2hpbGQoc2F2ZV9idXR0b24pO1xuICAgIGNvbnN0IHVwZGF0ZSA9IGZ1bmN0aW9uICgpIHsgc2F2ZV9idXR0b24uZGlzYWJsZWQgPSBiYXNpY19zYXZlX2J1dHRvbi5kaXNhYmxlZDsgfTtcbiAgICBvYnNlcnZlKGJhc2ljX3NhdmVfYnV0dG9uLCB1cGRhdGUsIHsgYXR0cmlidXRlczogdHJ1ZSwgc3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlLCB9LCBmYWxzZSk7XG59XG4vL3doZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkoYWRkX3NhdmVfYnV0dG9uKVxuIiwiZXhwb3J0IGNsYXNzIFNldHRpbmdzIHtcbiAgICBzdGF0aWMgQ2hlY2tWZXJzaW9uKGNhbGxiYWNrKSB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChTZXR0aW5ncy5LZXlzLlZlcnNpb24sIHNldHRpbmdzID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRWZXJzaW9uID0gdGhpcy5kZWZhdWx0U2V0dGluZ3NbU2V0dGluZ3MuS2V5cy5WZXJzaW9uXTtcbiAgICAgICAgICAgIGNvbnN0IHNldHRpbmdzVmVyc2lvbiA9IHNldHRpbmdzW1NldHRpbmdzLktleXMuVmVyc2lvbl07XG4gICAgICAgICAgICBpZiAoc2V0dGluZ3NWZXJzaW9uICE9IGN1cnJlbnRWZXJzaW9uKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgdmVyc2lvbnMgZG9uYHQgbWF0Y2gsIGNsZWFyIGxvY2FsIHN0b3JhZ2UgYW5kIHJlc3RhcnQgc2V0dGluZ3MgdG8gcHJldmVudCBlcnJvcnNcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgR1VBUkFOSS1DSFJPTUU6IE5ldyB2ZXJzaW9uICR7Y3VycmVudFZlcnNpb259IGZvdW5kLCBkZWxldGluZyBzZXR0aW5ncyBmcm9tICR7c2V0dGluZ3NWZXJzaW9ufSBgKTtcbiAgICAgICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xuICAgICAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuY2xlYXIoKTtcbiAgICAgICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU2V0dGluZ3MuS2V5cy5WZXJzaW9uXTogY3VycmVudFZlcnNpb24gfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgc3RhdGljIFJlc3RvcmVGcm9tU3RvcmFnZShjYWxsYmFjaykge1xuICAgICAgICBjb25zb2xlLmxvZyhgR1VBUkFOSS1DSFJPTUU6IEluaXRpYWxpemluZyBzZXR0aW5ncy4uLiBgKTtcbiAgICAgICAgdGhpcy5DaGVja1ZlcnNpb24oKCkgPT4ge1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYEluaXRpYWxpemVkIHdpdGggc2V0dGluZ3M6ICR7T2JqZWN0LmVudHJpZXModil9YClcbiAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChTZXR0aW5ncy5kZWZhdWx0U2V0dGluZ3MsIHZhbHVlcyA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgcyA9IG5ldyBTZXR0aW5ncyh2YWx1ZXNbU2V0dGluZ3MuS2V5cy5UaGVtZV0sIHZhbHVlc1tTZXR0aW5ncy5LZXlzLk92ZXJ3cml0ZU9uQXV0b2ZpbGxdLCB2YWx1ZXNbU2V0dGluZ3MuS2V5cy5BdXRvZmlsbERhdGFDU1ZdLCB2YWx1ZXNbU2V0dGluZ3MuS2V5cy5WZXJzaW9uXSk7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2socyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKHRoZW1lID0gXCJkYXJrXCIsIG92ZXJ3cml0ZU9uQXV0b2ZpbGwgPSB0cnVlLCBhdXRvZmlsbERhdGEsIHZlcnNpb24pIHtcbiAgICAgICAgdGhpcy50aGVtZSA9IHRoZW1lO1xuICAgICAgICB0aGlzLm92ZXJ3cml0ZU9uQXV0b2ZpbGwgPSBvdmVyd3JpdGVPbkF1dG9maWxsO1xuICAgICAgICB0aGlzLmF1dG9maWxsRGF0YSA9IGF1dG9maWxsRGF0YTtcbiAgICAgICAgdGhpcy52ZXJzaW9uID0gdmVyc2lvbjtcbiAgICB9XG4gICAgc2F2ZShjYWxsYmFjayA9ICgpID0+IHsgfSkge1xuICAgICAgICBjb25zdCBzID0ge1xuICAgICAgICAgICAgW1NldHRpbmdzLktleXMuVGhlbWVdOiB0aGlzLnRoZW1lLFxuICAgICAgICAgICAgW1NldHRpbmdzLktleXMuT3ZlcndyaXRlT25BdXRvZmlsbF06IHRoaXMub3ZlcndyaXRlT25BdXRvZmlsbCxcbiAgICAgICAgICAgIFtTZXR0aW5ncy5LZXlzLkF1dG9maWxsRGF0YUNTVl06IHRoaXMuYXV0b2ZpbGxEYXRhLFxuICAgICAgICAgICAgW1NldHRpbmdzLktleXMuVmVyc2lvbl06IHRoaXMudmVyc2lvblxuICAgICAgICB9O1xuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQocykudGhlbigoKSA9PiBjYWxsYmFjaygpKTtcbiAgICB9XG4gICAgZ2V0RGF0YUlEKG9wZXJhdGlvbiwgc3ViamVjdCkge1xuICAgICAgICByZXR1cm4gYCR7b3BlcmF0aW9ufV8ke3N1YmplY3R9YDtcbiAgICB9XG4gICAgZ2V0QXV0b2ZpbGxEYXRhKG9wZXJhdGlvbiwgc3ViamVjdCA9IFwiXCIpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICByZXR1cm4gKF9hID0gdGhpcy5hdXRvZmlsbERhdGFbdGhpcy5nZXREYXRhSUQob3BlcmF0aW9uLCBzdWJqZWN0KV0pICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IFwiXCI7XG4gICAgfVxuICAgIHNldEF1dG9maWxsRGF0YShvcGVyYXRpb24sIHN1YmplY3QsIGRhdGEpIHtcbiAgICAgICAgdGhpcy5hdXRvZmlsbERhdGFbdGhpcy5nZXREYXRhSUQob3BlcmF0aW9uLCBzdWJqZWN0KV0gPSBkYXRhO1xuICAgIH1cbn1cblNldHRpbmdzLktleXMgPSB7XG4gICAgLy8gTWlzc2luZ1N0dWRlbnRzOlwibWlzc2luZ1N0dWRlbnRzXCIsXG4gICAgVGhlbWU6IFwidGhlbWVcIixcbiAgICBPdmVyd3JpdGVPbkF1dG9maWxsOiBcIm92ZXJ3cml0ZU9uQXV0b2ZpbGxcIixcbiAgICBBdXRvZmlsbERhdGFDU1Y6IFwiYXV0b2ZpbGxEYXRhQ1NWXCIsXG4gICAgVmVyc2lvbjogXCJ2ZXJzaW9uXCJcbiAgICAvLyBVbm1hdGNoZWQ6XCJ1bm1hdGNoZWRcIlxufTtcblNldHRpbmdzLmRlZmF1bHRTZXR0aW5ncyA9IHtcbiAgICBbU2V0dGluZ3MuS2V5cy5UaGVtZV06IFwiZGFya1wiLFxuICAgIFtTZXR0aW5ncy5LZXlzLk92ZXJ3cml0ZU9uQXV0b2ZpbGxdOiBmYWxzZSxcbiAgICBbU2V0dGluZ3MuS2V5cy5BdXRvZmlsbERhdGFDU1ZdOiB7fSxcbiAgICBbU2V0dGluZ3MuS2V5cy5WZXJzaW9uXTogXCIyXCJcbiAgICAvLyBbU2V0dGluZ3MyLktleXMuVW5tYXRjaGVkXTpbXSxcbn07XG4iLCJpbXBvcnQgeyBmcm9tSFRNTCwgVUkgfSBmcm9tIFwiLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IG1hcFZhbHVlcyB9IGZyb20gXCIuL3V0aWxzL3V0aWxzXCI7XG5mdW5jdGlvbiBhZGRDU1MoaHJlZikge1xuICAgIGNvbnN0IHRydWVIcmVmID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKGhyZWYpO1xuICAgIHZhciBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGluaycpO1xuICAgIGxpbmsuc2V0QXR0cmlidXRlKCdyZWwnLCAnc3R5bGVzaGVldCcpO1xuICAgIGxpbmsuc2V0QXR0cmlidXRlKCdocmVmJywgdHJ1ZUhyZWYpO1xuICAgIGxpbmsuc2V0QXR0cmlidXRlKCd0eXBlJywgXCJ0ZXh0L2Nzc1wiKTtcbiAgICAvLyBsaW5rLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCBcImRpc2FibGVkXCIpO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgcmV0dXJuIGxpbms7XG59XG5jbGFzcyBUaGVtZXNVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3Rvcih0aGVtZXMsIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMudGhlbWVzID0gdGhlbWVzO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgIHRoaXMucm9vdCA9IGZyb21IVE1MKGA8c2VsZWN0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInRoZW1lXCIgaWQ9XCJ0aGVtZVwiPlxuICAgIDxvcHRpb24gdmFsdWU9XCJsaWdodFwiPkNsYXJvIPCfjJU8L29wdGlvbj5cbiAgICA8b3B0aW9uIHZhbHVlPVwiZGFya1wiPk9zY3VybyDwn4yRPC9vcHRpb24+XG4gICAgPC9zZWxlY3Q+YCk7XG4gICAgICAgIHRoaXMucm9vdC52YWx1ZSA9IHNldHRpbmdzLnRoZW1lO1xuICAgICAgICB0aGlzLnJvb3QuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKGV2ZW50KSA9PiB0aGlzLnVwZGF0ZVRoZW1lKCkpO1xuICAgICAgICB0aGlzLnVwZGF0ZVRoZW1lKCk7XG4gICAgfVxuICAgIHVwZGF0ZVRoZW1lKCkge1xuICAgICAgICBjb25zdCBuZXdUaGVtZSA9IHRoaXMucm9vdC52YWx1ZTtcbiAgICAgICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBDaGFuZ2luZyB0aGVtZSB0byBcIiR7bmV3VGhlbWV9XCJgKTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy50aGVtZSA9IG5ld1RoZW1lO1xuICAgICAgICB0aGlzLnNldHRpbmdzLnNhdmUoKTtcbiAgICAgICAgLy9kaXNhYmxlIGFsbCB0aGVtZXNcbiAgICAgICAgdGhpcy50aGVtZXMuZm9yRWFjaCgodiwgaykgPT4gdi5kaXNhYmxlZCA9IHRydWUpO1xuICAgICAgICAvL2VuYWJsZSBqdXN0IHRoaXMgb25lXG4gICAgICAgIGlmICh0aGlzLnRoZW1lcy5oYXMobmV3VGhlbWUpKSB7XG4gICAgICAgICAgICB0aGlzLnRoZW1lcy5nZXQobmV3VGhlbWUpLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZVRoZW1lQ2hvb3NlcihzZXR0aW5ncykge1xuICAgIGNvbnNvbGUubG9nKGBHVUFSQU5JLUNIUk9NRTogaW5pdGlhbGl6aW5nIHRoZW1lIGNob29zZXJgKTtcbiAgICBjb25zdCB0aGVtZVVSTHMgPSBuZXcgTWFwKE9iamVjdC5lbnRyaWVzKHsgXCJkYXJrXCI6IFwidGhlbWVzL2RhcmsuY3NzXCIsXG4gICAgICAgIFwibGlnaHRcIjogXCJ0aGVtZXMvbGlnaHQuY3NzXCJcbiAgICB9KSk7XG4gICAgY29uc3QgdGhlbWVzID0gbWFwVmFsdWVzKHRoZW1lVVJMcywgYWRkQ1NTKTtcbiAgICAvLyB3YWl0IGEgYml0IGZvciBjc3MgZmlsZXMgdG8gbG9hZCBiZWZvcmUgY3JlYXRpbmcgVGhlbWVzVUlcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHRoZW1lc1VJID0gbmV3IFRoZW1lc1VJKHRoZW1lcywgc2V0dGluZ3MpO1xuICAgICAgICBsZXQgbm90aWZpY2F0aW9ucyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIubm90aWZpY2FjaW9uZXNcIik7XG4gICAgICAgIGlmIChub3RpZmljYXRpb25zKSB7XG4gICAgICAgICAgICBub3RpZmljYXRpb25zLmFwcGVuZENoaWxkKHRoZW1lc1VJLnJvb3QpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBEaWQgbm90IGZpbmQgZWxlbWVudCBcIi5ub3RpZmljYWNpb25lc1wiIHRvIGFwcGVuZCB0aGUgdGhlbWUgY2hvb3NlcmApO1xuICAgICAgICB9XG4gICAgfSwgMTAwKTtcbn1cbiIsImV4cG9ydCBjbGFzcyBVSSB7XG59XG5leHBvcnQgZnVuY3Rpb24gcmVhZHkoZm4pIHtcbiAgICBpZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSAhPT0gJ2xvYWRpbmcnKSB7XG4gICAgICAgIGZuKCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsIGZuKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBvYnNlcnZlKGVsZW1lbnQsIGYsIGNvbmZpZyA9IHsgc3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlLCBhdHRyaWJ1dGVzOiB0cnVlIH0sIGRpc2FibGVBZnRlckZpcnN0ID0gdHJ1ZSwgcGFyYW1zID0gW10pIHtcbiAgICBjb25zdCBtdXRhdGlvbk9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZUFmdGVyRmlyc3QpIHtcbiAgICAgICAgICAgIG11dGF0aW9uT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGYobXV0YXRpb25PYnNlcnZlciwgcGFyYW1zKTtcbiAgICB9KTtcbiAgICBtdXRhdGlvbk9ic2VydmVyLm9ic2VydmUoZWxlbWVudCwgY29uZmlnKTtcbiAgICByZXR1cm4gbXV0YXRpb25PYnNlcnZlcjtcbn1cbmV4cG9ydCBmdW5jdGlvbiB0b2dnbGVFbGVtZW50KGVsLCBkaXNwbGF5ID0gXCJibG9ja1wiKSB7XG4gICAgaWYgKGVsLnN0eWxlLmRpc3BsYXkgPT09IFwibm9uZVwiKSB7XG4gICAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSBkaXNwbGF5O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBmcm9tSFRNTChodG1sLCB0cmltID0gdHJ1ZSkge1xuICAgIC8vIFByb2Nlc3MgdGhlIEhUTUwgc3RyaW5nLlxuICAgIGh0bWwgPSB0cmltID8gaHRtbCA6IGh0bWwudHJpbSgpO1xuICAgIGlmICghaHRtbClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgLy8gVGhlbiBzZXQgdXAgYSBuZXcgdGVtcGxhdGUgZWxlbWVudC5cbiAgICBjb25zdCB0ZW1wbGF0ZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RlbXBsYXRlJyk7XG4gICAgdGVtcGxhdGUuaW5uZXJIVE1MID0gaHRtbDtcbiAgICBjb25zdCByZXN1bHQgPSB0ZW1wbGF0ZS5jb250ZW50LmNoaWxkcmVuO1xuICAgIC8vIFRoZW4gcmV0dXJuIGVpdGhlciBhbiBIVE1MRWxlbWVudCBvciBIVE1MQ29sbGVjdGlvbixcbiAgICAvLyBiYXNlZCBvbiB3aGV0aGVyIHRoZSBpbnB1dCBIVE1MIGhhZCBvbmUgb3IgbW9yZSByb290cy5cbiAgICBpZiAocmVzdWx0Lmxlbmd0aCAhPT0gMSlcbiAgICAgICAgdGhyb3cgRXJyb3IoYGZyb21IVE1MIG11c3QgY3JlYXRlIG9uZSBhbmQgb25seSBvbmUgZWxlbWVudCAocG9zc2libHkgd2l0aCBtYW55IGNoaWxkcmVuLCBmb3VuZCAke3Jlc3VsdH0pYCk7XG4gICAgcmV0dXJuIHJlc3VsdFswXTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBhcHBlbmRDaGlsZHJlbihyb290LCBjaGlsZHJlbikge1xuICAgIGNoaWxkcmVuLmZvckVhY2goY2hpbGQgPT4gcm9vdC5hcHBlbmRDaGlsZChjaGlsZCkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHdhaXRGb3JFbGVtZW50KHNlbGVjdG9yLCBjYWxsYmFjaywgY2hlY2tGcmVxdWVuY3lJbk1zID0gMTAsIHRpbWVvdXRJbk1zID0gMTUwMDAsIGZhaWx1cmVfY2FsbGJhY2sgPSB1bmRlZmluZWQpIHtcbiAgICB2YXIgc3RhcnRUaW1lSW5NcyA9IERhdGUubm93KCk7XG4gICAgKGZ1bmN0aW9uIGxvb3BTZWFyY2goKSB7XG4gICAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICAgICAgaWYgKGVsZW1lbnQpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKGVsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydFRpbWVJbk1zO1xuICAgICAgICAgICAgICAgIGlmICh0aW1lb3V0SW5NcyAmJiBlbGFwc2VkID4gdGltZW91dEluTXMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZhaWx1cmVfY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVfY2FsbGJhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbG9vcFNlYXJjaCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIGNoZWNrRnJlcXVlbmN5SW5Ncyk7XG4gICAgICAgIH1cbiAgICB9KSgpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHByb3BhZ2F0ZU9uQ2hhbmdlKGVsZW1lbnQpIHtcbiAgICB2YXIgZXZlbnQgPSBuZXcgRXZlbnQoJ2NoYW5nZScsIHsgYnViYmxlczogdHJ1ZSB9KTtcbiAgICBlbGVtZW50LmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFuUHJvcGFnYXRlKGUpIHtcbiAgICBlLnZhbHVlID0gXCJcIjtcbiAgICBwcm9wYWdhdGVPbkNoYW5nZShlKTtcbn1cbiIsImV4cG9ydCBjb25zdCB6aXAgPSAoYSwgYikgPT4gYS5tYXAoKGssIGkpID0+IFtrLCBiW2ldXSk7XG5leHBvcnQgZnVuY3Rpb24gaW50ZXJzZWN0aW9uKGEsIGIpIHsgcmV0dXJuIGEuZmlsdGVyKHZhbHVlID0+IGIuaW5jbHVkZXModmFsdWUpKTsgfVxuZXhwb3J0IGZ1bmN0aW9uIGRpY3RGcm9tTGlzdHMoa2V5cywgdmFscykge1xuICAgIGNvbnN0IGRpY3QgPSBuZXcgTWFwKCk7XG4gICAgemlwKGtleXMsIHZhbHMpLmZvckVhY2goa3YgPT4ge1xuICAgICAgICBjb25zdCBbaywgdl0gPSBrdjtcbiAgICAgICAgZGljdC5zZXQoaywgdik7XG4gICAgfSk7XG4gICAgcmV0dXJuIGRpY3Q7XG59XG5leHBvcnQgY2xhc3MgT3B0aW9uYWwge1xufVxuZXhwb3J0IGNsYXNzIFNvbWUgZXh0ZW5kcyBPcHRpb25hbCB7XG4gICAgY29uc3RydWN0b3IoeCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnggPSB4O1xuICAgIH1cbiAgICBnZXQoKSB7IHJldHVybiB0aGlzLng7IH1cbiAgICBtYXAoZikgeyByZXR1cm4gbmV3IFNvbWUoZih0aGlzLngpKTsgfVxuICAgIGZsYXRNYXAoZikgeyByZXR1cm4gZih0aGlzLngpOyB9XG4gICAgZG9Tb21lKGYpIHsgZih0aGlzLngpOyB9XG4gICAgZG9Ob25lKGYpIHsgfVxuICAgIGlzTm9uZSgpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgaXNTb21lKCkgeyByZXR1cm4gdHJ1ZTsgfVxufVxuZXhwb3J0IGNsYXNzIE5vbmUgZXh0ZW5kcyBPcHRpb25hbCB7XG4gICAgbWFwKGYpIHsgcmV0dXJuIGYodGhpcyk7IH1cbiAgICBmbGF0TWFwKGYpIHsgdGhpczsgfVxuICAgIGRvU29tZShmKSB7IH1cbiAgICBkb05vbmUoZikgeyBmKCk7IH1cbiAgICBpc05vbmUoKSB7IHJldHVybiB0cnVlOyB9XG4gICAgaXNTb21lKCkgeyByZXR1cm4gZmFsc2U7IH1cbn1cbmV4cG9ydCBjbGFzcyBMZWZ0IHtcbiAgICBjb25zdHJ1Y3Rvcih2YWwpIHtcbiAgICAgICAgdGhpcy5fdmFsID0gdmFsO1xuICAgIH1cbiAgICBpc0xlZnQoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpc1JpZ2h0KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGRvKGZMLCBmUikge1xuICAgICAgICByZXR1cm4gdGhpcy5kb0xlZnQoZkwpO1xuICAgIH1cbiAgICBkb0xlZnQoZikge1xuICAgICAgICBmKHRoaXMuX3ZhbCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBkb1JpZ2h0KGYpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNoYWluQW55KGZMLCBmUikge1xuICAgICAgICByZXR1cm4gZkwodGhpcy5fdmFsKTtcbiAgICB9XG4gICAgbWFwKCkge1xuICAgICAgICAvLyBMZWZ0IGlzIHRoZSBzYWQgcGF0aFxuICAgICAgICAvLyBzbyB3ZSBkbyBub3RoaW5nXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBqb2luKCkge1xuICAgICAgICAvLyBPbiB0aGUgc2FkIHBhdGgsIHdlIGRvbid0XG4gICAgICAgIC8vIGRvIGFueXRoaW5nIHdpdGggam9pblxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY2hhaW4oKSB7XG4gICAgICAgIC8vIEJvcmluZyBzYWQgcGF0aCxcbiAgICAgICAgLy8gZG8gbm90aGluZy5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGdldCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbDtcbiAgICB9XG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHN0ciA9IHRoaXMuX3ZhbC50b1N0cmluZygpO1xuICAgICAgICByZXR1cm4gYExlZnQoJHtzdHJ9KWA7XG4gICAgfVxufVxuLyoqXG4qUmlnaHQgcmVwcmVzZW50cyB0aGUgaGFwcHkgcGF0aFxuKi9cbmV4cG9ydCBjbGFzcyBSaWdodCB7XG4gICAgY29uc3RydWN0b3IodmFsKSB7XG4gICAgICAgIHRoaXMuX3ZhbCA9IHZhbDtcbiAgICB9XG4gICAgaXNMZWZ0KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzUmlnaHQoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBkbyhmTCwgZlIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZG9SaWdodChmUik7XG4gICAgfVxuICAgIGRvTGVmdChmKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBkb1JpZ2h0KGYpIHtcbiAgICAgICAgZih0aGlzLl92YWwpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY2hhaW5BbnkoZkwsIGZSKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNoYWluKGZSKTtcbiAgICB9XG4gICAgbWFwKGZuKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmlnaHQoZm4odGhpcy5fdmFsKSk7XG4gICAgfVxuICAgIGpvaW4oKSB7XG4gICAgICAgIGlmICgodGhpcy5fdmFsIGluc3RhbmNlb2YgTGVmdClcbiAgICAgICAgICAgIHx8ICh0aGlzLl92YWwgaW5zdGFuY2VvZiBSaWdodCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl92YWw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNoYWluKGZuKSB7XG4gICAgICAgIHJldHVybiBmbih0aGlzLl92YWwpO1xuICAgIH1cbiAgICBnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWw7XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICBjb25zdCBzdHIgPSB0aGlzLl92YWwudG9TdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIGBSaWdodCgke3N0cn0pYDtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gbWFwVmFsdWVzKG1hcCwgZm4pIHtcbiAgICByZXR1cm4gbmV3IE1hcChBcnJheS5mcm9tKG1hcCwgKFtrZXksIHZhbHVlXSkgPT4gW2tleSwgZm4odmFsdWUpXSkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1hcEtleXMobWFwLCBmbikge1xuICAgIHJldHVybiBuZXcgTWFwKEFycmF5LmZyb20obWFwLCAoW2tleSwgdmFsdWVdKSA9PiBbZm4oa2V5KSwgdmFsdWVdKSk7XG59XG5leHBvcnQgZnVuY3Rpb24gbWFwTWFwKG1hcCwgZm4pIHtcbiAgICByZXR1cm4gbmV3IE1hcChBcnJheS5mcm9tKG1hcCwgKFtrZXksIHZhbHVlXSkgPT4gZm4oa2V5LCB2YWx1ZSkpKTtcbn1cbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiaW1wb3J0IHsgU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiO1xuaW1wb3J0IHsgYWRkU2F2ZUJ1dHRvbiB9IGZyb20gXCIuL3NhdmVfYnV0dG9uXCI7XG5pbXBvcnQgeyBpbml0aWFsaXplVGhlbWVDaG9vc2VyIH0gZnJvbSBcIi4vdGhlbWVzXCI7XG5pbXBvcnQgeyByZWFkeSwgd2FpdEZvckVsZW1lbnQgfSBmcm9tIFwiLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkgfSBmcm9tIFwiLi9mb3JtX3Jlbmdsb25lc1wiO1xuaW1wb3J0IHsgYWRkQXV0b2ZpbGxVSSB9IGZyb20gXCIuL2F1dG9maWxsX3VpL2F1dG9maWxsX3VpXCI7XG5pbXBvcnQgeyBBdXRvZmlsbEN1cnNhZGEsIEF1dG9maWxsRmluYWwgfSBmcm9tIFwiLi9hdXRvZmlsbC9hdXRvZmlsbFwiO1xuaW1wb3J0IHsgQXV0b2ZpbGxQYXJzZXIgfSBmcm9tIFwiLi9pbnB1dC9wYXJzZXJcIjtcbmltcG9ydCB7IENTVkN1cnNhZGFDb25maWcgfSBmcm9tIFwiLi9pbnB1dC9DU1ZDdXJzYWRhQ29uZmlnXCI7XG5pbXBvcnQgeyBDU1ZGaW5hbENvbmZpZyB9IGZyb20gXCIuL2lucHV0L0NTVkZpbmFsQ29uZmlnXCI7XG5pbXBvcnQgeyBDb2x1bW5TdGF0dXNVSSB9IGZyb20gXCIuL2F1dG9maWxsX3VpL2F1dG9maWxsX3N0YXR1c191aVwiO1xudmFyIFBhZ2VUeXBlO1xuKGZ1bmN0aW9uIChQYWdlVHlwZSkge1xuICAgIFBhZ2VUeXBlW1BhZ2VUeXBlW1wiQ3Vyc2FkYVwiXSA9IDBdID0gXCJDdXJzYWRhXCI7XG4gICAgUGFnZVR5cGVbUGFnZVR5cGVbXCJGaW5hbFwiXSA9IDFdID0gXCJGaW5hbFwiO1xuICAgIFBhZ2VUeXBlW1BhZ2VUeXBlW1wiT3RoZXJcIl0gPSAyXSA9IFwiT3RoZXJcIjtcbn0pKFBhZ2VUeXBlIHx8IChQYWdlVHlwZSA9IHt9KSk7XG5mdW5jdGlvbiBkZXRlY3RQYWdlVHlwZUJ5VVJMKCkge1xuICAgIGlmICh3aW5kb3cubG9jYXRpb24uaG9zdC5pbmNsdWRlcyhcImxvY2FsaG9zdFwiKSkge1xuICAgICAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLmVuZHNXaXRoKFwiY3Vyc2FkYS5odG1sXCIpKSB7XG4gICAgICAgICAgICByZXR1cm4gUGFnZVR5cGUuQ3Vyc2FkYTtcbiAgICAgICAgfVxuICAgICAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLmVuZHNXaXRoKFwiZmluYWwuaHRtbFwiKSkge1xuICAgICAgICAgICAgcmV0dXJuIFBhZ2VUeXBlLkZpbmFsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQYWdlVHlwZS5PdGhlcjtcbiAgICB9XG4gICAgY29uc3QgdXJsID0gd2luZG93LmxvY2F0aW9uLnRvU3RyaW5nKCk7XG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKFwiL2N1cnNhZGEvZWRpY2lvblwiKSkge1xuICAgICAgICByZXR1cm4gUGFnZVR5cGUuQ3Vyc2FkYTtcbiAgICB9XG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zdGFydHNXaXRoKFwiL25vdGFzX21lc2FfZXhhbWVuL2VkaWNpb25cIikpIHtcbiAgICAgICAgcmV0dXJuIFBhZ2VUeXBlLkZpbmFsO1xuICAgIH1cbiAgICByZXR1cm4gUGFnZVR5cGUuT3RoZXI7XG59XG5mdW5jdGlvbiBkZXRlY3RQYWdlVHlwZUJ5RWxlbWVudHMoKSB7XG4gICAgY29uc3QgY2FiZWNlcmFFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYWJlY2VyYVwiKTtcbiAgICBpZiAoIWNhYmVjZXJhRWxlbWVudCkge1xuICAgICAgICByZXR1cm4gUGFnZVR5cGUuT3RoZXI7XG4gICAgfVxuICAgIGNvbnN0IHRpdGxlRWxlbWVudENvbnRhaW5lciA9IGNhYmVjZXJhRWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiaDJcIik7XG4gICAgaWYgKCF0aXRsZUVsZW1lbnRDb250YWluZXIpIHtcbiAgICAgICAgcmV0dXJuIFBhZ2VUeXBlLk90aGVyO1xuICAgIH1cbiAgICBjb25zdCB0aXRsZUVsZW1lbnQgPSB0aXRsZUVsZW1lbnRDb250YWluZXIuY2hpbGRyZW5bMF07XG4gICAgc3dpdGNoICh0aXRsZUVsZW1lbnQuaW5uZXJUZXh0KSB7XG4gICAgICAgIGNhc2UgXCJDYXJnYSBkZSBub3RhcyBkZSBjdXJzYWRhXCI6IHJldHVybiBQYWdlVHlwZS5DdXJzYWRhO1xuICAgICAgICBjYXNlIFwiQ2FyZ2EgZGUgbm90YXMgYSBtZXNhIGRlIGV4YW1lblwiOiByZXR1cm4gUGFnZVR5cGUuRmluYWw7XG4gICAgICAgIGRlZmF1bHQ6IHJldHVybiBQYWdlVHlwZS5PdGhlcjtcbiAgICB9XG59XG5mdW5jdGlvbiBnZXRTdWJqZWN0TmFtZSgpIHtcbiAgICBjb25zdCBkaXZDYWJlY2VyYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwianMtY29sYXBzYXItZGV0YWxsZXMtem9uYVwiKTtcbiAgICBjb25zdCBuYW1lU3BhbiA9IGRpdkNhYmVjZXJhLmNoaWxkcmVuWzBdLmNoaWxkcmVuWzBdO1xuICAgIHJldHVybiBuYW1lU3Bhbi5pbm5lclRleHQ7XG59XG5mdW5jdGlvbiBhZGRDb2x1bW5Db3VudGVycyhyb3dzLCBhdXRvZmlsbCwgZmllbGRUb0luZGV4KSB7XG4gICAgY29uc3QgaGVhZGVyRWxlbWVudHMgPSBBcnJheS5mcm9tKGRvY3VtZW50XG4gICAgICAgIC5nZXRFbGVtZW50QnlJZChcInJlbmdsb25lc1wiKVxuICAgICAgICAucXVlcnlTZWxlY3RvcihcInRoZWFkXCIpXG4gICAgICAgIC5xdWVyeVNlbGVjdG9yQWxsKFwidGhcIikpO1xuICAgIGNvbnN0IGNvbHVtbnNTdGF0dXNVSXMgPSBPYmplY3QuZW50cmllcyhmaWVsZFRvSW5kZXgpLm1hcCgoZSwgaSwgYSkgPT4ge1xuICAgICAgICBjb25zdCBba2V5LCB2YWx1ZV0gPSBlO1xuICAgICAgICBjb25zdCBoZWFkZXIgPSBoZWFkZXJFbGVtZW50c1t2YWx1ZV07XG4gICAgICAgIHJldHVybiBuZXcgQ29sdW1uU3RhdHVzVUkocm93cywgYXV0b2ZpbGwsIGtleSwgaGVhZGVyKTtcbiAgICB9KTtcbiAgICByZXR1cm4gY29sdW1uc1N0YXR1c1VJcztcbn1cbmZ1bmN0aW9uIGFkZFBhZ2VTcGVjaWZpY1VJKHNldHRpbmdzKSB7XG4gICAgc3dpdGNoIChkZXRlY3RQYWdlVHlwZUJ5VVJMKCkpIHtcbiAgICAgICAgY2FzZSBQYWdlVHlwZS5DdXJzYWRhOiB7XG4gICAgICAgICAgICB3aGVuX2Zvcm1fcmVuZ2xvbmVzX3JlYWR5KChmb3JtX3Jlbmdsb25lcykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhYmxlID0gZm9ybV9yZW5nbG9uZXMuY2hpbGRyZW5bMV07XG4gICAgICAgICAgICAgICAgY29uc3QgdGFibGVfYm9keSA9IHRhYmxlLmNoaWxkcmVuWzFdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBBcnJheS5mcm9tKHRhYmxlX2JvZHkucm93cyk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3ViamVjdE5hbWUgPSBnZXRTdWJqZWN0TmFtZSgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBHVUFSQU5JLUNIUk9NRTogU2UgZGV0ZWN0w7MgcMOhZ2luYSBkZSBjYXJnYSBkZSBub3RhcyBkZSBDVVJTQURBIGRlIGxhIG1hdGVyaWEgJHtzdWJqZWN0TmFtZX1gKTtcbiAgICAgICAgICAgICAgICBjb25zdCBhdXRvZmlsbCA9IG5ldyBBdXRvZmlsbEN1cnNhZGEobmV3IEF1dG9maWxsUGFyc2VyKG5ldyBDU1ZDdXJzYWRhQ29uZmlnKCkpLCBzdWJqZWN0TmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRUb0luZGV4ID0geyBcImZlY2hhXCI6IDMsIFwibm90YVwiOiA0LCBcInJlc3VsdGFkb1wiOiA1LCBcImNvbmRpY2lvblwiOiA2IH07XG4gICAgICAgICAgICAgICAgYWRkQ29sdW1uQ291bnRlcnMocm93cywgYXV0b2ZpbGwsIGZpZWxkVG9JbmRleCk7XG4gICAgICAgICAgICAgICAgYWRkQXV0b2ZpbGxVSShyb3dzLCBzZXR0aW5ncywgYXV0b2ZpbGwpO1xuICAgICAgICAgICAgICAgIGFkZFNhdmVCdXR0b24oZm9ybV9yZW5nbG9uZXMpO1xuICAgICAgICAgICAgfSwgNDAwMCwgMTApO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSBQYWdlVHlwZS5GaW5hbDoge1xuICAgICAgICAgICAgd2hlbl9mb3JtX3Jlbmdsb25lc19yZWFkeSgoZm9ybV9yZW5nbG9uZXMpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB0YWJsZSA9IGZvcm1fcmVuZ2xvbmVzLmNoaWxkcmVuWzFdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhYmxlX2JvZHkgPSB0YWJsZS5jaGlsZHJlblsxXTtcbiAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gQXJyYXkuZnJvbSh0YWJsZV9ib2R5LnJvd3MpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHN1YmplY3ROYW1lID0gZ2V0U3ViamVjdE5hbWUoKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgR1VBUkFOSS1DSFJPTUU6IFNlIGRldGVjdMOzIHDDoWdpbmEgZGUgY2FyZ2EgZGUgbm90YXMgZGUgRklOQUwgZGUgbGEgbWF0ZXJpYSAke3N1YmplY3ROYW1lfWApO1xuICAgICAgICAgICAgICAgIGNvbnN0IGF1dG9maWxsID0gbmV3IEF1dG9maWxsRmluYWwobmV3IEF1dG9maWxsUGFyc2VyKG5ldyBDU1ZGaW5hbENvbmZpZygpKSwgc3ViamVjdE5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkVG9JbmRleCA9IHsgXCJmZWNoYVwiOiAzLCBcIm5vdGFcIjogNCwgXCJyZXN1bHRhZG9cIjogNSB9O1xuICAgICAgICAgICAgICAgIGFkZENvbHVtbkNvdW50ZXJzKHJvd3MsIGF1dG9maWxsLCBmaWVsZFRvSW5kZXgpO1xuICAgICAgICAgICAgICAgIGFkZEF1dG9maWxsVUkocm93cywgc2V0dGluZ3MsIGF1dG9maWxsKTtcbiAgICAgICAgICAgIH0sIDQwMDAsIDEwKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6IGNvbnNvbGUubG9nKFwiR1VBUkFOSS1DSFJPTUU6IE5vIHNlIGRldGVjdMOzIHVuIHRpcG8gZGUgcMOhZ2luYSBlc3BlY2lhbC5cIik7XG4gICAgfVxufVxuU2V0dGluZ3MuUmVzdG9yZUZyb21TdG9yYWdlKHMgPT4ge1xuICAgIHJlYWR5KCgpID0+IGluaXRpYWxpemVUaGVtZUNob29zZXIocykpO1xuICAgIHdhaXRGb3JFbGVtZW50KFwiI2NhYmVjZXJhXCIsICgpID0+IHtcbiAgICAgICAgYWRkUGFnZVNwZWNpZmljVUkocyk7XG4gICAgfSk7XG59KTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==