"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeThemeChooser = void 0;
var settings_1 = require("./settings");
function addCSS(href) {
    var link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', href);
    link.setAttribute('type', "text/css");
    // link.setAttribute('disabled', "disabled");
    document.head.appendChild(link);
    return link;
}
function updateTheme(dark, themeButton) {
    console.log("Changing theme to \"".concat(themeButton.value, "\""));
    (0, settings_1.setSettings)("theme", themeButton.value);
    // console.log(getSettings("theme"))
    if (themeButton.value == "dark") {
        dark.disabled = false;
    }
    else {
        dark.disabled = true;
    }
}
function initializeThemeChooser() {
    console.log("initializing theme chooser");
    var darkUrl = chrome.runtime.getURL("themes/dark.css");
    console.log("Loading ".concat(darkUrl));
    var dark = addCSS(darkUrl);
    var p = document.createElement("div");
    var themeSelect = fromHTML("<select type=\"text\" name=\"theme\" id=\"theme\">\n    <option value=\"light\">Claro \uD83C\uDF15</option>\n    <option value=\"dark\">Oscuro \uD83C\uDF11</option>\n    </select>");
    themeSelect.value = (0, settings_1.getSettings)("theme");
    var notifications = document.querySelector(".notificaciones");
    if (notifications) {
        notifications.appendChild(themeSelect);
    }
    else {
        console.log("Did not find element \".notificaciones\" to append the theme chooser");
    }
    themeSelect.addEventListener('change', function (event) { return updateTheme(dark, themeSelect); });
    updateTheme(dark, themeSelect);
}
exports.initializeThemeChooser = initializeThemeChooser;
// when_form_renglones_ready(initializeThemeChooser);
ready(initializeThemeChooser);
//# sourceMappingURL=themes.js.map