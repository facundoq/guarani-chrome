"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var settings_1 = require("./settings");
var autofill_1 = require("./autofill");
var autofill_config_ui_1 = require("./autofill_config_ui");
var sampleCSV = "dni;condicion;fecha;resultado;nota\n44960966;Aprobado;1/02/2024;Aprobado;A\n44785441;Insuficiente;1/02/2024;Reprobado;D\n45814671;Aprobado;1/02/2024;Aprobado;A\n96172896;Desaprobado;1/02/2024;Reprobado;D\n";
function toggleElement(el, display) {
    if (display === void 0) { display = "block"; }
    if (el.style.display === "none") {
        el.style.display = display;
    }
    else {
        el.style.display = "none";
    }
}
function set2array() {
}
function AutofillStartButtonUI(rows, autofillCallback) {
    var button = fromHTML("<button type='button' class=\"btn btn-small\"> \uD83D\uDCDD Autocompletar </button>");
    button.onclick = function () {
        var unmatched = (0, autofill_1.autofill)(rows, (0, settings_1.getSettings)("autofillData"), (0, settings_1.getSettings)("overwriteOnAutofill"));
        var allUnmatched = (0, settings_1.getSettings)("unmatched");
        var newUnmatched = new Set(allUnmatched.concat(unmatched));
        (0, settings_1.setSettings)("unmatched", Array.from(newUnmatched));
        autofillCallback();
    };
    button.update = function () {
        if ((0, settings_1.getSettings)("autofillData")) {
            button.disabled = false;
        }
        else {
            button.disabled = true;
        }
    };
    button.update();
    return button;
}
function AutofillStatsUI(rows_element) {
    var container = fromHTML("<span  id=\"statsUI\"> </span>");
    var label = fromHTML("<span> Completados: </span>");
    var count = fromHTML("<span  id=\"statsUIProgress\"> </span>");
    // const elementsToWatch = rows_element.querySelectorAll("input, .select")
    // elementsToWatch.foreach()
    appendChildren(container, [label, count]);
    return container;
}
function shortenToolButtonsNames() {
    document.getElementById("js-colapsar-autocompletar").children[1].innerHTML = "Autocompletar básico";
    document.getElementById("ver_escala_regularidad").children[1].innerHTML =
        "Glosario";
}
function AutofillUI(rows_element) {
    // Create a bar above main form
    var autofillUI = fromHTML("<div id=\"autofillBar\"> </div>");
    // add a container with the autofill config, a toggle button to open/close it, and an autofill button to operate it
    var toggleButton = fromHTML("<button id=\"autofillAdvanced\" class=\"btn btn-small\" href=\"#\"><i   class=\"icon-wrench\"></i> Config </button>");
    var autofillStartButton = AutofillStartButtonUI(rows_element, function () {
        //TODO show unmatched
    });
    var config = fromHTML("<div id=\"autofillConfigContainer\" style=\"display:none;\"> </div>");
    var controls = fromHTML("<div id=\"autofillControlsContainer\"> </div>");
    toggleButton.onclick = function () { toggleElement(config, "block"); };
    controls.appendChild(toggleButton);
    controls.appendChild(autofillStartButton);
    autofillUI.appendChild(controls);
    autofillUI.appendChild(config);
    var autofillConfigUI = (0, autofill_config_ui_1.AutofillConfigUI)(autofillStartButton);
    config.appendChild(autofillConfigUI);
    return autofillUI;
}
// function AutofillUI2(rows_element) {
//   const container = fromHTML(`<div class="span3" id="autofillContainer"> </div>`)
//   console.log("Adding Autofill UI")
//   const logo = fromHTML(`<img id="guaraniChromeLogo" src="/images/logo.png"/>`)
//   const autofillStartButtonUI = AutofillStartButtonUI(rows_element, () => {
//     //TODO show unmatched
//   })
//   const autofillConfigUI = AutofillConfigUI(autofillStartButtonUI)
//   const autofillStatsUI = AutofillStatsUI(rows_element)
//   appendChildren(container, [logo, autofillStartButtonUI, autofillConfigUI])
//   return container
// }
function addAutofillUI(form_renglones) {
    // const root = document.getElementById("notas_cursada_query").parentElement.parentElement.parentElement
    var table = form_renglones.children[1];
    var table_body = table.children[1];
    var autofillUI = AutofillUI(table_body.rows);
    var renglones = document.getElementById("renglones");
    renglones.parentElement.insertBefore(autofillUI, renglones);
    // TODO COnsider alternative location for UI
    // const autofillContainer = document.getElementsByClassName("form-actions");
    // root.appendChild(autofillUI)
    //TODO remove load data for testing automatically
    //document.getElementById("autofillSubmitButton").onclick()
}
//# sourceMappingURL=autofill_ui.js.map