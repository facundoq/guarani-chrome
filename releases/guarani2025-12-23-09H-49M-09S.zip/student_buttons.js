"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var settings_1 = require("./settings");
var passed_button = '<p style="background-color:#82f5a3;font-weight:bold;cursor: pointer;"> Aprobar </p>';
var failed_button = '<p style="background-color:#f58982;font-weight:bold;cursor: pointer;"> Desaprobar </p>';
var clean_button = '<p style="background-color:#AAAAAA;font-weight:bold;cursor: pointer;"> Limpiar </p>';
function change_row(row, condition, result) {
    var fecha = row.querySelector(".fecha");
    fecha.value = (0, settings_1.getSettings)("date");
    propagateOnChange(fecha);
    // const resultado = row.querySelector(".resultado");
    // resultado.value = result;
    // propagateOnChange(resultado)
    var condicion = row.querySelector(".condicion");
    condicion.value = condition;
    propagateOnChange(condicion);
}
function add_passed_button(row) {
    var button_container = row.querySelector(".col-nro-acta");
    var button = fromHTML(passed_button);
    button.onclick = function (e) { change_row(row, 175, "A"); };
    button_container.appendChild(button);
}
function add_failed_button(row) {
    var button_container = row.querySelector(".col-nro-acta");
    var button = fromHTML(failed_button);
    button.onclick = function (e) { change_row(row, 174, "R"); };
    button_container.appendChild(button);
}
function add_clean_button(row) {
    var button_container = row.querySelector(".col-nro-acta");
    var button = fromHTML(clean_button);
    button.onclick = function (e) {
        cleanPropagate(row.querySelector(".fecha"));
        cleanPropagate(row.querySelector(".resultado"));
        cleanPropagate(row.querySelector(".condicion"));
    };
    button_container.appendChild(button);
}
function add_row_buttons(form_renglones) {
    var table = form_renglones.children[1];
    var table_body = table.children[1];
    for (var _i = 0, _a = table_body.rows; _i < _a.length; _i++) {
        var row = _a[_i];
        add_passed_button(row);
        add_failed_button(row);
        add_clean_button(row);
    }
}
//# sourceMappingURL=student_buttons.js.map