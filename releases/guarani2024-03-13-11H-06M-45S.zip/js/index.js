/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/autofill_ui/autofill_ui.ts":
/*!****************************************!*\
  !*** ./src/autofill_ui/autofill_ui.ts ***!
  \****************************************/
/***/ (() => {

throw new Error("Module build failed (from ./node_modules/ts-loader/index.js):\nError: TypeScript emitted no output for /home/facundoq/dev/guarani-chrome/src/autofill_ui/autofill_ui.ts.\n    at makeSourceMapAndFinish (/home/facundoq/dev/guarani-chrome/node_modules/ts-loader/dist/index.js:53:18)\n    at successLoader (/home/facundoq/dev/guarani-chrome/node_modules/ts-loader/dist/index.js:40:5)\n    at Object.loader (/home/facundoq/dev/guarani-chrome/node_modules/ts-loader/dist/index.js:23:5)");

/***/ }),

/***/ "./src/form_renglones.ts":
/*!*******************************!*\
  !*** ./src/form_renglones.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   when_form_renglones_ready: () => (/* binding */ when_form_renglones_ready),
/* harmony export */   when_renglones_changes: () => (/* binding */ when_renglones_changes)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");

const form_renglones_selector = ".form-renglones";
function failed_callback(timeout) {
    console.log(`after waiting for ${timeout}, assuming there's no form in page.`);
}
function when_form_renglones_ready(callback, timeout = 5000, additional_wait = 10) {
    const formCallback = () => {
        const form_renglones = document.querySelector(form_renglones_selector);
        callback(form_renglones);
    };
    const failCallback = () => { failed_callback(timeout); };
    const waitCallback = () => { setTimeout(formCallback, additional_wait); };
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.waitForElement)(form_renglones_selector, waitCallback, timeout, undefined, failCallback);
}
// function when_form_renglones_ready_old(listeners){
//     const columna = document.querySelector("#columna_1");
//       if (!columna) {
//         console.log("#Columna_1 not found; not a students form.")
//         return  
//     }
//     console.log("Registering to add save button")
//     console.log(columna)
//     observe(columna,when_columna_changes,{childList:true,subtree:true },disableAfterFirst=false,params=listeners)
//   }
// function when_columna_changes(observer,listeners){
//   const renglones = document.querySelector("#renglones");
//   if (renglones) {
//     console.log("renglones found; adding mutation observer")
//     console.log(renglones)
//     observer.disconnect()
//     observe(renglones,when_renglones_changes,{ subtree: true,childList:true },true,listeners)        
//   }
// }
function when_renglones_changes(observer, listeners) {
    const form_renglones = document.querySelector(".form-renglones");
    if (form_renglones) {
        console.log("Form renglones found; adding button");
        observer.disconnect();
        listeners.forEach(listener => listener(form_renglones));
    }
    else {
        console.log("Form renglones not found");
        console.log(document.querySelector("#renglones"));
    }
}


/***/ }),

/***/ "./src/settings.ts":
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Settings: () => (/* binding */ Settings),
/* harmony export */   getSettings: () => (/* binding */ getSettings),
/* harmony export */   initializeSettings: () => (/* binding */ initializeSettings),
/* harmony export */   setSettings: () => (/* binding */ setSettings)
/* harmony export */ });
const Settings = { MissingStudents: "missingStudents",
    Theme: "theme",
    Date: "date",
    OverwriteOnAutofill: "overwriteOnAutofill",
    AutofillData: "autofillData",
    AutofillDataCSV: "autofillDataCSV",
    Unmatched: "unmatched"
};
var _settings = { [Settings.Date]: '01/01/2024',
    [Settings.Theme]: "dark",
    [Settings.OverwriteOnAutofill]: false,
    [Settings.AutofillDataCSV]: "",
    [Settings.AutofillData]: {},
    unmatched: [],
};
function getSettings(key) {
    return _settings[key];
}
function setSettings(key, value) {
    _settings[key] = value;
    chrome.storage.local.set({ [key]: value }, () => { });
}
;
function initializeSettings(callback) {
    console.log(`Initializing settings...`);
    chrome.storage.local.get(_settings, (v) => {
        // copy existing values from local storage
        for (const k in v) {
            _settings[k] = v[k];
        }
        // console.log(`Initialized with settings: ${Object.entries(v)}`)
        callback();
    });
}


/***/ }),

/***/ "./src/themes.ts":
/*!***********************!*\
  !*** ./src/themes.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initializeThemeChooser: () => (/* binding */ initializeThemeChooser)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings */ "./src/settings.ts");


function addCSS(href) {
    var link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', href);
    link.setAttribute('type', "text/css");
    // link.setAttribute('disabled', "disabled");
    document.head.appendChild(link);
    return link;
}
function updateTheme(dark, themeButton) {
    console.log(`Changing theme to "${themeButton.value}"`);
    (0,_settings__WEBPACK_IMPORTED_MODULE_1__.setSettings)("theme", themeButton.value);
    // console.log(getSettings("theme"))
    if (themeButton.value == "dark") {
        dark.disabled = false;
    }
    else {
        dark.disabled = true;
    }
}
function initializeThemeChooser() {
    console.log(`initializing theme chooser`);
    const darkUrl = chrome.runtime.getURL("themes/dark.css");
    console.log(`Loading ${darkUrl}`);
    let dark = addCSS(darkUrl);
    const p = document.createElement("div");
    let themeSelect = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<select type="text" name="theme" id="theme">
    <option value="light">Claro 🌕</option>
    <option value="dark">Oscuro 🌑</option>
    </select>`);
    themeSelect.value = (0,_settings__WEBPACK_IMPORTED_MODULE_1__.getSettings)("theme");
    let notifications = document.querySelector(".notificaciones");
    if (notifications) {
        notifications.appendChild(themeSelect);
    }
    else {
        console.log(`Did not find element ".notificaciones" to append the theme chooser`);
    }
    themeSelect.addEventListener('change', (event) => updateTheme(dark, themeSelect));
    updateTheme(dark, themeSelect);
}


/***/ }),

/***/ "./src/utils/dom_utils.ts":
/*!********************************!*\
  !*** ./src/utils/dom_utils.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UI: () => (/* binding */ UI),
/* harmony export */   appendChildren: () => (/* binding */ appendChildren),
/* harmony export */   cleanPropagate: () => (/* binding */ cleanPropagate),
/* harmony export */   fromHTML: () => (/* binding */ fromHTML),
/* harmony export */   observe: () => (/* binding */ observe),
/* harmony export */   propagateOnChange: () => (/* binding */ propagateOnChange),
/* harmony export */   ready: () => (/* binding */ ready),
/* harmony export */   waitForElement: () => (/* binding */ waitForElement)
/* harmony export */ });
class UI {
    update() {
    }
}
function ready(fn) {
    if (document.readyState !== 'loading') {
        fn();
        return;
    }
    document.addEventListener('DOMContentLoaded', fn);
}
function observe(element, f, config = { subtree: true, childList: true, attributes: true }, disableAfterFirst = true, params = []) {
    const mutationObserver = new MutationObserver(() => {
        if (disableAfterFirst) {
            mutationObserver.disconnect();
        }
        f(mutationObserver, params);
    });
    mutationObserver.observe(element, config);
    return mutationObserver;
}
function fromHTML(html, trim = true) {
    // Process the HTML string.
    html = trim ? html : html.trim();
    if (!html)
        return null;
    // Then set up a new template element.
    const template = document.createElement('template');
    template.innerHTML = html;
    const result = template.content.children;
    // Then return either an HTMLElement or HTMLCollection,
    // based on whether the input HTML had one or more roots.
    if (result.length !== 1)
        throw Error(`fromHTML must create one and only one element (possibly with many children, found ${result})`);
    return result[0];
}
function appendChildren(root, children) {
    children.forEach(child => root.appendChild(child));
}
function waitForElement(selector, callback, checkFrequencyInMs = 10, timeoutInMs = 15000, failure_callback = undefined) {
    var startTimeInMs = Date.now();
    (function loopSearch() {
        const element = document.querySelector(selector);
        if (element) {
            callback(element);
        }
        else {
            setTimeout(function () {
                const elapsed = Date.now() - startTimeInMs;
                if (timeoutInMs && elapsed > timeoutInMs) {
                    if (failure_callback) {
                        failure_callback();
                    }
                }
                else {
                    loopSearch();
                }
            }, checkFrequencyInMs);
        }
    })();
}
function propagateOnChange(element) {
    var event = new Event('change', { bubbles: true });
    element.dispatchEvent(event);
}
function cleanPropagate(e) {
    e.value = "";
    propagateOnChange(e);
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./themes */ "./src/themes.ts");
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _form_renglones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form_renglones */ "./src/form_renglones.ts");
/* harmony import */ var _autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./autofill_ui/autofill_ui */ "./src/autofill_ui/autofill_ui.ts");





(0,_settings__WEBPACK_IMPORTED_MODULE_0__.initializeSettings)(() => {
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__.ready)(_themes__WEBPACK_IMPORTED_MODULE_1__.initializeThemeChooser);
    (0,_form_renglones__WEBPACK_IMPORTED_MODULE_3__.when_form_renglones_ready)(_autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_4__.addAutofillUI, 1000, 10);
    // when_form_renglones_ready(add_row_buttons)
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBbUQ7QUFDbkQ7QUFDQTtBQUNBLHFDQUFxQyxRQUFRO0FBQzdDO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQyxpQ0FBaUM7QUFDakMsSUFBSSxnRUFBYztBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2Qyw2QkFBNkI7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBLGtEQUFrRCw4QkFBOEI7QUFDaEY7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLDJDQUEyQztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUNPLG1CQUFtQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQSwrQkFBK0IsY0FBYyxXQUFXO0FBQ3hEO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxrQkFBa0I7QUFDdkU7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDNkM7QUFDUztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxrQkFBa0I7QUFDeEQsSUFBSSxzREFBVztBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSwyQkFBMkIsUUFBUTtBQUNuQztBQUNBO0FBQ0Esc0JBQXNCLDBEQUFRO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixzREFBVztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHdDQUF3QyxrREFBa0Q7QUFDakc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5R0FBeUcsT0FBTztBQUNoSDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsS0FBSztBQUNMO0FBQ087QUFDUCxzQ0FBc0MsZUFBZTtBQUNyRDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7Ozs7Ozs7VUNwRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTmdEO0FBQ0U7QUFDUjtBQUNtQjtBQUNIO0FBQzFELDZEQUFrQjtBQUNsQixJQUFJLHVEQUFLLENBQUMsMkRBQXNCO0FBQ2hDLElBQUksMEVBQXlCLENBQUMsbUVBQWE7QUFDM0M7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvZm9ybV9yZW5nbG9uZXMudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvc2V0dGluZ3MudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvdGhlbWVzLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL3V0aWxzL2RvbV91dGlscy50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHdhaXRGb3JFbGVtZW50IH0gZnJvbSBcIi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5jb25zdCBmb3JtX3Jlbmdsb25lc19zZWxlY3RvciA9IFwiLmZvcm0tcmVuZ2xvbmVzXCI7XG5mdW5jdGlvbiBmYWlsZWRfY2FsbGJhY2sodGltZW91dCkge1xuICAgIGNvbnNvbGUubG9nKGBhZnRlciB3YWl0aW5nIGZvciAke3RpbWVvdXR9LCBhc3N1bWluZyB0aGVyZSdzIG5vIGZvcm0gaW4gcGFnZS5gKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3aGVuX2Zvcm1fcmVuZ2xvbmVzX3JlYWR5KGNhbGxiYWNrLCB0aW1lb3V0ID0gNTAwMCwgYWRkaXRpb25hbF93YWl0ID0gMTApIHtcbiAgICBjb25zdCBmb3JtQ2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1fcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihmb3JtX3Jlbmdsb25lc19zZWxlY3Rvcik7XG4gICAgICAgIGNhbGxiYWNrKGZvcm1fcmVuZ2xvbmVzKTtcbiAgICB9O1xuICAgIGNvbnN0IGZhaWxDYWxsYmFjayA9ICgpID0+IHsgZmFpbGVkX2NhbGxiYWNrKHRpbWVvdXQpOyB9O1xuICAgIGNvbnN0IHdhaXRDYWxsYmFjayA9ICgpID0+IHsgc2V0VGltZW91dChmb3JtQ2FsbGJhY2ssIGFkZGl0aW9uYWxfd2FpdCk7IH07XG4gICAgd2FpdEZvckVsZW1lbnQoZm9ybV9yZW5nbG9uZXNfc2VsZWN0b3IsIHdhaXRDYWxsYmFjaywgdGltZW91dCwgdW5kZWZpbmVkLCBmYWlsQ2FsbGJhY2spO1xufVxuLy8gZnVuY3Rpb24gd2hlbl9mb3JtX3Jlbmdsb25lc19yZWFkeV9vbGQobGlzdGVuZXJzKXtcbi8vICAgICBjb25zdCBjb2x1bW5hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjb2x1bW5hXzFcIik7XG4vLyAgICAgICBpZiAoIWNvbHVtbmEpIHtcbi8vICAgICAgICAgY29uc29sZS5sb2coXCIjQ29sdW1uYV8xIG5vdCBmb3VuZDsgbm90IGEgc3R1ZGVudHMgZm9ybS5cIilcbi8vICAgICAgICAgcmV0dXJuICBcbi8vICAgICB9XG4vLyAgICAgY29uc29sZS5sb2coXCJSZWdpc3RlcmluZyB0byBhZGQgc2F2ZSBidXR0b25cIilcbi8vICAgICBjb25zb2xlLmxvZyhjb2x1bW5hKVxuLy8gICAgIG9ic2VydmUoY29sdW1uYSx3aGVuX2NvbHVtbmFfY2hhbmdlcyx7Y2hpbGRMaXN0OnRydWUsc3VidHJlZTp0cnVlIH0sZGlzYWJsZUFmdGVyRmlyc3Q9ZmFsc2UscGFyYW1zPWxpc3RlbmVycylcbi8vICAgfVxuLy8gZnVuY3Rpb24gd2hlbl9jb2x1bW5hX2NoYW5nZXMob2JzZXJ2ZXIsbGlzdGVuZXJzKXtcbi8vICAgY29uc3QgcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyZW5nbG9uZXNcIik7XG4vLyAgIGlmIChyZW5nbG9uZXMpIHtcbi8vICAgICBjb25zb2xlLmxvZyhcInJlbmdsb25lcyBmb3VuZDsgYWRkaW5nIG11dGF0aW9uIG9ic2VydmVyXCIpXG4vLyAgICAgY29uc29sZS5sb2cocmVuZ2xvbmVzKVxuLy8gICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxuLy8gICAgIG9ic2VydmUocmVuZ2xvbmVzLHdoZW5fcmVuZ2xvbmVzX2NoYW5nZXMseyBzdWJ0cmVlOiB0cnVlLGNoaWxkTGlzdDp0cnVlIH0sdHJ1ZSxsaXN0ZW5lcnMpICAgICAgICBcbi8vICAgfVxuLy8gfVxuZXhwb3J0IGZ1bmN0aW9uIHdoZW5fcmVuZ2xvbmVzX2NoYW5nZXMob2JzZXJ2ZXIsIGxpc3RlbmVycykge1xuICAgIGNvbnN0IGZvcm1fcmVuZ2xvbmVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5mb3JtLXJlbmdsb25lc1wiKTtcbiAgICBpZiAoZm9ybV9yZW5nbG9uZXMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGb3JtIHJlbmdsb25lcyBmb3VuZDsgYWRkaW5nIGJ1dHRvblwiKTtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICBsaXN0ZW5lcnMuZm9yRWFjaChsaXN0ZW5lciA9PiBsaXN0ZW5lcihmb3JtX3Jlbmdsb25lcykpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGb3JtIHJlbmdsb25lcyBub3QgZm91bmRcIik7XG4gICAgICAgIGNvbnNvbGUubG9nKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcmVuZ2xvbmVzXCIpKTtcbiAgICB9XG59XG4iLCJleHBvcnQgY29uc3QgU2V0dGluZ3MgPSB7IE1pc3NpbmdTdHVkZW50czogXCJtaXNzaW5nU3R1ZGVudHNcIixcbiAgICBUaGVtZTogXCJ0aGVtZVwiLFxuICAgIERhdGU6IFwiZGF0ZVwiLFxuICAgIE92ZXJ3cml0ZU9uQXV0b2ZpbGw6IFwib3ZlcndyaXRlT25BdXRvZmlsbFwiLFxuICAgIEF1dG9maWxsRGF0YTogXCJhdXRvZmlsbERhdGFcIixcbiAgICBBdXRvZmlsbERhdGFDU1Y6IFwiYXV0b2ZpbGxEYXRhQ1NWXCIsXG4gICAgVW5tYXRjaGVkOiBcInVubWF0Y2hlZFwiXG59O1xudmFyIF9zZXR0aW5ncyA9IHsgW1NldHRpbmdzLkRhdGVdOiAnMDEvMDEvMjAyNCcsXG4gICAgW1NldHRpbmdzLlRoZW1lXTogXCJkYXJrXCIsXG4gICAgW1NldHRpbmdzLk92ZXJ3cml0ZU9uQXV0b2ZpbGxdOiBmYWxzZSxcbiAgICBbU2V0dGluZ3MuQXV0b2ZpbGxEYXRhQ1NWXTogXCJcIixcbiAgICBbU2V0dGluZ3MuQXV0b2ZpbGxEYXRhXToge30sXG4gICAgdW5tYXRjaGVkOiBbXSxcbn07XG5leHBvcnQgZnVuY3Rpb24gZ2V0U2V0dGluZ3Moa2V5KSB7XG4gICAgcmV0dXJuIF9zZXR0aW5nc1trZXldO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNldFNldHRpbmdzKGtleSwgdmFsdWUpIHtcbiAgICBfc2V0dGluZ3Nba2V5XSA9IHZhbHVlO1xuICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9LCAoKSA9PiB7IH0pO1xufVxuO1xuZXhwb3J0IGZ1bmN0aW9uIGluaXRpYWxpemVTZXR0aW5ncyhjYWxsYmFjaykge1xuICAgIGNvbnNvbGUubG9nKGBJbml0aWFsaXppbmcgc2V0dGluZ3MuLi5gKTtcbiAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoX3NldHRpbmdzLCAodikgPT4ge1xuICAgICAgICAvLyBjb3B5IGV4aXN0aW5nIHZhbHVlcyBmcm9tIGxvY2FsIHN0b3JhZ2VcbiAgICAgICAgZm9yIChjb25zdCBrIGluIHYpIHtcbiAgICAgICAgICAgIF9zZXR0aW5nc1trXSA9IHZba107XG4gICAgICAgIH1cbiAgICAgICAgLy8gY29uc29sZS5sb2coYEluaXRpYWxpemVkIHdpdGggc2V0dGluZ3M6ICR7T2JqZWN0LmVudHJpZXModil9YClcbiAgICAgICAgY2FsbGJhY2soKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IGZyb21IVE1MIH0gZnJvbSBcIi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5pbXBvcnQgeyBzZXRTZXR0aW5ncywgZ2V0U2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiO1xuZnVuY3Rpb24gYWRkQ1NTKGhyZWYpIHtcbiAgICB2YXIgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgncmVsJywgJ3N0eWxlc2hlZXQnKTtcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xuICAgIGxpbmsuc2V0QXR0cmlidXRlKCd0eXBlJywgXCJ0ZXh0L2Nzc1wiKTtcbiAgICAvLyBsaW5rLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCBcImRpc2FibGVkXCIpO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgcmV0dXJuIGxpbms7XG59XG5mdW5jdGlvbiB1cGRhdGVUaGVtZShkYXJrLCB0aGVtZUJ1dHRvbikge1xuICAgIGNvbnNvbGUubG9nKGBDaGFuZ2luZyB0aGVtZSB0byBcIiR7dGhlbWVCdXR0b24udmFsdWV9XCJgKTtcbiAgICBzZXRTZXR0aW5ncyhcInRoZW1lXCIsIHRoZW1lQnV0dG9uLnZhbHVlKTtcbiAgICAvLyBjb25zb2xlLmxvZyhnZXRTZXR0aW5ncyhcInRoZW1lXCIpKVxuICAgIGlmICh0aGVtZUJ1dHRvbi52YWx1ZSA9PSBcImRhcmtcIikge1xuICAgICAgICBkYXJrLmRpc2FibGVkID0gZmFsc2U7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBkYXJrLmRpc2FibGVkID0gdHJ1ZTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZVRoZW1lQ2hvb3NlcigpIHtcbiAgICBjb25zb2xlLmxvZyhgaW5pdGlhbGl6aW5nIHRoZW1lIGNob29zZXJgKTtcbiAgICBjb25zdCBkYXJrVXJsID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwidGhlbWVzL2RhcmsuY3NzXCIpO1xuICAgIGNvbnNvbGUubG9nKGBMb2FkaW5nICR7ZGFya1VybH1gKTtcbiAgICBsZXQgZGFyayA9IGFkZENTUyhkYXJrVXJsKTtcbiAgICBjb25zdCBwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBsZXQgdGhlbWVTZWxlY3QgPSBmcm9tSFRNTChgPHNlbGVjdCB0eXBlPVwidGV4dFwiIG5hbWU9XCJ0aGVtZVwiIGlkPVwidGhlbWVcIj5cbiAgICA8b3B0aW9uIHZhbHVlPVwibGlnaHRcIj5DbGFybyDwn4yVPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cImRhcmtcIj5Pc2N1cm8g8J+MkTwvb3B0aW9uPlxuICAgIDwvc2VsZWN0PmApO1xuICAgIHRoZW1lU2VsZWN0LnZhbHVlID0gZ2V0U2V0dGluZ3MoXCJ0aGVtZVwiKTtcbiAgICBsZXQgbm90aWZpY2F0aW9ucyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIubm90aWZpY2FjaW9uZXNcIik7XG4gICAgaWYgKG5vdGlmaWNhdGlvbnMpIHtcbiAgICAgICAgbm90aWZpY2F0aW9ucy5hcHBlbmRDaGlsZCh0aGVtZVNlbGVjdCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhgRGlkIG5vdCBmaW5kIGVsZW1lbnQgXCIubm90aWZpY2FjaW9uZXNcIiB0byBhcHBlbmQgdGhlIHRoZW1lIGNob29zZXJgKTtcbiAgICB9XG4gICAgdGhlbWVTZWxlY3QuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKGV2ZW50KSA9PiB1cGRhdGVUaGVtZShkYXJrLCB0aGVtZVNlbGVjdCkpO1xuICAgIHVwZGF0ZVRoZW1lKGRhcmssIHRoZW1lU2VsZWN0KTtcbn1cbiIsImV4cG9ydCBjbGFzcyBVSSB7XG4gICAgdXBkYXRlKCkge1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiByZWFkeShmbikge1xuICAgIGlmIChkb2N1bWVudC5yZWFkeVN0YXRlICE9PSAnbG9hZGluZycpIHtcbiAgICAgICAgZm4oKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgZm4pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG9ic2VydmUoZWxlbWVudCwgZiwgY29uZmlnID0geyBzdWJ0cmVlOiB0cnVlLCBjaGlsZExpc3Q6IHRydWUsIGF0dHJpYnV0ZXM6IHRydWUgfSwgZGlzYWJsZUFmdGVyRmlyc3QgPSB0cnVlLCBwYXJhbXMgPSBbXSkge1xuICAgIGNvbnN0IG11dGF0aW9uT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlQWZ0ZXJGaXJzdCkge1xuICAgICAgICAgICAgbXV0YXRpb25PYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICAgIH1cbiAgICAgICAgZihtdXRhdGlvbk9ic2VydmVyLCBwYXJhbXMpO1xuICAgIH0pO1xuICAgIG11dGF0aW9uT2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50LCBjb25maWcpO1xuICAgIHJldHVybiBtdXRhdGlvbk9ic2VydmVyO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21IVE1MKGh0bWwsIHRyaW0gPSB0cnVlKSB7XG4gICAgLy8gUHJvY2VzcyB0aGUgSFRNTCBzdHJpbmcuXG4gICAgaHRtbCA9IHRyaW0gPyBodG1sIDogaHRtbC50cmltKCk7XG4gICAgaWYgKCFodG1sKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAvLyBUaGVuIHNldCB1cCBhIG5ldyB0ZW1wbGF0ZSBlbGVtZW50LlxuICAgIGNvbnN0IHRlbXBsYXRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGVtcGxhdGUnKTtcbiAgICB0ZW1wbGF0ZS5pbm5lckhUTUwgPSBodG1sO1xuICAgIGNvbnN0IHJlc3VsdCA9IHRlbXBsYXRlLmNvbnRlbnQuY2hpbGRyZW47XG4gICAgLy8gVGhlbiByZXR1cm4gZWl0aGVyIGFuIEhUTUxFbGVtZW50IG9yIEhUTUxDb2xsZWN0aW9uLFxuICAgIC8vIGJhc2VkIG9uIHdoZXRoZXIgdGhlIGlucHV0IEhUTUwgaGFkIG9uZSBvciBtb3JlIHJvb3RzLlxuICAgIGlmIChyZXN1bHQubGVuZ3RoICE9PSAxKVxuICAgICAgICB0aHJvdyBFcnJvcihgZnJvbUhUTUwgbXVzdCBjcmVhdGUgb25lIGFuZCBvbmx5IG9uZSBlbGVtZW50IChwb3NzaWJseSB3aXRoIG1hbnkgY2hpbGRyZW4sIGZvdW5kICR7cmVzdWx0fSlgKTtcbiAgICByZXR1cm4gcmVzdWx0WzBdO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGFwcGVuZENoaWxkcmVuKHJvb3QsIGNoaWxkcmVuKSB7XG4gICAgY2hpbGRyZW4uZm9yRWFjaChjaGlsZCA9PiByb290LmFwcGVuZENoaWxkKGNoaWxkKSk7XG59XG5leHBvcnQgZnVuY3Rpb24gd2FpdEZvckVsZW1lbnQoc2VsZWN0b3IsIGNhbGxiYWNrLCBjaGVja0ZyZXF1ZW5jeUluTXMgPSAxMCwgdGltZW91dEluTXMgPSAxNTAwMCwgZmFpbHVyZV9jYWxsYmFjayA9IHVuZGVmaW5lZCkge1xuICAgIHZhciBzdGFydFRpbWVJbk1zID0gRGF0ZS5ub3coKTtcbiAgICAoZnVuY3Rpb24gbG9vcFNlYXJjaCgpIHtcbiAgICAgICAgY29uc3QgZWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgICAgICBpZiAoZWxlbWVudCkge1xuICAgICAgICAgICAgY2FsbGJhY2soZWxlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIHN0YXJ0VGltZUluTXM7XG4gICAgICAgICAgICAgICAgaWYgKHRpbWVvdXRJbk1zICYmIGVsYXBzZWQgPiB0aW1lb3V0SW5Ncykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmFpbHVyZV9jYWxsYmFjaykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmFpbHVyZV9jYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBsb29wU2VhcmNoKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgY2hlY2tGcmVxdWVuY3lJbk1zKTtcbiAgICAgICAgfVxuICAgIH0pKCk7XG59XG5leHBvcnQgZnVuY3Rpb24gcHJvcGFnYXRlT25DaGFuZ2UoZWxlbWVudCkge1xuICAgIHZhciBldmVudCA9IG5ldyBFdmVudCgnY2hhbmdlJywgeyBidWJibGVzOiB0cnVlIH0pO1xuICAgIGVsZW1lbnQuZGlzcGF0Y2hFdmVudChldmVudCk7XG59XG5leHBvcnQgZnVuY3Rpb24gY2xlYW5Qcm9wYWdhdGUoZSkge1xuICAgIGUudmFsdWUgPSBcIlwiO1xuICAgIHByb3BhZ2F0ZU9uQ2hhbmdlKGUpO1xufVxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgeyBpbml0aWFsaXplU2V0dGluZ3MgfSBmcm9tIFwiLi9zZXR0aW5nc1wiO1xuaW1wb3J0IHsgaW5pdGlhbGl6ZVRoZW1lQ2hvb3NlciB9IGZyb20gXCIuL3RoZW1lc1wiO1xuaW1wb3J0IHsgcmVhZHkgfSBmcm9tIFwiLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkgfSBmcm9tIFwiLi9mb3JtX3Jlbmdsb25lc1wiO1xuaW1wb3J0IHsgYWRkQXV0b2ZpbGxVSSB9IGZyb20gXCIuL2F1dG9maWxsX3VpL2F1dG9maWxsX3VpXCI7XG5pbml0aWFsaXplU2V0dGluZ3MoKCkgPT4ge1xuICAgIHJlYWR5KGluaXRpYWxpemVUaGVtZUNob29zZXIpO1xuICAgIHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkoYWRkQXV0b2ZpbGxVSSwgMTAwMCwgMTApO1xuICAgIC8vIHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkoYWRkX3Jvd19idXR0b25zKVxufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=