"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeSettings = exports.setSettings = exports.getSettings = exports.Settings = void 0;
exports.Settings = { MissingStudents: "missingStudents",
    Theme: "theme",
    Date: "date",
    OverwriteOnAutofill: "overwriteOnAutofill",
    AutofillData: "autofillData",
    AutofillDataCSV: "autofillDataCSV"
};
var _settings = (_a = { date: '01/01/2024',
        theme: "dark",
        overwriteOnAutofill: false }, _a[exports.Settings.AutofillDataCSV] = "", _a[exports.Settings.AutofillData] = {}, _a.unmatched = [], _a);
function getSettings(key) {
    return _settings[key];
}
exports.getSettings = getSettings;
function setSettings(key, value) {
    var _a;
    _settings[key] = value;
    chrome.storage.local.set((_a = {}, _a[key] = value, _a), function () { });
}
exports.setSettings = setSettings;
;
function initializeSettings(callback) {
    console.log("Initializing settings...");
    chrome.storage.local.get(_settings, function (v) {
        // copy existing values from local storage
        for (var k in v) {
            _settings[k] = v[k];
        }
        // console.log(`Initialized with settings: ${Object.entries(v)}`)
        callback();
    });
}
exports.initializeSettings = initializeSettings;
//# sourceMappingURL=settings.js.map