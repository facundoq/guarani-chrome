"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutofillConfigUI = void 0;
var settings_1 = require("./settings");
var csv_parser_1 = require("./csv_parser");
// import {csv2autofillData} from "./csv_parser"
function autofillDataToString(autofillData, k) {
    var n = autofillData.length;
    k = Math.min(n, k);
    var samples = "";
    var i = 0;
    for (var _i = 0, _a = autofillData.entries(); _i < _a.length; _i++) {
        var _b = _a[_i], key = _b[0], values = _b[1];
        if (i == k) {
            break;
        }
        i = i + 1;
        var sample = "";
        for (var _c = 0, _d = values.entries(); _c < _d.length; _c++) {
            var _e = _d[_c], sampleKey = _e[0], sampleValue = _e[1];
            sample = sample.concat("".concat(sampleKey, "=").concat(sampleValue, ", "));
        }
        samples = samples.concat("\n".concat(key, ": ").concat(sample));
    }
    return samples;
}
function AutofillDataViewer(max_rows) {
    if (max_rows === void 0) { max_rows = 5; }
    var root = document.createElement("textarea");
    root.disabled = true;
    root.textContent = "No hay datos cargados";
    root["update"] = function () {
        var autofillData = (0, settings_1.getSettings)("autofillData");
        if (autofillData && autofillData.length > 0) {
            root.value = "".concat(autofillDataToString(autofillData, max_rows), "\n...\nTotal: ").concat(autofillData.length, " filas.\n");
        }
        else {
            root.value = "No hay datos guardados.";
        }
    };
    return root;
}
// function AutofillMissingUI() {
//     const root = document.createElement("div")
//     root.id = "autofillMissingUI"
//     const deleteButton = fromHTML(`<button  type="button" id="autofillDeleteMissingButton"> Borrar faltantes </button>`)
//     const textarea = fromHTML(`<textarea id="autofillMissingViewer" disabled="true">
//     </textarea>`)
//     root.update = () => {
//         const missingStudents = getSettings("missingStudents")
//         if (missingStudents) {
//             textarea.value = missingStudents;
//             deleteButton.disabled = false;
//         } else {
//             textarea.value = "No hay datos guardados."
//             deleteButton.disabled = true;
//         }
//     }
//     deleteButton.onclick = (e) => {
//         setSettings("missingStudents", [])
//         root.update()
//     }
//     root.appendChild(textarea)
//     root.appendChild(deleteButton)
//     return root
// }
function autofillSubmit(autofillDataViewer, resultViewer, autofillDataInput, autofillStartButton) {
    resultViewer.innerHTML = "Cargando...";
    var data = autofillDataInput.value;
    var result = (0, csv_parser_1.csv2autofillData)(data);
    result.doLeft(function (errors) {
        resultViewer.innerHTML = "Errores en el csv: \n\n           ".concat(errors, "\n");
        (0, settings_1.setSettings)(settings_1.Settings.AutofillData, []);
        autofillDataViewer.update();
    });
    result.doRight(function (_a) {
        var autofillData = _a[0], header = _a[1];
        (0, settings_1.setSettings)("autofillData", autofillData);
        resultViewer.innerHTML = "Carga exitosa, ".concat(autofillData.length, " Filas \n ").concat(header.length, " Columnas:  ").concat(header.join(", "));
        autofillDataViewer.update();
        autofillStartButton.update();
    });
}
function validateAutofillData(autofillData) {
    if (!autofillData.value) {
        return false;
    }
    else {
        return autofillData.value.trim().length > 0;
    }
}
function AutofillOverwriteConfigUI(onchangeCallback) {
    var root = fromHTML("<div id=\"autofillOverwrite\"></div>");
    var labelTitle = "Sobreescribir valores (notas, condición, fecha, etc) existentes al rellenar.";
    var label = fromHTML("<label title=\"".concat(labelTitle, "\" style=\"display:inline;\">Sobreescribir valores: </label>"));
    var checkbox = fromHTML("<input type=\"checkbox\" id=\"autofillOverwriteCheckbox\"/>");
    checkbox.onchange = function (e) {
        onchangeCallback(checkbox.checked);
    };
    root.appendChild(label);
    root.appendChild(checkbox);
    checkbox.checked = (0, settings_1.getSettings)("overwriteOnAutofill");
    return root;
}
function AutofillConfigUI(autofillStartButton) {
    var root = fromHTML("<div id=\"autofillConfig\" ></div>");
    var labelTitle = "El CSV requiere como m\u00EDnimo una columna de identificaci\u00F3n y una columna de datos:\n\n      Cols. de identificaci\u00F3n: ".concat(csv_parser_1.csvConfig.keyColumns, "\n      Cols. de datos: ").concat(csv_parser_1.csvConfig.dataColumns, "\n      ");
    var autofillDataCSV = (0, settings_1.getSettings)("autofillDataCSV");
    var label = fromHTML("<label for=\"autofillInput\" style=\"display:block\" title=\"".concat(labelTitle, "\">Carga de CSV para autollenado \uD83D\uDEC8:</label>"));
    var autofillDataInput = fromHTML("\n      <textarea type=\"text\" name=\"autofill\" \n      id=\"autofillInput\">".concat(autofillDataCSV, "</textarea>"));
    var resultLabel = fromHTML("<p\">Resultado de la carga:</p>");
    var resultViewer = fromHTML("<pre></pre>");
    var autofillDataViewerLabel = fromHTML("<p style=\"display:block\">Datos cargados actualmente:</p>");
    var autofillDataViewer = AutofillDataViewer();
    var inputUpdate = function () {
        (0, settings_1.setSettings)(settings_1.Settings.AutofillDataCSV, autofillDataInput.textContent);
        autofillSubmit(autofillDataViewer, resultViewer, autofillDataInput, autofillStartButton);
    };
    autofillDataInput.onchange = inputUpdate;
    autofillDataInput.addEventListener('input', inputUpdate);
    inputUpdate();
    var autofillOverwriteConfigUI = AutofillOverwriteConfigUI(function (value) {
        (0, settings_1.setSettings)("overwriteOnAutofill", value);
    });
    appendChildren(root, [autofillOverwriteConfigUI, label, autofillDataInput, resultLabel, resultViewer, autofillDataViewerLabel, autofillDataViewer,]);
    autofillDataViewer.update();
    return root;
}
exports.AutofillConfigUI = AutofillConfigUI;
//# sourceMappingURL=autofill_config_ui.js.map