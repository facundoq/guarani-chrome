"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var settings_1 = require("./settings");
var themes_1 = require("./themes");
(0, settings_1.initializeSettings)(function () {
    ready(themes_1.initializeThemeChooser);
    // when_form_renglones_ready(addAutofillUI,1000,10);
    // when_form_renglones_ready(add_row_buttons)
});
//# sourceMappingURL=main.js.map