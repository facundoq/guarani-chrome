function add_save_button(form_renglones) {
    var basic_save_button = document.querySelector("#js-btn-guardar");
    var save_button = document.createElement("input");
    save_button.type = "submit";
    save_button.value = "Guardar";
    save_button.classList.add("btn ", "btn-info", "btn-small", "pull-right");
    save_button.id = "js-btn-guardar";
    save_button.onclick = function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    form_renglones.appendChild(save_button);
    var update = function () { save_button.disabled = basic_save_button.disabled; };
    observe(basic_save_button, update, { attributes: true, subtree: true, childList: true, }, false);
}
when_form_renglones_ready(add_save_button);
//# sourceMappingURL=save_button.js.map