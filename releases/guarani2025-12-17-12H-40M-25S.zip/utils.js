"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Right = exports.Left = exports.Either = exports.None = exports.Some = exports.Optional = exports.listOfDictToDictOfDict = exports.dictFromLists = exports.intersection = exports.zip = void 0;
var zip = function (a, b) { return a.map(function (k, i) { return [k, b[i]]; }); };
exports.zip = zip;
function intersection(a, b) { return a.filter(function (value) { return b.includes(value); }); }
exports.intersection = intersection;
function dictFromLists(keys, vals) {
    var dict = new Map();
    (0, exports.zip)(keys, vals).forEach(function (kv) {
        var k = kv[0], v = kv[1];
        dict.set(k, v);
    });
    return dict;
}
exports.dictFromLists = dictFromLists;
function listOfDictToDictOfDict(rows, key) {
    if (key === void 0) { key = "dni"; }
    var keys = rows.map(function (row) { return row.get(key); });
    return dictFromLists(keys, rows);
}
exports.listOfDictToDictOfDict = listOfDictToDictOfDict;
var Optional = /** @class */ (function () {
    function Optional() {
    }
    return Optional;
}());
exports.Optional = Optional;
var Some = /** @class */ (function (_super) {
    __extends(Some, _super);
    function Some(x) {
        var _this = _super.call(this) || this;
        _this.x = x;
        return _this;
    }
    Some.prototype.get = function () { return this.x; };
    Some.prototype.map = function (f) { return new Some(f(this.x)); };
    Some.prototype.flatMap = function (f) { return f(this.x); };
    Some.prototype.doSome = function (f) { f(this.x); };
    Some.prototype.doNone = function (f) { };
    Some.prototype.isNone = function () { return false; };
    Some.prototype.isSome = function () { return true; };
    return Some;
}(Optional));
exports.Some = Some;
var None = /** @class */ (function (_super) {
    __extends(None, _super);
    function None() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    None.prototype.map = function (f) { return f(this); };
    None.prototype.flatMap = function (f) { this; };
    None.prototype.doSome = function (f) { };
    None.prototype.doNone = function (f) { f(); };
    None.prototype.isNone = function () { return true; };
    None.prototype.isSome = function () { return false; };
    return None;
}(Optional));
exports.None = None;
var Either = /** @class */ (function () {
    function Either() {
    }
    Either.Left = function (v) { return new Left(v); };
    Either.Right = function (v) { return new Right(v); };
    Either.if = function (condition, valueLeft, valueRight) { return (condition) ? Either.Right(valueRight) : Either.Left(valueLeft); };
    return Either;
}());
exports.Either = Either;
var Left = /** @class */ (function (_super) {
    __extends(Left, _super);
    function Left(val) {
        var _this = _super.call(this) || this;
        _this._val = val;
        return _this;
    }
    Left.prototype.isLeft = function () {
        return true;
    };
    Left.prototype.isRight = function () {
        return false;
    };
    Left.prototype.doLeft = function (f) {
        f(this._val);
    };
    Left.prototype.doRight = function (f) {
    };
    Left.prototype.map = function () {
        // Left is the sad path
        // so we do nothing
        return this;
    };
    Left.prototype.join = function () {
        // On the sad path, we don't
        // do anything with join
        return this;
    };
    Left.prototype.chain = function () {
        // Boring sad path,
        // do nothing.
        return this;
    };
    Left.prototype.get = function () {
        return this._val;
    };
    Left.prototype.toString = function () {
        var str = this._val.toString();
        return "Left(".concat(str, ")");
    };
    return Left;
}(Either));
exports.Left = Left;
/**
*Right represents the happy path
*/
var Right = /** @class */ (function (_super) {
    __extends(Right, _super);
    function Right(val) {
        var _this = _super.call(this) || this;
        _this._val = val;
        return _this;
    }
    Right.prototype.isLeft = function () {
        return false;
    };
    Right.prototype.isRight = function () {
        return true;
    };
    Right.prototype.doLeft = function (f) {
    };
    Right.prototype.doRight = function (f) {
        f(this._val);
    };
    Right.prototype.map = function (fn) {
        return new Right(fn(this._val));
    };
    Right.prototype.join = function () {
        if ((this._val instanceof Left)
            || (this._val instanceof Right)) {
            return this._val;
        }
        return this;
    };
    Right.prototype.chain = function (fn) {
        return fn(this._val);
    };
    Right.prototype.get = function () {
        return this._val;
    };
    Right.prototype.toString = function () {
        var str = this._val.toString();
        return "Right(".concat(str, ")");
    };
    return Right;
}(Either));
exports.Right = Right;
//# sourceMappingURL=utils.js.map