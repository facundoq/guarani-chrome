/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/autofill/autofill.ts":
/*!**********************************!*\
  !*** ./src/autofill/autofill.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillCursada: () => (/* binding */ AutofillCursada),
/* harmony export */   AutofillFinal: () => (/* binding */ AutofillFinal),
/* harmony export */   BaseAutofill: () => (/* binding */ BaseAutofill)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
/* harmony import */ var _guarani_StudentCursada__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../guarani/StudentCursada */ "./src/guarani/StudentCursada.ts");
/* harmony import */ var _guarani_StudentFinal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../guarani/StudentFinal */ "./src/guarani/StudentFinal.ts");



function dniMatcher(student, data) {
    const matches = data.rows.filter((s) => s.get("dni") == student.dni);
    if (matches.length === 1) {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(matches[0]);
    }
    else {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(matches);
    }
}
class BaseAutofill {
    constructor(parser, subjectName) {
        this.parser = parser;
        this.subjectName = subjectName;
    }
    parse(csv) {
        const result = this.parser.parse(csv);
        return result;
    }
    autofill(rowsElement, autofillData, overwrite, matcher = dniMatcher) {
        const students = this.getStudents(rowsElement);
        const unmatched = [];
        for (let student of students) {
            const studentFormEmpty = student.isEmpty;
            if (!overwrite && !studentFormEmpty) {
                student.markAlreadyFilledStudent();
                continue;
            }
            const studentDataResult = matcher(student, autofillData);
            studentDataResult.doRight((studentData) => {
                this.autofillStudent(student, studentData);
                if (studentFormEmpty) {
                    student.markFilledStudent();
                }
                else {
                    student.markOverwrittenStudent();
                }
            });
            studentDataResult.doLeft((matches) => {
                if (studentFormEmpty) {
                    student.markUnmatchedStudent(matches);
                    unmatched.push(student.dni);
                }
                else {
                    student.markAlreadyFilledStudent();
                }
            });
        }
        return unmatched;
    }
    autofillStudent(student, studentData) {
        this.parser.config.dataColumns.forEach((column) => {
            if (studentData.has(column)) {
                const autofillValue = this.convertValues(studentData.get(column), column);
                const element = student.getFillableFieldElement(column);
                element.value = autofillValue;
                var event = new Event("change");
                element.dispatchEvent(event);
            }
        });
    }
    convertValues(value, column) {
        // TODO test alternative
        if (column in this.parser.config.values) {
            return this.parser.config.values[column][value];
        }
        else {
            return value;
        }
    }
}
class AutofillCursada extends BaseAutofill {
    constructor() {
        super(...arguments);
        this.operationType = "cursada";
    }
    getStudents(rowsElement) {
        return Array.from(rowsElement.map(r => new _guarani_StudentCursada__WEBPACK_IMPORTED_MODULE_1__.StudentCursada(r)));
    }
}
class AutofillFinal extends BaseAutofill {
    constructor() {
        super(...arguments);
        this.operationType = "final";
    }
    getStudents(rowsElement) {
        return Array.from(rowsElement.map(r => new _guarani_StudentFinal__WEBPACK_IMPORTED_MODULE_2__.StudentFinal(r)));
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_config_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_config_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillConfigUI: () => (/* binding */ AutofillConfigUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _autofill_overwrite_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./autofill_overwrite_ui */ "./src/autofill_ui/autofill_overwrite_ui.ts");
/* harmony import */ var _autofill_result_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./autofill_result_ui */ "./src/autofill_ui/autofill_result_ui.ts");
/* harmony import */ var _autofill_input_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./autofill_input_ui */ "./src/autofill_ui/autofill_input_ui.ts");




class AutofillConfigUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(autofill, onParseCallback, settings) {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<div id="autofillConfig" ></div>`);
        const inputCSV = settings.getAutofillData(autofill.operationType, autofill.subjectName);
        const autofillResultUI = new _autofill_result_ui__WEBPACK_IMPORTED_MODULE_2__.AutofillResultUI(5);
        const inputUpdate = (inputCSV) => {
            settings.setAutofillData(autofill.operationType, autofill.subjectName, inputCSV);
            settings.save();
            this.data = autofill.parse(inputCSV);
            autofillResultUI.update(this.data);
            onParseCallback(this.data);
        };
        const inputUI = new _autofill_input_ui__WEBPACK_IMPORTED_MODULE_3__.AutofillInputUI(inputCSV, inputUpdate, autofill.parser.config.keyColumns, autofill.parser.config.dataColumns);
        const autofillOverwriteConfigUI = new _autofill_overwrite_ui__WEBPACK_IMPORTED_MODULE_1__.AutofillOverwriteConfigUI(settings);
        (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.appendChildren)(this.root, [autofillOverwriteConfigUI.root, inputUI.root, autofillResultUI.root]);
        inputUpdate(inputCSV);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_input_ui.ts":
/*!**********************************************!*\
  !*** ./src/autofill_ui/autofill_input_ui.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillInputUI: () => (/* binding */ AutofillInputUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class AutofillInputUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(inputCSV, changeCallback, keyColumns, dataColumns) {
        super();
        this.root = document.createElement("div");
        this.root.id = "autofillInputUI";
        const labelTitle = `El formato de entrada es de un CSV, con campos separados por el carácter ';'.\nSe requiere como mínimo una columna de identificación y una columna de datos:\n
      Columnas de identificación: ${keyColumns}.
      Columnas de datos: ${dataColumns}.
      `;
        const label = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<label for="autofillInput" style="display:block" title="${labelTitle}">Carga de CSV para autollenado 🛈:</label>`);
        const autofillDataInput = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`
        <textarea type="text" name="autofill" 
        id="autofillInput">${inputCSV}</textarea>`);
        this.root.appendChild(label);
        this.root.appendChild(autofillDataInput);
        autofillDataInput.onchange = e => changeCallback(autofillDataInput.value);
        autofillDataInput.addEventListener('input', e => changeCallback(autofillDataInput.value));
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_overwrite_ui.ts":
/*!**************************************************!*\
  !*** ./src/autofill_ui/autofill_overwrite_ui.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillOverwriteConfigUI: () => (/* binding */ AutofillOverwriteConfigUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class AutofillOverwriteConfigUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(settings) {
        super();
        this.settings = settings;
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<div id="autofillOverwrite"></div>`);
        const labelTitle = "Sobreescribir valores (notas, condición, fecha, etc) existentes al rellenar.";
        const label = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<label title="${labelTitle}" style="display:inline;">Sobreescribir valores: </label>`);
        const checkbox = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<input type="checkbox" id="autofillOverwriteCheckbox"/>`);
        checkbox.checked = this.settings.overwriteOnAutofill;
        checkbox.onchange = (e) => {
            this.settings.overwriteOnAutofill = checkbox.checked;
            this.settings.save();
        };
        this.root.appendChild(label);
        this.root.appendChild(checkbox);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_result_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_result_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillResultUI: () => (/* binding */ AutofillResultUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");


function rowToString(row, index) {
    const data = Array.from((0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.mapMap)(row, (k, v) => [k, `${k}=${v}`]).values()).join(", ");
    return `${index}: ${data}`;
}
function autofillDataToString(rows) {
    let asStr = rows.map((v, i, a) => rowToString(v, i));
    return asStr.join("\n");
}
class AutofillResultUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(maxRows = 5) {
        super();
        this.maxRows = maxRows;
        this.root = document.createElement("div");
        this.result = document.createElement("textarea");
        this.status = document.createElement("span");
        const autofillDataViewerLabel = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<p style="display:block">Resultado de la carga: </p>`);
        autofillDataViewerLabel.appendChild(this.status);
        this.result.id = "autofillResult";
        this.result.disabled = true;
        this.root.appendChild(autofillDataViewerLabel);
        this.root.appendChild(this.result);
    }
    update(result) {
        result.doLeft(error => {
            this.result.value = error;
            this.status.innerText = "❌";
        });
        result.doRight(csv => {
            const shortRows = csv.rows.slice(0, Math.min(this.maxRows, csv.rows.length));
            this.result.value = `${autofillDataToString(shortRows)}`;
            this.status.innerText = `✅ (Filas: ${csv.rows.length}, Columnas: ${csv.header.length})`;
        });
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_status_ui.ts":
/*!***********************************************!*\
  !*** ./src/autofill_ui/autofill_status_ui.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillStatsUI: () => (/* binding */ AutofillStatsUI),
/* harmony export */   ColumnStatusUI: () => (/* binding */ ColumnStatusUI),
/* harmony export */   CounterUI: () => (/* binding */ CounterUI),
/* harmony export */   ProgressUI: () => (/* binding */ ProgressUI),
/* harmony export */   StudentChangeUI: () => (/* binding */ StudentChangeUI)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class CounterUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor() {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span class="counterUI">  </span>`);
        this.count = document.createElement("span");
        this.icon = document.createElement("span");
        this.icon.innerHTML = " ●";
        this.root.appendChild(this.count);
        this.root.appendChild(this.icon);
    }
    update(count, total) {
        this.count.innerHTML = `${count}/${total}`;
        const rate = count / total;
        const hue = (rate * 120).toString(10);
        this.icon.style.color = `hsl(${hue},70%,35%)`;
    }
}
class ProgressUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(id, label, title) {
        super();
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span id="statsUIComplete" class="progressUI" >  </span>`);
        this.root.title = title;
        this.root.id = id;
        const labelElement = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span> ${label} </span>`);
        this.count = new CounterUI();
        this.root.appendChild(labelElement);
        this.root.appendChild(this.count.root);
    }
    update(count, total) {
        this.count.update(count, total);
    }
}
class StudentChangeUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(rows_element, autofill) {
        super();
        this.rows_element = rows_element;
        this.autofill = autofill;
        rows_element.forEach((e) => {
            const inputs = e.querySelectorAll("input, select");
            inputs.forEach((i) => {
                i.addEventListener("change", () => {
                    this.onStudentChange();
                }, true);
                i.addEventListener("keyup", () => {
                    this.onStudentChange();
                }, true);
            });
        });
    }
    getStudents() {
        return this.autofill.getStudents(this.rows_element);
    }
}
class AutofillStatsUI extends StudentChangeUI {
    constructor(rows_element, autofill) {
        super(rows_element, autofill);
        this.root = document.createElement("span");
        this.fieldCounters = new Map();
        this.root.id = "statsUI";
        this.countComplete = new ProgressUI("statsUIComplete", "Completo", "Estudiantes con información completa (no considera el campo observaciones)");
        this.countNonEmpty = new ProgressUI("statsUINonEmpty", "Con datos", "Estudiantes con información algún dato completado, pero no todos (no considera el campo observaciones)");
        this.root.appendChild(this.countNonEmpty.root);
        this.root.appendChild(this.countComplete.root);
        // force update the first time
        this.onStudentChange();
    }
    onStudentChange() {
        const students = this.autofill.getStudents(this.rows_element);
        const total = students.length;
        const nonEmpty = students.filter((s) => !(s.isEmpty)).length;
        const complete = students.filter((s) => s.isFull).length;
        this.countNonEmpty.update(nonEmpty, total);
        this.countComplete.update(complete, total);
    }
}
class ColumnStatusUI extends StudentChangeUI {
    constructor(rows_element, autofill, field, header) {
        super(rows_element, autofill);
        this.field = field;
        this.header = header;
        // create CounterUI objects for each field/column
        // const headerElements = Array.from(
        //   document
        //     .getElementById("renglones")
        //     .querySelector("thead")
        //     .querySelectorAll("th")
        // );
        // const fieldToIndex = { fecha: 3, nota: 4, resultado: 5, condicion: 6 };
        // const header = headerElements[fieldToIndex[f]]
        // this.fieldCounters.set(f, counterUI);
        this.counterUI = new CounterUI();
        const container = document.createElement("div");
        header.appendChild(container);
        container.appendChild(this.counterUI.root);
        this.onStudentChange();
    }
    onStudentChange() {
        const students = this.getStudents();
        const count = students.map((s) => {
            return s.getFillableField(this.field) !== "" ? 1 : 0;
        }).reduce((a, b) => a + b, 0);
        // console.log(students)
        this.counterUI.update(count, students.length);
    }
}


/***/ }),

/***/ "./src/autofill_ui/autofill_ui.ts":
/*!****************************************!*\
  !*** ./src/autofill_ui/autofill_ui.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillUI: () => (/* binding */ AutofillUI),
/* harmony export */   addAutofillUI: () => (/* binding */ addAutofillUI)
/* harmony export */ });
/* harmony import */ var _autofill_config_ui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./autofill_config_ui */ "./src/autofill_ui/autofill_config_ui.ts");
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _autofill_status_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./autofill_status_ui */ "./src/autofill_ui/autofill_status_ui.ts");



function shortenToolButtonsNames() {
    const autocomplete = document.getElementById("js-colapsar-autocompletar");
    if (autocomplete) {
        autocomplete.children[1].innerHTML = "Autocompletar básico";
    }
    const scale = document.getElementById("ver_escala_regularidad");
    if (scale) {
        scale.innerHTML = "Glosario";
    }
}
class AutofillUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.UI {
    constructor(rowsElement, autofill, settings) {
        super();
        this.rowsElement = rowsElement;
        this.autofill = autofill;
        // Create a bar above main form
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillBar"> </div>`);
        // add a container with the autofill config, a toggle button to open/close it, and an autofill button to operate it
        const toggleButton = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<button id="autofillAdvanced" class="btn btn-small" href="#" title="Cargar los datos en formato csv para la materia actual desde donde se obtienen los datos para rellenar."><i   class="icon-wrench"></i> Configurar autocompletado </button>`);
        const autofillStartButton = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<button type='button' class="btn btn-small" title="Autocompletar el formulario en base a los datos en formato csv cargados en la configuración"> 📝 Autocompletar </button>`);
        autofillStartButton.onclick = () => {
            autofillConfigUI.data.doRight((csv) => {
                const unmatched = this.autofill.autofill(rowsElement, csv, settings.overwriteOnAutofill);
                // const allUnmatched = getSettings(SettingsKeys.Unmatched) as Array<object>;
                // const newUnmatched = new Set(allUnmatched.concat(unmatched));
                // setSettings(SettingsKeys.Unmatched, Array.from(newUnmatched));
            });
        };
        const config = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillConfigContainer" style="display:none;"> </div>`);
        const controls = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.fromHTML)(`<div id="autofillControlsContainer"> </div>`);
        toggleButton.onclick = () => {
            (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_1__.toggleElement)(config, "block");
        };
        const statsUI = new _autofill_status_ui__WEBPACK_IMPORTED_MODULE_2__.AutofillStatsUI(rowsElement, autofill);
        controls.appendChild(statsUI.root);
        controls.appendChild(toggleButton);
        controls.appendChild(autofillStartButton);
        this.root.appendChild(controls);
        this.root.appendChild(config);
        const autofillConfigUI = new _autofill_config_ui__WEBPACK_IMPORTED_MODULE_0__.AutofillConfigUI(autofill, result => {
            result.doLeft(error => {
                autofillStartButton.disabled = true;
            });
            result.doRight(csv => {
                autofillStartButton.disabled = false;
            });
        }, settings);
        config.appendChild(autofillConfigUI.root);
    }
}
function addAutofillUI(rows, settings, autofill) {
    const autofillUI = new AutofillUI(rows, autofill, settings);
    const renglones = document.getElementById("renglones");
    renglones.parentElement.insertBefore(autofillUI.root, renglones);
    shortenToolButtonsNames();
}


/***/ }),

/***/ "./src/form_renglones.ts":
/*!*******************************!*\
  !*** ./src/form_renglones.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   when_form_renglones_ready: () => (/* binding */ when_form_renglones_ready),
/* harmony export */   when_renglones_changes: () => (/* binding */ when_renglones_changes)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");

const form_renglones_selector = ".form-renglones";
function failed_callback(timeout) {
    console.log(`GUARANI-CHROME: after waiting for ${timeout}, assuming there's no form in page.`);
}
function when_form_renglones_ready(callback, timeout = 5000, additional_wait = 10) {
    const formCallback = () => {
        const form_renglones = document.querySelector(form_renglones_selector);
        callback(form_renglones);
    };
    const failCallback = () => { failed_callback(timeout); };
    const waitCallback = () => { setTimeout(formCallback, additional_wait); };
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.waitForElement)(form_renglones_selector, waitCallback, timeout, undefined, failCallback);
}
// function when_form_renglones_ready_old(listeners){
//     const columna = document.querySelector("#columna_1");
//       if (!columna) {
//         console.log("#Columna_1 not found; not a students form.")
//         return  
//     }
//     console.log("Registering to add save button")
//     console.log(columna)
//     observe(columna,when_columna_changes,{childList:true,subtree:true },disableAfterFirst=false,params=listeners)
//   }
// function when_columna_changes(observer,listeners){
//   const renglones = document.querySelector("#renglones");
//   if (renglones) {
//     console.log("renglones found; adding mutation observer")
//     console.log(renglones)
//     observer.disconnect()
//     observe(renglones,when_renglones_changes,{ subtree: true,childList:true },true,listeners)        
//   }
// }
function when_renglones_changes(observer, listeners) {
    const form_renglones = document.querySelector(".form-renglones");
    if (form_renglones) {
        console.log("GUARANI-CHROME: Form renglones found; adding button");
        observer.disconnect();
        listeners.forEach(listener => listener(form_renglones));
    }
    else {
        console.log("GUARANI-CHROME: Form renglones not found");
        // console.log(document.querySelector("#renglones"))        
    }
}


/***/ }),

/***/ "./src/guarani/Student.ts":
/*!********************************!*\
  !*** ./src/guarani/Student.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Student: () => (/* binding */ Student)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/dom_utils */ "./src/utils/dom_utils.ts");

class Student {
    getFillableFieldElement(name) {
        const i = this.fillableFieldsNames.indexOf(name);
        return this.fillableFieldsElements[i];
    }
    getFillableField(name) {
        const i = this.fillableFieldsNames.indexOf(name);
        return this.fillableFields[i];
    }
    constructor(row) {
        this.row = row;
        this.addResultEmojiElement();
    }
    addResultEmojiElement() {
        if (this.emojiElement) {
            // don't create element if it already exists
            return;
        }
        const alumnoDiv = this.row.querySelector(".ficha-alumno").children[1];
        const emojiElement = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<span class="${Student.EmojiClass}"> <span>`);
        alumnoDiv.appendChild(emojiElement);
    }
    get emojiElement() {
        return this.row.querySelector(Student.EmojiSelector);
    }
    get dniElement() {
        return this.row.querySelector(Student.elementSelectors.dni);
    }
    get dni() { return this.dniElement.innerText.split(" ")[1]; }
    get nombreElement() {
        return this.row.querySelector(Student.elementSelectors.nombre);
    }
    get nombre() {
        return this.nombreElement.innerText;
    }
    get fechaElement() {
        return this.row.querySelector(Student.elementSelectors.fecha);
    }
    get fecha() {
        return this.fechaElement.value;
    }
    set fecha(v) {
        this.fechaElement.value = v;
    }
    get nota() {
        const v = this.notaElement.value;
        // nota uses - as no value
        return (v === "-") ? "" : v;
    }
    set nota(v) {
        // nota uses - as no value
        v = (v === "") ? "-" : v;
        this.notaElement.value = v;
    }
    get resultadoElement() {
        return this.row.querySelector(Student.elementSelectors.resultado);
    }
    get resultado() {
        return this.resultadoElement.value;
    }
    set resultado(v) {
        this.resultadoElement.value = v;
    }
    addToStudentTitle(message) {
        function appendToTitle(element, s) {
            element.title = `${element.title}${s}`;
        }
        appendToTitle(this.nombreElement, `\n Autofill: ${message}`);
        appendToTitle(this.dniElement, `\n Autofill: ${message}`);
        appendToTitle(this.emojiElement, `\n Autofill: ${message}`);
    }
    setStudentClass(klass) {
        this.row.classList.remove(...this.row.classList);
        this.row.classList.add(klass);
    }
    markFilledStudent() {
        this.setStudentClass("autofilledStudent");
        this.addEmojiStudent("✅");
        this.addToStudentTitle("ha sido completado automaticamente");
    }
    markOverwrittenStudent() {
        this.setStudentClass("modifiedStudent");
        this.addEmojiStudent("✏️");
        this.addToStudentTitle("ha sido editado automáticamente");
    }
    markUnmatchedStudent(matches) {
        this.setStudentClass("unmatchedStudent");
        this.addEmojiStudent("❌");
        this.addToStudentTitle("no se pudo encontrar en el csv");
    }
    addEmojiStudent(emoji) {
        this.emojiElement.innerText = `${this.emojiElement.innerText}${emoji}`;
    }
    markAlreadyFilledStudent() {
        this.setStudentClass("alreadyFilledStudent");
        this.addEmojiStudent("⚠️");
        this.addToStudentTitle("No se modificó porque ya tenía valores cargados");
    }
    get emptyFields() {
        return this.fillableFields.filter(f => f === "");
    }
    get isFull() {
        return this.emptyFields.length === 0;
    }
    get isEmpty() {
        return this.emptyFields.length == this.fillableFields.length;
    }
}
Student.EmojiClass = "result-emoji";
Student.EmojiSelector = `.${Student.EmojiClass}`;
Student.elementSelectors = {
    dni: ".identificacion",
    nombre: ".nombre",
    fecha: ".fecha",
    resultado: ".resultado",
    condicion: ".condicion",
    observacion: ".observacion",
};


/***/ }),

/***/ "./src/guarani/StudentCursada.ts":
/*!***************************************!*\
  !*** ./src/guarani/StudentCursada.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StudentCursada: () => (/* binding */ StudentCursada)
/* harmony export */ });
/* harmony import */ var _Student__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Student */ "./src/guarani/Student.ts");

class StudentCursada extends _Student__WEBPACK_IMPORTED_MODULE_0__.Student {
    constructor() {
        super(...arguments);
        this.fillableFieldsElements = [this.notaElement, this.fechaElement, this.resultadoElement, this.condicionElement];
    }
    get condicionElement() {
        return this.row.querySelector(StudentCursada.elementSelectors.condicion);
    }
    get condicion() {
        return this.condicionElement.value;
    }
    set condicion(v) {
        this.condicionElement.value = v;
    }
    get observacionElement() {
        return this.row.querySelector(StudentCursada.elementSelectors.observacion);
    }
    get observacion() {
        return this.observacionElement.value;
    }
    set observacion(v) {
        this.observacionElement.value = v;
    }
    asDict() {
        return {
            dni: this.dni,
            nombre: this.nombre,
            fecha: this.fecha,
            nota: this.nota,
            resultado: this.resultado,
            condicion: this.condicion,
            observacion: this.observacion
        };
    }
    get notaElement() {
        return this.row.querySelector(".nota_cursada");
    }
    get fillableFieldsNames() {
        return ["nota", "fecha", "resultado", "condicion"];
    }
    get fillableFields() {
        return [this.nota, this.fecha, this.resultado, this.condicion];
    }
}


/***/ }),

/***/ "./src/guarani/StudentFinal.ts":
/*!*************************************!*\
  !*** ./src/guarani/StudentFinal.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StudentFinal: () => (/* binding */ StudentFinal)
/* harmony export */ });
/* harmony import */ var _Student__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Student */ "./src/guarani/Student.ts");

class StudentFinal extends _Student__WEBPACK_IMPORTED_MODULE_0__.Student {
    constructor() {
        super(...arguments);
        this.fillableFieldsElements = [this.notaElement, this.fechaElement, this.resultadoElement];
    }
    get notaElement() {
        return this.row.querySelector(".nota");
    }
    get fillableFieldsNames() {
        return ["nota", "fecha", "resultado"];
    }
    get fillableFields() {
        return [this.nota, this.fecha, this.resultado];
    }
}


/***/ }),

/***/ "./src/input/CSVCursadaConfig.ts":
/*!***************************************!*\
  !*** ./src/input/CSVCursadaConfig.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSVCursadaConfig: () => (/* binding */ CSVCursadaConfig)
/* harmony export */ });
/* harmony import */ var _parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parser */ "./src/input/parser.ts");

class CSVCursadaConfig extends _parser__WEBPACK_IMPORTED_MODULE_0__.CSVConfig {
    constructor() {
        super(...arguments);
        this.id = "cursada";
        this.dataColumns = ["fecha", "condicion", "nota", "resultado"];
        this.keyColumns = ["dni", "nombre"];
        this.csvSeparator = ";";
        this.values = {
            nota: {
                "U": "U",
                "D": "D",
                "A": "A",
                "-": "",
            },
            resultado: {
                "Ausente": "U",
                "Reprobado": "R",
                "Aprobado": "A",
                "-": "",
            },
            condicion: {
                "Abandono": "2",
                "Aprobado": "175",
                "Desaprobado": "174",
                "Insuficiente": "3",
                "Libre": "1",
                "No Promociono": "107",
                "Promociono": "5",
                "Regular": "4",
                "-": "",
            }
        };
    }
}


/***/ }),

/***/ "./src/input/CSVFinalConfig.ts":
/*!*************************************!*\
  !*** ./src/input/CSVFinalConfig.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSVFinalConfig: () => (/* binding */ CSVFinalConfig)
/* harmony export */ });
/* harmony import */ var _parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./parser */ "./src/input/parser.ts");

class CSVFinalConfig extends _parser__WEBPACK_IMPORTED_MODULE_0__.CSVConfig {
    constructor() {
        super(...arguments);
        this.id = "final";
        this.dataColumns = ["fecha", "nota", "resultado"];
        this.keyColumns = ["dni", "nombre"];
        this.csvSeparator = ";";
        this.values = {
            nota: {
                "0": "0",
                "1": "1",
                "2": "2",
                "3": "3",
                "4": "4",
                "5": "5",
                "6": "6",
                "7": "7",
                "8": "8",
                "9": "9",
                "10": "10",
                "-": "",
            },
            resultado: {
                "Ausente": "U",
                "Reprobado": "R",
                "Aprobado": "A",
                "-": "",
            },
        };
    }
}


/***/ }),

/***/ "./src/input/csv.ts":
/*!**************************!*\
  !*** ./src/input/csv.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSV: () => (/* binding */ CSV),
/* harmony export */   CSVParseError: () => (/* binding */ CSVParseError),
/* harmony export */   parseCSV: () => (/* binding */ parseCSV),
/* harmony export */   validateCSV: () => (/* binding */ validateCSV)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");

function validateCSV(input, separator = ";") {
    return input.trim().length > 0;
}
function toEntries(a) {
    return a.map((value, index) => [index, value]);
}
class CSVParseError extends Error {
    constructor(message) {
        super(message);
        this.name = 'CSVParseError';
    }
}
class CSV {
    constructor(rows, header) {
        this.rows = rows;
        this.header = header;
    }
}
function parseCSV(input, separator = ";", normalize_header = false) {
    input = input.trim();
    if (input === "") {
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(new CSV([], []));
    }
    const lines = input.split(/\r\n|\n/).map(r => r.trim());
    const nonemptyLines = lines.filter(r => r.length > 0);
    const splitLines = nonemptyLines.map((l) => l.split(separator));
    const basicHeader = splitLines.shift();
    const header = normalize_header ? basicHeader.map(h => h.trim().toLowerCase()) : basicHeader;
    const rows = [];
    for (const [i, values] of toEntries(splitLines)) {
        if (header.length != values.length) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`Number of values in row ${i} does not match number of values in header.\nHeader: "${header}"\nRow ${i}: "${values}"`);
        }
        const row = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.dictFromLists)(header, values);
        rows.push(row);
    }
    return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(new CSV(rows, header));
}
// parseCSV("dni;h1\n23;v1\n  \n  \n")


/***/ }),

/***/ "./src/input/parser.ts":
/*!*****************************!*\
  !*** ./src/input/parser.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutofillParser: () => (/* binding */ AutofillParser),
/* harmony export */   CSVConfig: () => (/* binding */ CSVConfig)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/utils */ "./src/utils/utils.ts");
/* harmony import */ var _csv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./csv */ "./src/input/csv.ts");


class CSVConfig {
}
function checkValues(column, values, rows) {
    const rowsWithNumber = rows.map((v, i, a) => [v, i + 2]);
    const rowsWithWrongValues = rowsWithNumber.filter(([s, i], j) => !values.includes(s.get(column)));
    return rowsWithWrongValues.length === 0
        ? new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.None()
        : new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Some(rowsWithWrongValues);
}
function printRow(rowIndex, separator) {
    const [row, index] = rowIndex;
    return `Fila ${index}: ${Array.from(row.values()).join(separator)}`;
}
function printAutofillData(data, header, separator) {
    let headerRow = header.join(separator);
    let rows = data.map(r => printRow(r, separator)).join("\n");
    return `${headerRow}\n${rows}\n`;
}
class AutofillParser {
    constructor(config) {
        this.config = config;
    }
    parse(data) {
        const parseResult = (0,_csv__WEBPACK_IMPORTED_MODULE_1__.parseCSV)(data, this.config.csvSeparator, true);
        if (parseResult.isLeft()) {
            return parseResult;
        }
        const csv = parseResult.get();
        const keyColumnsPresent = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.intersection)(this.config.keyColumns, csv.header);
        if (keyColumnsPresent.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El CSV no contiene ninguna de las columnas necesarias para identificar estudiantes. \n - Columnas de identificación: ${this.config.keyColumns}. \n - Columnas del csv: ${csv.header}`);
        }
        const dataColumnsPresent = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__.intersection)(this.config.dataColumns, csv.header);
        if (dataColumnsPresent.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El CSV no contiene ninguna columna de datos relevante para el llenado. \n - Columnas de datos: ${this.config.dataColumns}.\n - Columnas del csv: ${csv.header}`);
        }
        if (csv.rows.length === 0) {
            return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`El csv solo contiene un encabezado, y no contiene datos.\n - Encabezado: ${csv.header}`);
        }
        for (const [key, values] of Object.entries(this.config.values)) {
            if (csv.header.includes(key)) {
                const validValues = Object.keys(values);
                const valueCheck = checkValues(key, validValues, csv.rows);
                if (valueCheck.isSome()) {
                    let rowsWithErrors = valueCheck.get();
                    return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Left(`La columna ${key} contiene valores inválidos. Valores válidos: ${validValues}.\n Filas con valores inválidos:\n${printAutofillData(rowsWithErrors, csv.header, this.config.csvSeparator)}`);
                }
            }
        }
        return new _utils_utils__WEBPACK_IMPORTED_MODULE_0__.Right(csv);
    }
}


/***/ }),

/***/ "./src/settings.ts":
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Settings: () => (/* binding */ Settings)
/* harmony export */ });
class Settings {
    static CheckVersion(callback) {
        chrome.storage.local.get(Settings.Keys.Version, settings => {
            const currentVersion = this.defaultSettings[Settings.Keys.Version];
            const settingsVersion = settings[Settings.Keys.Version];
            if (settingsVersion != currentVersion) {
                // if versions don`t match, clear local storage and restart settings to prevent errors
                console.log(`GUARANI-CHROME: New version ${currentVersion} found, deleting settings from ${settingsVersion} `);
                chrome.storage.local.clear();
                chrome.storage.sync.clear();
                chrome.storage.local.set({ [Settings.Keys.Version]: currentVersion });
            }
            callback();
        });
    }
    static RestoreFromStorage(callback) {
        console.log(`GUARANI-CHROME: Initializing settings... `);
        this.CheckVersion(() => {
            // console.log(`Initialized with settings: ${Object.entries(v)}`)
            chrome.storage.local.get(Settings.defaultSettings, values => {
                const s = new Settings(values[Settings.Keys.Theme], values[Settings.Keys.OverwriteOnAutofill], values[Settings.Keys.AutofillDataCSV], values[Settings.Keys.Version]);
                callback(s);
            });
        });
    }
    constructor(theme = "dark", overwriteOnAutofill = true, autofillData, version) {
        this.theme = theme;
        this.overwriteOnAutofill = overwriteOnAutofill;
        this.autofillData = autofillData;
        this.version = version;
    }
    save(callback = () => { }) {
        const s = {
            [Settings.Keys.Theme]: this.theme,
            [Settings.Keys.OverwriteOnAutofill]: this.overwriteOnAutofill,
            [Settings.Keys.AutofillDataCSV]: this.autofillData,
            [Settings.Keys.Version]: this.version
        };
        chrome.storage.local.set(s).then(() => callback());
    }
    getDataID(operation, subject) {
        return `${operation}_${subject}`;
    }
    getAutofillData(operation, subject = "") {
        var _a;
        return (_a = this.autofillData[this.getDataID(operation, subject)]) !== null && _a !== void 0 ? _a : "";
    }
    setAutofillData(operation, subject, data) {
        this.autofillData[this.getDataID(operation, subject)] = data;
    }
}
Settings.Keys = {
    // MissingStudents:"missingStudents",
    Theme: "theme",
    OverwriteOnAutofill: "overwriteOnAutofill",
    AutofillDataCSV: "autofillDataCSV",
    Version: "version"
    // Unmatched:"unmatched"
};
Settings.defaultSettings = {
    [Settings.Keys.Theme]: "dark",
    [Settings.Keys.OverwriteOnAutofill]: false,
    [Settings.Keys.AutofillDataCSV]: {},
    [Settings.Keys.Version]: "2"
    // [Settings2.Keys.Unmatched]:[],
};


/***/ }),

/***/ "./src/themes.ts":
/*!***********************!*\
  !*** ./src/themes.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initializeThemeChooser: () => (/* binding */ initializeThemeChooser)
/* harmony export */ });
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/utils */ "./src/utils/utils.ts");


function addCSS(href) {
    const trueHref = chrome.runtime.getURL(href);
    var link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', trueHref);
    link.setAttribute('type', "text/css");
    // link.setAttribute('disabled', "disabled");
    document.head.appendChild(link);
    return link;
}
class ThemesUI extends _utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.UI {
    constructor(themes, settings) {
        super();
        this.themes = themes;
        this.settings = settings;
        this.root = (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_0__.fromHTML)(`<select type="text" name="theme" id="theme">
    <option value="light">Claro 🌕</option>
    <option value="dark">Oscuro 🌑</option>
    </select>`);
        this.root.value = settings.theme;
        this.root.addEventListener('change', (event) => this.updateTheme());
        this.updateTheme();
    }
    updateTheme() {
        const newTheme = this.root.value;
        console.log(`GUARANI-CHROME: Changing theme to "${newTheme}"`);
        this.settings.theme = newTheme;
        this.settings.save();
        //disable all themes
        this.themes.forEach((v, k) => v.disabled = true);
        //enable just this one
        if (this.themes.has(newTheme)) {
            this.themes.get(newTheme).disabled = false;
        }
    }
}
function initializeThemeChooser(settings) {
    console.log(`GUARANI-CHROME: initializing theme chooser`);
    const themeURLs = new Map(Object.entries({ "dark": "themes/dark.css",
        "light": "themes/light.css"
    }));
    const themes = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.mapValues)(themeURLs, addCSS);
    // wait a bit for css files to load before creating ThemesUI
    window.setTimeout(() => {
        const themesUI = new ThemesUI(themes, settings);
        let notifications = document.querySelector(".notificaciones");
        if (notifications) {
            notifications.appendChild(themesUI.root);
        }
        else {
            console.log(`GUARANI-CHROME: Did not find element ".notificaciones" to append the theme chooser`);
        }
    }, 100);
}


/***/ }),

/***/ "./src/utils/dom_utils.ts":
/*!********************************!*\
  !*** ./src/utils/dom_utils.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UI: () => (/* binding */ UI),
/* harmony export */   appendChildren: () => (/* binding */ appendChildren),
/* harmony export */   cleanPropagate: () => (/* binding */ cleanPropagate),
/* harmony export */   fromHTML: () => (/* binding */ fromHTML),
/* harmony export */   observe: () => (/* binding */ observe),
/* harmony export */   propagateOnChange: () => (/* binding */ propagateOnChange),
/* harmony export */   ready: () => (/* binding */ ready),
/* harmony export */   toggleElement: () => (/* binding */ toggleElement),
/* harmony export */   waitForElement: () => (/* binding */ waitForElement)
/* harmony export */ });
class UI {
}
function ready(fn) {
    if (document.readyState !== 'loading') {
        fn();
        return;
    }
    document.addEventListener('DOMContentLoaded', fn);
}
function observe(element, f, config = { subtree: true, childList: true, attributes: true }, disableAfterFirst = true, params = []) {
    const mutationObserver = new MutationObserver(() => {
        if (disableAfterFirst) {
            mutationObserver.disconnect();
        }
        f(mutationObserver, params);
    });
    mutationObserver.observe(element, config);
    return mutationObserver;
}
function toggleElement(el, display = "block") {
    if (el.style.display === "none") {
        el.style.display = display;
    }
    else {
        el.style.display = "none";
    }
}
function fromHTML(html, trim = true) {
    // Process the HTML string.
    html = trim ? html : html.trim();
    if (!html)
        return null;
    // Then set up a new template element.
    const template = document.createElement('template');
    template.innerHTML = html;
    const result = template.content.children;
    // Then return either an HTMLElement or HTMLCollection,
    // based on whether the input HTML had one or more roots.
    if (result.length !== 1)
        throw Error(`fromHTML must create one and only one element (possibly with many children, found ${result})`);
    return result[0];
}
function appendChildren(root, children) {
    children.forEach(child => root.appendChild(child));
}
function waitForElement(selector, callback, checkFrequencyInMs = 10, timeoutInMs = 15000, failure_callback = undefined) {
    var startTimeInMs = Date.now();
    (function loopSearch() {
        const element = document.querySelector(selector);
        if (element) {
            callback(element);
        }
        else {
            setTimeout(function () {
                const elapsed = Date.now() - startTimeInMs;
                if (timeoutInMs && elapsed > timeoutInMs) {
                    if (failure_callback) {
                        failure_callback();
                    }
                }
                else {
                    loopSearch();
                }
            }, checkFrequencyInMs);
        }
    })();
}
function propagateOnChange(element) {
    var event = new Event('change', { bubbles: true });
    element.dispatchEvent(event);
}
function cleanPropagate(e) {
    e.value = "";
    propagateOnChange(e);
}


/***/ }),

/***/ "./src/utils/utils.ts":
/*!****************************!*\
  !*** ./src/utils/utils.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Left: () => (/* binding */ Left),
/* harmony export */   None: () => (/* binding */ None),
/* harmony export */   Optional: () => (/* binding */ Optional),
/* harmony export */   Right: () => (/* binding */ Right),
/* harmony export */   Some: () => (/* binding */ Some),
/* harmony export */   dictFromLists: () => (/* binding */ dictFromLists),
/* harmony export */   intersection: () => (/* binding */ intersection),
/* harmony export */   mapKeys: () => (/* binding */ mapKeys),
/* harmony export */   mapMap: () => (/* binding */ mapMap),
/* harmony export */   mapValues: () => (/* binding */ mapValues),
/* harmony export */   zip: () => (/* binding */ zip)
/* harmony export */ });
const zip = (a, b) => a.map((k, i) => [k, b[i]]);
function intersection(a, b) { return a.filter(value => b.includes(value)); }
function dictFromLists(keys, vals) {
    const dict = new Map();
    zip(keys, vals).forEach(kv => {
        const [k, v] = kv;
        dict.set(k, v);
    });
    return dict;
}
class Optional {
}
class Some extends Optional {
    constructor(x) {
        super();
        this.x = x;
    }
    get() { return this.x; }
    map(f) { return new Some(f(this.x)); }
    flatMap(f) { return f(this.x); }
    doSome(f) { f(this.x); }
    doNone(f) { }
    isNone() { return false; }
    isSome() { return true; }
}
class None extends Optional {
    map(f) { return f(this); }
    flatMap(f) { this; }
    doSome(f) { }
    doNone(f) { f(); }
    isNone() { return true; }
    isSome() { return false; }
}
class Left {
    constructor(val) {
        this._val = val;
    }
    isLeft() {
        return true;
    }
    isRight() {
        return false;
    }
    do(fL, fR) {
        return this.doLeft(fL);
    }
    doLeft(f) {
        f(this._val);
        return this;
    }
    doRight(f) {
        return this;
    }
    chainAny(fL, fR) {
        return fL(this._val);
    }
    map() {
        // Left is the sad path
        // so we do nothing
        return this;
    }
    join() {
        // On the sad path, we don't
        // do anything with join
        return this;
    }
    chain() {
        // Boring sad path,
        // do nothing.
        return this;
    }
    get() {
        return this._val;
    }
    toString() {
        const str = this._val.toString();
        return `Left(${str})`;
    }
}
/**
*Right represents the happy path
*/
class Right {
    constructor(val) {
        this._val = val;
    }
    isLeft() {
        return false;
    }
    isRight() {
        return true;
    }
    do(fL, fR) {
        return this.doRight(fR);
    }
    doLeft(f) {
        return this;
    }
    doRight(f) {
        f(this._val);
        return this;
    }
    chainAny(fL, fR) {
        return this.chain(fR);
    }
    map(fn) {
        return new Right(fn(this._val));
    }
    join() {
        if ((this._val instanceof Left)
            || (this._val instanceof Right)) {
            return this._val;
        }
        return this;
    }
    chain(fn) {
        return fn(this._val);
    }
    get() {
        return this._val;
    }
    toString() {
        const str = this._val.toString();
        return `Right(${str})`;
    }
}
function mapValues(map, fn) {
    return new Map(Array.from(map, ([key, value]) => [key, fn(value)]));
}
function mapKeys(map, fn) {
    return new Map(Array.from(map, ([key, value]) => [fn(key), value]));
}
function mapMap(map, fn) {
    return new Map(Array.from(map, ([key, value]) => fn(key, value)));
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./themes */ "./src/themes.ts");
/* harmony import */ var _utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/dom_utils */ "./src/utils/dom_utils.ts");
/* harmony import */ var _form_renglones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form_renglones */ "./src/form_renglones.ts");
/* harmony import */ var _autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./autofill_ui/autofill_ui */ "./src/autofill_ui/autofill_ui.ts");
/* harmony import */ var _autofill_autofill__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./autofill/autofill */ "./src/autofill/autofill.ts");
/* harmony import */ var _input_parser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./input/parser */ "./src/input/parser.ts");
/* harmony import */ var _input_CSVCursadaConfig__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./input/CSVCursadaConfig */ "./src/input/CSVCursadaConfig.ts");
/* harmony import */ var _input_CSVFinalConfig__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./input/CSVFinalConfig */ "./src/input/CSVFinalConfig.ts");
/* harmony import */ var _autofill_ui_autofill_status_ui__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./autofill_ui/autofill_status_ui */ "./src/autofill_ui/autofill_status_ui.ts");










var PageType;
(function (PageType) {
    PageType[PageType["Cursada"] = 0] = "Cursada";
    PageType[PageType["Final"] = 1] = "Final";
    PageType[PageType["Other"] = 2] = "Other";
})(PageType || (PageType = {}));
function detectPageTypeByURL() {
    if (window.location.host.includes("localhost")) {
        if (window.location.pathname.endsWith("cursada.html")) {
            return PageType.Cursada;
        }
        if (window.location.pathname.endsWith("final.html")) {
            return PageType.Final;
        }
        return PageType.Other;
    }
    const url = window.location.toString();
    if (window.location.pathname.startsWith("/cursada/edicion")) {
        return PageType.Cursada;
    }
    if (window.location.pathname.startsWith("/notas_mesa_examen/edicion")) {
        return PageType.Final;
    }
    return PageType.Other;
}
function detectPageTypeByElements() {
    const cabeceraElement = document.getElementById("cabecera");
    if (!cabeceraElement) {
        return PageType.Other;
    }
    const titleElementContainer = cabeceraElement.querySelector("h2");
    if (!titleElementContainer) {
        return PageType.Other;
    }
    const titleElement = titleElementContainer.children[0];
    switch (titleElement.innerText) {
        case "Carga de notas de cursada": return PageType.Cursada;
        case "Carga de notas a mesa de examen": return PageType.Final;
        default: return PageType.Other;
    }
}
function getSubjectName() {
    const divCabecera = document.getElementById("js-colapsar-detalles-zona");
    const nameSpan = divCabecera.children[0].children[0];
    return nameSpan.innerText;
}
function addColumnCounters(rows, autofill, fieldToIndex) {
    const headerElements = Array.from(document
        .getElementById("renglones")
        .querySelector("thead")
        .querySelectorAll("th"));
    const columnsStatusUIs = Object.entries(fieldToIndex).map((e, i, a) => {
        const [key, value] = e;
        const header = headerElements[value];
        return new _autofill_ui_autofill_status_ui__WEBPACK_IMPORTED_MODULE_9__.ColumnStatusUI(rows, autofill, key, header);
    });
    return columnsStatusUIs;
}
function addPageSpecificUI(settings) {
    switch (detectPageTypeByURL()) {
        case PageType.Cursada: {
            (0,_form_renglones__WEBPACK_IMPORTED_MODULE_3__.when_form_renglones_ready)((form_renglones) => {
                const table = form_renglones.children[1];
                const table_body = table.children[1];
                const rows = Array.from(table_body.rows);
                const subjectName = getSubjectName();
                console.log(`GUARANI-CHROME: Se detectó página de carga de notas de CURSADA de la materia ${subjectName}`);
                const autofill = new _autofill_autofill__WEBPACK_IMPORTED_MODULE_5__.AutofillCursada(new _input_parser__WEBPACK_IMPORTED_MODULE_6__.AutofillParser(new _input_CSVCursadaConfig__WEBPACK_IMPORTED_MODULE_7__.CSVCursadaConfig()), subjectName);
                const fieldToIndex = { "fecha": 3, "nota": 4, "resultado": 5, "condicion": 6 };
                addColumnCounters(rows, autofill, fieldToIndex);
                (0,_autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_4__.addAutofillUI)(rows, settings, autofill);
            }, 4000, 10);
            break;
        }
        case PageType.Final: {
            (0,_form_renglones__WEBPACK_IMPORTED_MODULE_3__.when_form_renglones_ready)((form_renglones) => {
                const table = form_renglones.children[1];
                const table_body = table.children[1];
                const rows = Array.from(table_body.rows);
                const subjectName = getSubjectName();
                console.log(`GUARANI-CHROME: Se detectó página de carga de notas de FINAL de la materia ${subjectName}`);
                const autofill = new _autofill_autofill__WEBPACK_IMPORTED_MODULE_5__.AutofillFinal(new _input_parser__WEBPACK_IMPORTED_MODULE_6__.AutofillParser(new _input_CSVFinalConfig__WEBPACK_IMPORTED_MODULE_8__.CSVFinalConfig()), subjectName);
                const fieldToIndex = { "fecha": 3, "nota": 4, "resultado": 5 };
                addColumnCounters(rows, autofill, fieldToIndex);
                (0,_autofill_ui_autofill_ui__WEBPACK_IMPORTED_MODULE_4__.addAutofillUI)(rows, settings, autofill);
            }, 4000, 10);
            break;
        }
        default: console.log("GUARANI-CHROME: No se detectó un tipo de página especial.");
    }
}
_settings__WEBPACK_IMPORTED_MODULE_0__.Settings.RestoreFromStorage(s => {
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__.ready)(() => (0,_themes__WEBPACK_IMPORTED_MODULE_1__.initializeThemeChooser)(s));
    (0,_utils_dom_utils__WEBPACK_IMPORTED_MODULE_2__.waitForElement)("#cabecera", () => {
        addPageSpecificUI(s);
    });
});

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE2QztBQUNjO0FBQ0o7QUFDdkQ7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7QUFDQSxtQkFBbUIsOENBQUk7QUFDdkI7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELG1FQUFjO0FBQ2pFO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsK0RBQVk7QUFDL0Q7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFGa0U7QUFDRTtBQUNaO0FBQ0Y7QUFDL0MsK0JBQStCLGdEQUFFO0FBQ3hDO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQSxxQ0FBcUMsaUVBQWdCO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLCtEQUFlO0FBQzNDLDhDQUE4Qyw2RUFBeUI7QUFDdkUsUUFBUSxnRUFBYztBQUN0QjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QmtEO0FBQzNDLDhCQUE4QixnREFBRTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBLHVHQUF1RztBQUN2RyxvQ0FBb0MsV0FBVztBQUMvQywyQkFBMkIsWUFBWTtBQUN2QztBQUNBLHNCQUFzQiwwREFBUSw0REFBNEQsV0FBVztBQUNyRyxrQ0FBa0MsMERBQVE7QUFDMUM7QUFDQSw2QkFBNkIsU0FBUztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQmtEO0FBQzNDLHdDQUF3QyxnREFBRTtBQUNqRDtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQSxzQkFBc0IsMERBQVEsa0JBQWtCLFdBQVcsd0JBQXdCO0FBQ25GLHlCQUF5QiwwREFBUTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJrRDtBQUNWO0FBQ3hDO0FBQ0EsNEJBQTRCLG9EQUFNLHVCQUF1QixFQUFFLEdBQUcsRUFBRTtBQUNoRSxjQUFjLE1BQU0sSUFBSSxLQUFLO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTywrQkFBK0IsZ0RBQUU7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLDBEQUFRO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxtQ0FBbUMsZ0NBQWdDO0FBQ25FLGlEQUFpRCxnQkFBZ0IsY0FBYyxrQkFBa0I7QUFDakcsU0FBUztBQUNUO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNrRDtBQUMzQyx3QkFBd0IsZ0RBQUU7QUFDakM7QUFDQTtBQUNBLG9CQUFvQiwwREFBUTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxNQUFNLEdBQUcsTUFBTTtBQUNqRDtBQUNBO0FBQ0EsdUNBQXVDLElBQUk7QUFDM0M7QUFDQTtBQUNPLHlCQUF5QixnREFBRTtBQUNsQztBQUNBO0FBQ0Esb0JBQW9CLDBEQUFRO0FBQzVCO0FBQ0E7QUFDQSw2QkFBNkIsMERBQVEsV0FBVyxPQUFPO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyw4QkFBOEIsZ0RBQUU7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekd3RDtBQUNVO0FBQ1g7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyx5QkFBeUIsZ0RBQUU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiwwREFBUTtBQUM1QjtBQUNBLDZCQUE2QiwwREFBUTtBQUNyQyxvQ0FBb0MsMERBQVE7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsdUJBQXVCLDBEQUFRLHdEQUF3RDtBQUN2Rix5QkFBeUIsMERBQVE7QUFDakM7QUFDQSxZQUFZLCtEQUFhO0FBQ3pCO0FBQ0EsNEJBQTRCLGdFQUFlO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsaUVBQWdCO0FBQ3JEO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQzFEbUQ7QUFDbkQ7QUFDQTtBQUNBLHFEQUFxRCxRQUFRO0FBQzdEO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQyxpQ0FBaUM7QUFDakMsSUFBSSxnRUFBYztBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2Qyw2QkFBNkI7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBLGtEQUFrRCw4QkFBOEI7QUFDaEY7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLDJEQUEyRDtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUM4QztBQUN2QztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QiwwREFBUSxpQkFBaUIsbUJBQW1CO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLGNBQWMsRUFBRSxFQUFFO0FBQ2pEO0FBQ0EsMERBQTBELFFBQVE7QUFDbEUsdURBQXVELFFBQVE7QUFDL0QseURBQXlELFFBQVE7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLDRCQUE0QixFQUFFLE1BQU07QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixtQkFBbUI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ3RIb0M7QUFDN0IsNkJBQTZCLDZDQUFPO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUNvQztBQUM3QiwyQkFBMkIsNkNBQU87QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZxQztBQUM5QiwrQkFBK0IsOENBQVM7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDbENxQztBQUM5Qiw2QkFBNkIsOENBQVM7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0I0RDtBQUNyRCwwQ0FBMEM7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHVDQUF1QztBQUM5QztBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qiw4Q0FBSSw0QkFBNEIsR0FBRyx1REFBdUQsT0FBTyxTQUFTLEVBQUUsS0FBSyxPQUFPO0FBQy9JO0FBQ0Esb0JBQW9CLDJEQUFhO0FBQ2pDO0FBQ0E7QUFDQSxlQUFlLCtDQUFLO0FBQ3BCO0FBQ0EsaUJBQWlCLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDZ0Q7QUFDdkM7QUFDMUI7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyw4Q0FBSTtBQUNsQixjQUFjLDhDQUFJO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixNQUFNLElBQUkseUNBQXlDO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxVQUFVLElBQUksS0FBSztBQUNqQztBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsOENBQVE7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsMERBQVk7QUFDOUM7QUFDQSx1QkFBdUIsOENBQUkseUhBQXlILHVCQUF1QiwyQkFBMkIsV0FBVztBQUNqTjtBQUNBLG1DQUFtQywwREFBWTtBQUMvQztBQUNBLHVCQUF1Qiw4Q0FBSSxtR0FBbUcsd0JBQXdCLDBCQUEwQixXQUFXO0FBQzNMO0FBQ0E7QUFDQSx1QkFBdUIsOENBQUksNkVBQTZFLFdBQVc7QUFDbkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsOENBQUksZUFBZSxLQUFLLCtDQUErQyxZQUFZLG9DQUFvQyx3RUFBd0U7QUFDOU47QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLCtDQUFLO0FBQ3hCO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ3JETztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxnQkFBZ0IsZ0NBQWdDLGlCQUFpQjtBQUM1SDtBQUNBO0FBQ0EsMkNBQTJDLHlDQUF5QztBQUNwRjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlELGtCQUFrQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixVQUFVLEdBQUcsUUFBUTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRWlEO0FBQ1A7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsZ0RBQUU7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMERBQVE7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELFNBQVM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsK0NBQStDO0FBQy9DO0FBQ0EsS0FBSztBQUNMLG1CQUFtQix1REFBUztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RE87QUFDUDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sd0NBQXdDLGtEQUFrRDtBQUNqRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5R0FBeUcsT0FBTztBQUNoSDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsS0FBSztBQUNMO0FBQ087QUFDUCxzQ0FBc0MsZUFBZTtBQUNyRDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRU87QUFDQSw4QkFBOEI7QUFDOUI7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ087QUFDUDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1osYUFBYTtBQUNiLGlCQUFpQjtBQUNqQixnQkFBZ0I7QUFDaEI7QUFDQSxlQUFlO0FBQ2YsZUFBZTtBQUNmO0FBQ087QUFDUCxhQUFhO0FBQ2IsaUJBQWlCO0FBQ2pCO0FBQ0EsZ0JBQWdCO0FBQ2hCLGVBQWU7QUFDZixlQUFlO0FBQ2Y7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixJQUFJO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLElBQUk7QUFDNUI7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTs7Ozs7OztVQ3RJQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTnNDO0FBQ1k7QUFDUTtBQUNHO0FBQ0g7QUFDVztBQUNyQjtBQUNZO0FBQ0o7QUFDVTtBQUNsRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyw0QkFBNEI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLDJFQUFjO0FBQ2pDLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwwRUFBeUI7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0R0FBNEcsWUFBWTtBQUN4SCxxQ0FBcUMsK0RBQWUsS0FBSyx5REFBYyxLQUFLLHFFQUFnQjtBQUM1Rix1Q0FBdUM7QUFDdkM7QUFDQSxnQkFBZ0IsdUVBQWE7QUFDN0IsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLFlBQVksMEVBQXlCO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEdBQTBHLFlBQVk7QUFDdEgscUNBQXFDLDZEQUFhLEtBQUsseURBQWMsS0FBSyxpRUFBYztBQUN4Rix1Q0FBdUM7QUFDdkM7QUFDQSxnQkFBZ0IsdUVBQWE7QUFDN0IsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBUTtBQUNSLElBQUksdURBQUssT0FBTywrREFBc0I7QUFDdEMsSUFBSSxnRUFBYztBQUNsQjtBQUNBLEtBQUs7QUFDTCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvYXV0b2ZpbGwvYXV0b2ZpbGwudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvYXV0b2ZpbGxfdWkvYXV0b2ZpbGxfY29uZmlnX3VpLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsX3VpL2F1dG9maWxsX2lucHV0X3VpLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsX3VpL2F1dG9maWxsX292ZXJ3cml0ZV91aS50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9hdXRvZmlsbF91aS9hdXRvZmlsbF9yZXN1bHRfdWkudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvYXV0b2ZpbGxfdWkvYXV0b2ZpbGxfc3RhdHVzX3VpLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2F1dG9maWxsX3VpL2F1dG9maWxsX3VpLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2Zvcm1fcmVuZ2xvbmVzLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2d1YXJhbmkvU3R1ZGVudC50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9ndWFyYW5pL1N0dWRlbnRDdXJzYWRhLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2d1YXJhbmkvU3R1ZGVudEZpbmFsLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2lucHV0L0NTVkN1cnNhZGFDb25maWcudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvaW5wdXQvQ1NWRmluYWxDb25maWcudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvaW5wdXQvY3N2LnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL2lucHV0L3BhcnNlci50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy9zZXR0aW5ncy50cyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS8uL3NyYy90aGVtZXMudHMiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvdXRpbHMvZG9tX3V0aWxzLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lLy4vc3JjL3V0aWxzL3V0aWxzLnRzIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9ndWFyYW5pLWNocm9tZS93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2d1YXJhbmktY2hyb21lL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vZ3VhcmFuaS1jaHJvbWUvLi9zcmMvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGVmdCwgUmlnaHQgfSBmcm9tIFwiLi4vdXRpbHMvdXRpbHNcIjtcbmltcG9ydCB7IFN0dWRlbnRDdXJzYWRhIH0gZnJvbSBcIi4uL2d1YXJhbmkvU3R1ZGVudEN1cnNhZGFcIjtcbmltcG9ydCB7IFN0dWRlbnRGaW5hbCB9IGZyb20gXCIuLi9ndWFyYW5pL1N0dWRlbnRGaW5hbFwiO1xuZnVuY3Rpb24gZG5pTWF0Y2hlcihzdHVkZW50LCBkYXRhKSB7XG4gICAgY29uc3QgbWF0Y2hlcyA9IGRhdGEucm93cy5maWx0ZXIoKHMpID0+IHMuZ2V0KFwiZG5pXCIpID09IHN0dWRlbnQuZG5pKTtcbiAgICBpZiAobWF0Y2hlcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSaWdodChtYXRjaGVzWzBdKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiBuZXcgTGVmdChtYXRjaGVzKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgQmFzZUF1dG9maWxsIHtcbiAgICBjb25zdHJ1Y3RvcihwYXJzZXIsIHN1YmplY3ROYW1lKSB7XG4gICAgICAgIHRoaXMucGFyc2VyID0gcGFyc2VyO1xuICAgICAgICB0aGlzLnN1YmplY3ROYW1lID0gc3ViamVjdE5hbWU7XG4gICAgfVxuICAgIHBhcnNlKGNzdikge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLnBhcnNlci5wYXJzZShjc3YpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBhdXRvZmlsbChyb3dzRWxlbWVudCwgYXV0b2ZpbGxEYXRhLCBvdmVyd3JpdGUsIG1hdGNoZXIgPSBkbmlNYXRjaGVyKSB7XG4gICAgICAgIGNvbnN0IHN0dWRlbnRzID0gdGhpcy5nZXRTdHVkZW50cyhyb3dzRWxlbWVudCk7XG4gICAgICAgIGNvbnN0IHVubWF0Y2hlZCA9IFtdO1xuICAgICAgICBmb3IgKGxldCBzdHVkZW50IG9mIHN0dWRlbnRzKSB7XG4gICAgICAgICAgICBjb25zdCBzdHVkZW50Rm9ybUVtcHR5ID0gc3R1ZGVudC5pc0VtcHR5O1xuICAgICAgICAgICAgaWYgKCFvdmVyd3JpdGUgJiYgIXN0dWRlbnRGb3JtRW1wdHkpIHtcbiAgICAgICAgICAgICAgICBzdHVkZW50Lm1hcmtBbHJlYWR5RmlsbGVkU3R1ZGVudCgpO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc3R1ZGVudERhdGFSZXN1bHQgPSBtYXRjaGVyKHN0dWRlbnQsIGF1dG9maWxsRGF0YSk7XG4gICAgICAgICAgICBzdHVkZW50RGF0YVJlc3VsdC5kb1JpZ2h0KChzdHVkZW50RGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuYXV0b2ZpbGxTdHVkZW50KHN0dWRlbnQsIHN0dWRlbnREYXRhKTtcbiAgICAgICAgICAgICAgICBpZiAoc3R1ZGVudEZvcm1FbXB0eSkge1xuICAgICAgICAgICAgICAgICAgICBzdHVkZW50Lm1hcmtGaWxsZWRTdHVkZW50KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzdHVkZW50Lm1hcmtPdmVyd3JpdHRlblN0dWRlbnQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHN0dWRlbnREYXRhUmVzdWx0LmRvTGVmdCgobWF0Y2hlcykgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChzdHVkZW50Rm9ybUVtcHR5KSB7XG4gICAgICAgICAgICAgICAgICAgIHN0dWRlbnQubWFya1VubWF0Y2hlZFN0dWRlbnQobWF0Y2hlcyk7XG4gICAgICAgICAgICAgICAgICAgIHVubWF0Y2hlZC5wdXNoKHN0dWRlbnQuZG5pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN0dWRlbnQubWFya0FscmVhZHlGaWxsZWRTdHVkZW50KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVubWF0Y2hlZDtcbiAgICB9XG4gICAgYXV0b2ZpbGxTdHVkZW50KHN0dWRlbnQsIHN0dWRlbnREYXRhKSB7XG4gICAgICAgIHRoaXMucGFyc2VyLmNvbmZpZy5kYXRhQ29sdW1ucy5mb3JFYWNoKChjb2x1bW4pID0+IHtcbiAgICAgICAgICAgIGlmIChzdHVkZW50RGF0YS5oYXMoY29sdW1uKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGF1dG9maWxsVmFsdWUgPSB0aGlzLmNvbnZlcnRWYWx1ZXMoc3R1ZGVudERhdGEuZ2V0KGNvbHVtbiksIGNvbHVtbik7XG4gICAgICAgICAgICAgICAgY29uc3QgZWxlbWVudCA9IHN0dWRlbnQuZ2V0RmlsbGFibGVGaWVsZEVsZW1lbnQoY29sdW1uKTtcbiAgICAgICAgICAgICAgICBlbGVtZW50LnZhbHVlID0gYXV0b2ZpbGxWYWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgZXZlbnQgPSBuZXcgRXZlbnQoXCJjaGFuZ2VcIik7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnZlcnRWYWx1ZXModmFsdWUsIGNvbHVtbikge1xuICAgICAgICAvLyBUT0RPIHRlc3QgYWx0ZXJuYXRpdmVcbiAgICAgICAgaWYgKGNvbHVtbiBpbiB0aGlzLnBhcnNlci5jb25maWcudmFsdWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZXIuY29uZmlnLnZhbHVlc1tjb2x1bW5dW3ZhbHVlXTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbEN1cnNhZGEgZXh0ZW5kcyBCYXNlQXV0b2ZpbGwge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm9wZXJhdGlvblR5cGUgPSBcImN1cnNhZGFcIjtcbiAgICB9XG4gICAgZ2V0U3R1ZGVudHMocm93c0VsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20ocm93c0VsZW1lbnQubWFwKHIgPT4gbmV3IFN0dWRlbnRDdXJzYWRhKHIpKSk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEF1dG9maWxsRmluYWwgZXh0ZW5kcyBCYXNlQXV0b2ZpbGwge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLm9wZXJhdGlvblR5cGUgPSBcImZpbmFsXCI7XG4gICAgfVxuICAgIGdldFN0dWRlbnRzKHJvd3NFbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKHJvd3NFbGVtZW50Lm1hcChyID0+IG5ldyBTdHVkZW50RmluYWwocikpKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBmcm9tSFRNTCwgYXBwZW5kQ2hpbGRyZW4sIFVJIH0gZnJvbSBcIi4uL3V0aWxzL2RvbV91dGlsc1wiO1xuaW1wb3J0IHsgQXV0b2ZpbGxPdmVyd3JpdGVDb25maWdVSSB9IGZyb20gXCIuL2F1dG9maWxsX292ZXJ3cml0ZV91aVwiO1xuaW1wb3J0IHsgQXV0b2ZpbGxSZXN1bHRVSSB9IGZyb20gXCIuL2F1dG9maWxsX3Jlc3VsdF91aVwiO1xuaW1wb3J0IHsgQXV0b2ZpbGxJbnB1dFVJIH0gZnJvbSBcIi4vYXV0b2ZpbGxfaW5wdXRfdWlcIjtcbmV4cG9ydCBjbGFzcyBBdXRvZmlsbENvbmZpZ1VJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKGF1dG9maWxsLCBvblBhcnNlQ2FsbGJhY2ssIHNldHRpbmdzKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucm9vdCA9IGZyb21IVE1MKGA8ZGl2IGlkPVwiYXV0b2ZpbGxDb25maWdcIiA+PC9kaXY+YCk7XG4gICAgICAgIGNvbnN0IGlucHV0Q1NWID0gc2V0dGluZ3MuZ2V0QXV0b2ZpbGxEYXRhKGF1dG9maWxsLm9wZXJhdGlvblR5cGUsIGF1dG9maWxsLnN1YmplY3ROYW1lKTtcbiAgICAgICAgY29uc3QgYXV0b2ZpbGxSZXN1bHRVSSA9IG5ldyBBdXRvZmlsbFJlc3VsdFVJKDUpO1xuICAgICAgICBjb25zdCBpbnB1dFVwZGF0ZSA9IChpbnB1dENTVikgPT4ge1xuICAgICAgICAgICAgc2V0dGluZ3Muc2V0QXV0b2ZpbGxEYXRhKGF1dG9maWxsLm9wZXJhdGlvblR5cGUsIGF1dG9maWxsLnN1YmplY3ROYW1lLCBpbnB1dENTVik7XG4gICAgICAgICAgICBzZXR0aW5ncy5zYXZlKCk7XG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBhdXRvZmlsbC5wYXJzZShpbnB1dENTVik7XG4gICAgICAgICAgICBhdXRvZmlsbFJlc3VsdFVJLnVwZGF0ZSh0aGlzLmRhdGEpO1xuICAgICAgICAgICAgb25QYXJzZUNhbGxiYWNrKHRoaXMuZGF0YSk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGlucHV0VUkgPSBuZXcgQXV0b2ZpbGxJbnB1dFVJKGlucHV0Q1NWLCBpbnB1dFVwZGF0ZSwgYXV0b2ZpbGwucGFyc2VyLmNvbmZpZy5rZXlDb2x1bW5zLCBhdXRvZmlsbC5wYXJzZXIuY29uZmlnLmRhdGFDb2x1bW5zKTtcbiAgICAgICAgY29uc3QgYXV0b2ZpbGxPdmVyd3JpdGVDb25maWdVSSA9IG5ldyBBdXRvZmlsbE92ZXJ3cml0ZUNvbmZpZ1VJKHNldHRpbmdzKTtcbiAgICAgICAgYXBwZW5kQ2hpbGRyZW4odGhpcy5yb290LCBbYXV0b2ZpbGxPdmVyd3JpdGVDb25maWdVSS5yb290LCBpbnB1dFVJLnJvb3QsIGF1dG9maWxsUmVzdWx0VUkucm9vdF0pO1xuICAgICAgICBpbnB1dFVwZGF0ZShpbnB1dENTVik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZnJvbUhUTUwsIFVJIH0gZnJvbSBcIi4uL3V0aWxzL2RvbV91dGlsc1wiO1xuZXhwb3J0IGNsYXNzIEF1dG9maWxsSW5wdXRVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3RvcihpbnB1dENTViwgY2hhbmdlQ2FsbGJhY2ssIGtleUNvbHVtbnMsIGRhdGFDb2x1bW5zKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucm9vdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIHRoaXMucm9vdC5pZCA9IFwiYXV0b2ZpbGxJbnB1dFVJXCI7XG4gICAgICAgIGNvbnN0IGxhYmVsVGl0bGUgPSBgRWwgZm9ybWF0byBkZSBlbnRyYWRhIGVzIGRlIHVuIENTViwgY29uIGNhbXBvcyBzZXBhcmFkb3MgcG9yIGVsIGNhcsOhY3RlciAnOycuXFxuU2UgcmVxdWllcmUgY29tbyBtw61uaW1vIHVuYSBjb2x1bW5hIGRlIGlkZW50aWZpY2FjacOzbiB5IHVuYSBjb2x1bW5hIGRlIGRhdG9zOlxcblxuICAgICAgQ29sdW1uYXMgZGUgaWRlbnRpZmljYWNpw7NuOiAke2tleUNvbHVtbnN9LlxuICAgICAgQ29sdW1uYXMgZGUgZGF0b3M6ICR7ZGF0YUNvbHVtbnN9LlxuICAgICAgYDtcbiAgICAgICAgY29uc3QgbGFiZWwgPSBmcm9tSFRNTChgPGxhYmVsIGZvcj1cImF1dG9maWxsSW5wdXRcIiBzdHlsZT1cImRpc3BsYXk6YmxvY2tcIiB0aXRsZT1cIiR7bGFiZWxUaXRsZX1cIj5DYXJnYSBkZSBDU1YgcGFyYSBhdXRvbGxlbmFkbyDwn5uIOjwvbGFiZWw+YCk7XG4gICAgICAgIGNvbnN0IGF1dG9maWxsRGF0YUlucHV0ID0gZnJvbUhUTUwoYFxuICAgICAgICA8dGV4dGFyZWEgdHlwZT1cInRleHRcIiBuYW1lPVwiYXV0b2ZpbGxcIiBcbiAgICAgICAgaWQ9XCJhdXRvZmlsbElucHV0XCI+JHtpbnB1dENTVn08L3RleHRhcmVhPmApO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQobGFiZWwpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQoYXV0b2ZpbGxEYXRhSW5wdXQpO1xuICAgICAgICBhdXRvZmlsbERhdGFJbnB1dC5vbmNoYW5nZSA9IGUgPT4gY2hhbmdlQ2FsbGJhY2soYXV0b2ZpbGxEYXRhSW5wdXQudmFsdWUpO1xuICAgICAgICBhdXRvZmlsbERhdGFJbnB1dC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsIGUgPT4gY2hhbmdlQ2FsbGJhY2soYXV0b2ZpbGxEYXRhSW5wdXQudmFsdWUpKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBmcm9tSFRNTCwgVUkgfSBmcm9tIFwiLi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5leHBvcnQgY2xhc3MgQXV0b2ZpbGxPdmVyd3JpdGVDb25maWdVSSBleHRlbmRzIFVJIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgIHRoaXMucm9vdCA9IGZyb21IVE1MKGA8ZGl2IGlkPVwiYXV0b2ZpbGxPdmVyd3JpdGVcIj48L2Rpdj5gKTtcbiAgICAgICAgY29uc3QgbGFiZWxUaXRsZSA9IFwiU29icmVlc2NyaWJpciB2YWxvcmVzIChub3RhcywgY29uZGljacOzbiwgZmVjaGEsIGV0YykgZXhpc3RlbnRlcyBhbCByZWxsZW5hci5cIjtcbiAgICAgICAgY29uc3QgbGFiZWwgPSBmcm9tSFRNTChgPGxhYmVsIHRpdGxlPVwiJHtsYWJlbFRpdGxlfVwiIHN0eWxlPVwiZGlzcGxheTppbmxpbmU7XCI+U29icmVlc2NyaWJpciB2YWxvcmVzOiA8L2xhYmVsPmApO1xuICAgICAgICBjb25zdCBjaGVja2JveCA9IGZyb21IVE1MKGA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgaWQ9XCJhdXRvZmlsbE92ZXJ3cml0ZUNoZWNrYm94XCIvPmApO1xuICAgICAgICBjaGVja2JveC5jaGVja2VkID0gdGhpcy5zZXR0aW5ncy5vdmVyd3JpdGVPbkF1dG9maWxsO1xuICAgICAgICBjaGVja2JveC5vbmNoYW5nZSA9IChlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzLm92ZXJ3cml0ZU9uQXV0b2ZpbGwgPSBjaGVja2JveC5jaGVja2VkO1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncy5zYXZlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZChsYWJlbCk7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZChjaGVja2JveCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZnJvbUhUTUwsIFVJIH0gZnJvbSBcIi4uL3V0aWxzL2RvbV91dGlsc1wiO1xuaW1wb3J0IHsgbWFwTWFwIH0gZnJvbSBcIi4uL3V0aWxzL3V0aWxzXCI7XG5mdW5jdGlvbiByb3dUb1N0cmluZyhyb3csIGluZGV4KSB7XG4gICAgY29uc3QgZGF0YSA9IEFycmF5LmZyb20obWFwTWFwKHJvdywgKGssIHYpID0+IFtrLCBgJHtrfT0ke3Z9YF0pLnZhbHVlcygpKS5qb2luKFwiLCBcIik7XG4gICAgcmV0dXJuIGAke2luZGV4fTogJHtkYXRhfWA7XG59XG5mdW5jdGlvbiBhdXRvZmlsbERhdGFUb1N0cmluZyhyb3dzKSB7XG4gICAgbGV0IGFzU3RyID0gcm93cy5tYXAoKHYsIGksIGEpID0+IHJvd1RvU3RyaW5nKHYsIGkpKTtcbiAgICByZXR1cm4gYXNTdHIuam9pbihcIlxcblwiKTtcbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbFJlc3VsdFVJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKG1heFJvd3MgPSA1KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMubWF4Um93cyA9IG1heFJvd3M7XG4gICAgICAgIHRoaXMucm9vdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgIHRoaXMucmVzdWx0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRleHRhcmVhXCIpO1xuICAgICAgICB0aGlzLnN0YXR1cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICBjb25zdCBhdXRvZmlsbERhdGFWaWV3ZXJMYWJlbCA9IGZyb21IVE1MKGA8cCBzdHlsZT1cImRpc3BsYXk6YmxvY2tcIj5SZXN1bHRhZG8gZGUgbGEgY2FyZ2E6IDwvcD5gKTtcbiAgICAgICAgYXV0b2ZpbGxEYXRhVmlld2VyTGFiZWwuYXBwZW5kQ2hpbGQodGhpcy5zdGF0dXMpO1xuICAgICAgICB0aGlzLnJlc3VsdC5pZCA9IFwiYXV0b2ZpbGxSZXN1bHRcIjtcbiAgICAgICAgdGhpcy5yZXN1bHQuZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQoYXV0b2ZpbGxEYXRhVmlld2VyTGFiZWwpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQodGhpcy5yZXN1bHQpO1xuICAgIH1cbiAgICB1cGRhdGUocmVzdWx0KSB7XG4gICAgICAgIHJlc3VsdC5kb0xlZnQoZXJyb3IgPT4ge1xuICAgICAgICAgICAgdGhpcy5yZXN1bHQudmFsdWUgPSBlcnJvcjtcbiAgICAgICAgICAgIHRoaXMuc3RhdHVzLmlubmVyVGV4dCA9IFwi4p2MXCI7XG4gICAgICAgIH0pO1xuICAgICAgICByZXN1bHQuZG9SaWdodChjc3YgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc2hvcnRSb3dzID0gY3N2LnJvd3Muc2xpY2UoMCwgTWF0aC5taW4odGhpcy5tYXhSb3dzLCBjc3Yucm93cy5sZW5ndGgpKTtcbiAgICAgICAgICAgIHRoaXMucmVzdWx0LnZhbHVlID0gYCR7YXV0b2ZpbGxEYXRhVG9TdHJpbmcoc2hvcnRSb3dzKX1gO1xuICAgICAgICAgICAgdGhpcy5zdGF0dXMuaW5uZXJUZXh0ID0gYOKchSAoRmlsYXM6ICR7Y3N2LnJvd3MubGVuZ3RofSwgQ29sdW1uYXM6ICR7Y3N2LmhlYWRlci5sZW5ndGh9KWA7XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGZyb21IVE1MLCBVSSB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmV4cG9ydCBjbGFzcyBDb3VudGVyVUkgZXh0ZW5kcyBVSSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucm9vdCA9IGZyb21IVE1MKGA8c3BhbiBjbGFzcz1cImNvdW50ZXJVSVwiPiAgPC9zcGFuPmApO1xuICAgICAgICB0aGlzLmNvdW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG4gICAgICAgIHRoaXMuaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICB0aGlzLmljb24uaW5uZXJIVE1MID0gXCIg4pePXCI7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZCh0aGlzLmNvdW50KTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKHRoaXMuaWNvbik7XG4gICAgfVxuICAgIHVwZGF0ZShjb3VudCwgdG90YWwpIHtcbiAgICAgICAgdGhpcy5jb3VudC5pbm5lckhUTUwgPSBgJHtjb3VudH0vJHt0b3RhbH1gO1xuICAgICAgICBjb25zdCByYXRlID0gY291bnQgLyB0b3RhbDtcbiAgICAgICAgY29uc3QgaHVlID0gKHJhdGUgKiAxMjApLnRvU3RyaW5nKDEwKTtcbiAgICAgICAgdGhpcy5pY29uLnN0eWxlLmNvbG9yID0gYGhzbCgke2h1ZX0sNzAlLDM1JSlgO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBQcm9ncmVzc1VJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKGlkLCBsYWJlbCwgdGl0bGUpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5yb290ID0gZnJvbUhUTUwoYDxzcGFuIGlkPVwic3RhdHNVSUNvbXBsZXRlXCIgY2xhc3M9XCJwcm9ncmVzc1VJXCIgPiAgPC9zcGFuPmApO1xuICAgICAgICB0aGlzLnJvb3QudGl0bGUgPSB0aXRsZTtcbiAgICAgICAgdGhpcy5yb290LmlkID0gaWQ7XG4gICAgICAgIGNvbnN0IGxhYmVsRWxlbWVudCA9IGZyb21IVE1MKGA8c3Bhbj4gJHtsYWJlbH0gPC9zcGFuPmApO1xuICAgICAgICB0aGlzLmNvdW50ID0gbmV3IENvdW50ZXJVSSgpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQobGFiZWxFbGVtZW50KTtcbiAgICAgICAgdGhpcy5yb290LmFwcGVuZENoaWxkKHRoaXMuY291bnQucm9vdCk7XG4gICAgfVxuICAgIHVwZGF0ZShjb3VudCwgdG90YWwpIHtcbiAgICAgICAgdGhpcy5jb3VudC51cGRhdGUoY291bnQsIHRvdGFsKTtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgU3R1ZGVudENoYW5nZVVJIGV4dGVuZHMgVUkge1xuICAgIGNvbnN0cnVjdG9yKHJvd3NfZWxlbWVudCwgYXV0b2ZpbGwpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy5yb3dzX2VsZW1lbnQgPSByb3dzX2VsZW1lbnQ7XG4gICAgICAgIHRoaXMuYXV0b2ZpbGwgPSBhdXRvZmlsbDtcbiAgICAgICAgcm93c19lbGVtZW50LmZvckVhY2goKGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0cyA9IGUucXVlcnlTZWxlY3RvckFsbChcImlucHV0LCBzZWxlY3RcIik7XG4gICAgICAgICAgICBpbnB1dHMuZm9yRWFjaCgoaSkgPT4ge1xuICAgICAgICAgICAgICAgIGkuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25TdHVkZW50Q2hhbmdlKCk7XG4gICAgICAgICAgICAgICAgfSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgaS5hZGRFdmVudExpc3RlbmVyKFwia2V5dXBcIiwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uU3R1ZGVudENoYW5nZSgpO1xuICAgICAgICAgICAgICAgIH0sIHRydWUpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBnZXRTdHVkZW50cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuYXV0b2ZpbGwuZ2V0U3R1ZGVudHModGhpcy5yb3dzX2VsZW1lbnQpO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBdXRvZmlsbFN0YXRzVUkgZXh0ZW5kcyBTdHVkZW50Q2hhbmdlVUkge1xuICAgIGNvbnN0cnVjdG9yKHJvd3NfZWxlbWVudCwgYXV0b2ZpbGwpIHtcbiAgICAgICAgc3VwZXIocm93c19lbGVtZW50LCBhdXRvZmlsbCk7XG4gICAgICAgIHRoaXMucm9vdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICB0aGlzLmZpZWxkQ291bnRlcnMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMucm9vdC5pZCA9IFwic3RhdHNVSVwiO1xuICAgICAgICB0aGlzLmNvdW50Q29tcGxldGUgPSBuZXcgUHJvZ3Jlc3NVSShcInN0YXRzVUlDb21wbGV0ZVwiLCBcIkNvbXBsZXRvXCIsIFwiRXN0dWRpYW50ZXMgY29uIGluZm9ybWFjacOzbiBjb21wbGV0YSAobm8gY29uc2lkZXJhIGVsIGNhbXBvIG9ic2VydmFjaW9uZXMpXCIpO1xuICAgICAgICB0aGlzLmNvdW50Tm9uRW1wdHkgPSBuZXcgUHJvZ3Jlc3NVSShcInN0YXRzVUlOb25FbXB0eVwiLCBcIkNvbiBkYXRvc1wiLCBcIkVzdHVkaWFudGVzIGNvbiBpbmZvcm1hY2nDs24gYWxnw7puIGRhdG8gY29tcGxldGFkbywgcGVybyBubyB0b2RvcyAobm8gY29uc2lkZXJhIGVsIGNhbXBvIG9ic2VydmFjaW9uZXMpXCIpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQodGhpcy5jb3VudE5vbkVtcHR5LnJvb3QpO1xuICAgICAgICB0aGlzLnJvb3QuYXBwZW5kQ2hpbGQodGhpcy5jb3VudENvbXBsZXRlLnJvb3QpO1xuICAgICAgICAvLyBmb3JjZSB1cGRhdGUgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgdGhpcy5vblN0dWRlbnRDaGFuZ2UoKTtcbiAgICB9XG4gICAgb25TdHVkZW50Q2hhbmdlKCkge1xuICAgICAgICBjb25zdCBzdHVkZW50cyA9IHRoaXMuYXV0b2ZpbGwuZ2V0U3R1ZGVudHModGhpcy5yb3dzX2VsZW1lbnQpO1xuICAgICAgICBjb25zdCB0b3RhbCA9IHN0dWRlbnRzLmxlbmd0aDtcbiAgICAgICAgY29uc3Qgbm9uRW1wdHkgPSBzdHVkZW50cy5maWx0ZXIoKHMpID0+ICEocy5pc0VtcHR5KSkubGVuZ3RoO1xuICAgICAgICBjb25zdCBjb21wbGV0ZSA9IHN0dWRlbnRzLmZpbHRlcigocykgPT4gcy5pc0Z1bGwpLmxlbmd0aDtcbiAgICAgICAgdGhpcy5jb3VudE5vbkVtcHR5LnVwZGF0ZShub25FbXB0eSwgdG90YWwpO1xuICAgICAgICB0aGlzLmNvdW50Q29tcGxldGUudXBkYXRlKGNvbXBsZXRlLCB0b3RhbCk7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIENvbHVtblN0YXR1c1VJIGV4dGVuZHMgU3R1ZGVudENoYW5nZVVJIHtcbiAgICBjb25zdHJ1Y3Rvcihyb3dzX2VsZW1lbnQsIGF1dG9maWxsLCBmaWVsZCwgaGVhZGVyKSB7XG4gICAgICAgIHN1cGVyKHJvd3NfZWxlbWVudCwgYXV0b2ZpbGwpO1xuICAgICAgICB0aGlzLmZpZWxkID0gZmllbGQ7XG4gICAgICAgIHRoaXMuaGVhZGVyID0gaGVhZGVyO1xuICAgICAgICAvLyBjcmVhdGUgQ291bnRlclVJIG9iamVjdHMgZm9yIGVhY2ggZmllbGQvY29sdW1uXG4gICAgICAgIC8vIGNvbnN0IGhlYWRlckVsZW1lbnRzID0gQXJyYXkuZnJvbShcbiAgICAgICAgLy8gICBkb2N1bWVudFxuICAgICAgICAvLyAgICAgLmdldEVsZW1lbnRCeUlkKFwicmVuZ2xvbmVzXCIpXG4gICAgICAgIC8vICAgICAucXVlcnlTZWxlY3RvcihcInRoZWFkXCIpXG4gICAgICAgIC8vICAgICAucXVlcnlTZWxlY3RvckFsbChcInRoXCIpXG4gICAgICAgIC8vICk7XG4gICAgICAgIC8vIGNvbnN0IGZpZWxkVG9JbmRleCA9IHsgZmVjaGE6IDMsIG5vdGE6IDQsIHJlc3VsdGFkbzogNSwgY29uZGljaW9uOiA2IH07XG4gICAgICAgIC8vIGNvbnN0IGhlYWRlciA9IGhlYWRlckVsZW1lbnRzW2ZpZWxkVG9JbmRleFtmXV1cbiAgICAgICAgLy8gdGhpcy5maWVsZENvdW50ZXJzLnNldChmLCBjb3VudGVyVUkpO1xuICAgICAgICB0aGlzLmNvdW50ZXJVSSA9IG5ldyBDb3VudGVyVUkoKTtcbiAgICAgICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgaGVhZGVyLmFwcGVuZENoaWxkKGNvbnRhaW5lcik7XG4gICAgICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZCh0aGlzLmNvdW50ZXJVSS5yb290KTtcbiAgICAgICAgdGhpcy5vblN0dWRlbnRDaGFuZ2UoKTtcbiAgICB9XG4gICAgb25TdHVkZW50Q2hhbmdlKCkge1xuICAgICAgICBjb25zdCBzdHVkZW50cyA9IHRoaXMuZ2V0U3R1ZGVudHMoKTtcbiAgICAgICAgY29uc3QgY291bnQgPSBzdHVkZW50cy5tYXAoKHMpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBzLmdldEZpbGxhYmxlRmllbGQodGhpcy5maWVsZCkgIT09IFwiXCIgPyAxIDogMDtcbiAgICAgICAgfSkucmVkdWNlKChhLCBiKSA9PiBhICsgYiwgMCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHN0dWRlbnRzKVxuICAgICAgICB0aGlzLmNvdW50ZXJVSS51cGRhdGUoY291bnQsIHN0dWRlbnRzLmxlbmd0aCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQXV0b2ZpbGxDb25maWdVSSB9IGZyb20gXCIuL2F1dG9maWxsX2NvbmZpZ191aVwiO1xuaW1wb3J0IHsgZnJvbUhUTUwsIFVJLCB0b2dnbGVFbGVtZW50LCB9IGZyb20gXCIuLi91dGlscy9kb21fdXRpbHNcIjtcbmltcG9ydCB7IEF1dG9maWxsU3RhdHNVSSB9IGZyb20gXCIuL2F1dG9maWxsX3N0YXR1c191aVwiO1xuZnVuY3Rpb24gc2hvcnRlblRvb2xCdXR0b25zTmFtZXMoKSB7XG4gICAgY29uc3QgYXV0b2NvbXBsZXRlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJqcy1jb2xhcHNhci1hdXRvY29tcGxldGFyXCIpO1xuICAgIGlmIChhdXRvY29tcGxldGUpIHtcbiAgICAgICAgYXV0b2NvbXBsZXRlLmNoaWxkcmVuWzFdLmlubmVySFRNTCA9IFwiQXV0b2NvbXBsZXRhciBiw6FzaWNvXCI7XG4gICAgfVxuICAgIGNvbnN0IHNjYWxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ2ZXJfZXNjYWxhX3JlZ3VsYXJpZGFkXCIpO1xuICAgIGlmIChzY2FsZSkge1xuICAgICAgICBzY2FsZS5pbm5lckhUTUwgPSBcIkdsb3NhcmlvXCI7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEF1dG9maWxsVUkgZXh0ZW5kcyBVSSB7XG4gICAgY29uc3RydWN0b3Iocm93c0VsZW1lbnQsIGF1dG9maWxsLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnJvd3NFbGVtZW50ID0gcm93c0VsZW1lbnQ7XG4gICAgICAgIHRoaXMuYXV0b2ZpbGwgPSBhdXRvZmlsbDtcbiAgICAgICAgLy8gQ3JlYXRlIGEgYmFyIGFib3ZlIG1haW4gZm9ybVxuICAgICAgICB0aGlzLnJvb3QgPSBmcm9tSFRNTChgPGRpdiBpZD1cImF1dG9maWxsQmFyXCI+IDwvZGl2PmApO1xuICAgICAgICAvLyBhZGQgYSBjb250YWluZXIgd2l0aCB0aGUgYXV0b2ZpbGwgY29uZmlnLCBhIHRvZ2dsZSBidXR0b24gdG8gb3Blbi9jbG9zZSBpdCwgYW5kIGFuIGF1dG9maWxsIGJ1dHRvbiB0byBvcGVyYXRlIGl0XG4gICAgICAgIGNvbnN0IHRvZ2dsZUJ1dHRvbiA9IGZyb21IVE1MKGA8YnV0dG9uIGlkPVwiYXV0b2ZpbGxBZHZhbmNlZFwiIGNsYXNzPVwiYnRuIGJ0bi1zbWFsbFwiIGhyZWY9XCIjXCIgdGl0bGU9XCJDYXJnYXIgbG9zIGRhdG9zIGVuIGZvcm1hdG8gY3N2IHBhcmEgbGEgbWF0ZXJpYSBhY3R1YWwgZGVzZGUgZG9uZGUgc2Ugb2J0aWVuZW4gbG9zIGRhdG9zIHBhcmEgcmVsbGVuYXIuXCI+PGkgICBjbGFzcz1cImljb24td3JlbmNoXCI+PC9pPiBDb25maWd1cmFyIGF1dG9jb21wbGV0YWRvIDwvYnV0dG9uPmApO1xuICAgICAgICBjb25zdCBhdXRvZmlsbFN0YXJ0QnV0dG9uID0gZnJvbUhUTUwoYDxidXR0b24gdHlwZT0nYnV0dG9uJyBjbGFzcz1cImJ0biBidG4tc21hbGxcIiB0aXRsZT1cIkF1dG9jb21wbGV0YXIgZWwgZm9ybXVsYXJpbyBlbiBiYXNlIGEgbG9zIGRhdG9zIGVuIGZvcm1hdG8gY3N2IGNhcmdhZG9zIGVuIGxhIGNvbmZpZ3VyYWNpw7NuXCI+IPCfk50gQXV0b2NvbXBsZXRhciA8L2J1dHRvbj5gKTtcbiAgICAgICAgYXV0b2ZpbGxTdGFydEJ1dHRvbi5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgICAgICAgYXV0b2ZpbGxDb25maWdVSS5kYXRhLmRvUmlnaHQoKGNzdikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVubWF0Y2hlZCA9IHRoaXMuYXV0b2ZpbGwuYXV0b2ZpbGwocm93c0VsZW1lbnQsIGNzdiwgc2V0dGluZ3Mub3ZlcndyaXRlT25BdXRvZmlsbCk7XG4gICAgICAgICAgICAgICAgLy8gY29uc3QgYWxsVW5tYXRjaGVkID0gZ2V0U2V0dGluZ3MoU2V0dGluZ3NLZXlzLlVubWF0Y2hlZCkgYXMgQXJyYXk8b2JqZWN0PjtcbiAgICAgICAgICAgICAgICAvLyBjb25zdCBuZXdVbm1hdGNoZWQgPSBuZXcgU2V0KGFsbFVubWF0Y2hlZC5jb25jYXQodW5tYXRjaGVkKSk7XG4gICAgICAgICAgICAgICAgLy8gc2V0U2V0dGluZ3MoU2V0dGluZ3NLZXlzLlVubWF0Y2hlZCwgQXJyYXkuZnJvbShuZXdVbm1hdGNoZWQpKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjb25maWcgPSBmcm9tSFRNTChgPGRpdiBpZD1cImF1dG9maWxsQ29uZmlnQ29udGFpbmVyXCIgc3R5bGU9XCJkaXNwbGF5Om5vbmU7XCI+IDwvZGl2PmApO1xuICAgICAgICBjb25zdCBjb250cm9scyA9IGZyb21IVE1MKGA8ZGl2IGlkPVwiYXV0b2ZpbGxDb250cm9sc0NvbnRhaW5lclwiPiA8L2Rpdj5gKTtcbiAgICAgICAgdG9nZ2xlQnV0dG9uLm9uY2xpY2sgPSAoKSA9PiB7XG4gICAgICAgICAgICB0b2dnbGVFbGVtZW50KGNvbmZpZywgXCJibG9ja1wiKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc3RhdHNVSSA9IG5ldyBBdXRvZmlsbFN0YXRzVUkocm93c0VsZW1lbnQsIGF1dG9maWxsKTtcbiAgICAgICAgY29udHJvbHMuYXBwZW5kQ2hpbGQoc3RhdHNVSS5yb290KTtcbiAgICAgICAgY29udHJvbHMuYXBwZW5kQ2hpbGQodG9nZ2xlQnV0dG9uKTtcbiAgICAgICAgY29udHJvbHMuYXBwZW5kQ2hpbGQoYXV0b2ZpbGxTdGFydEJ1dHRvbik7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZChjb250cm9scyk7XG4gICAgICAgIHRoaXMucm9vdC5hcHBlbmRDaGlsZChjb25maWcpO1xuICAgICAgICBjb25zdCBhdXRvZmlsbENvbmZpZ1VJID0gbmV3IEF1dG9maWxsQ29uZmlnVUkoYXV0b2ZpbGwsIHJlc3VsdCA9PiB7XG4gICAgICAgICAgICByZXN1bHQuZG9MZWZ0KGVycm9yID0+IHtcbiAgICAgICAgICAgICAgICBhdXRvZmlsbFN0YXJ0QnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmVzdWx0LmRvUmlnaHQoY3N2ID0+IHtcbiAgICAgICAgICAgICAgICBhdXRvZmlsbFN0YXJ0QnV0dG9uLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSwgc2V0dGluZ3MpO1xuICAgICAgICBjb25maWcuYXBwZW5kQ2hpbGQoYXV0b2ZpbGxDb25maWdVSS5yb290KTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gYWRkQXV0b2ZpbGxVSShyb3dzLCBzZXR0aW5ncywgYXV0b2ZpbGwpIHtcbiAgICBjb25zdCBhdXRvZmlsbFVJID0gbmV3IEF1dG9maWxsVUkocm93cywgYXV0b2ZpbGwsIHNldHRpbmdzKTtcbiAgICBjb25zdCByZW5nbG9uZXMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJlbmdsb25lc1wiKTtcbiAgICByZW5nbG9uZXMucGFyZW50RWxlbWVudC5pbnNlcnRCZWZvcmUoYXV0b2ZpbGxVSS5yb290LCByZW5nbG9uZXMpO1xuICAgIHNob3J0ZW5Ub29sQnV0dG9uc05hbWVzKCk7XG59XG4iLCJpbXBvcnQgeyB3YWl0Rm9yRWxlbWVudCB9IGZyb20gXCIuL3V0aWxzL2RvbV91dGlsc1wiO1xuY29uc3QgZm9ybV9yZW5nbG9uZXNfc2VsZWN0b3IgPSBcIi5mb3JtLXJlbmdsb25lc1wiO1xuZnVuY3Rpb24gZmFpbGVkX2NhbGxiYWNrKHRpbWVvdXQpIHtcbiAgICBjb25zb2xlLmxvZyhgR1VBUkFOSS1DSFJPTUU6IGFmdGVyIHdhaXRpbmcgZm9yICR7dGltZW91dH0sIGFzc3VtaW5nIHRoZXJlJ3Mgbm8gZm9ybSBpbiBwYWdlLmApO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkoY2FsbGJhY2ssIHRpbWVvdXQgPSA1MDAwLCBhZGRpdGlvbmFsX3dhaXQgPSAxMCkge1xuICAgIGNvbnN0IGZvcm1DYWxsYmFjayA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgZm9ybV9yZW5nbG9uZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGZvcm1fcmVuZ2xvbmVzX3NlbGVjdG9yKTtcbiAgICAgICAgY2FsbGJhY2soZm9ybV9yZW5nbG9uZXMpO1xuICAgIH07XG4gICAgY29uc3QgZmFpbENhbGxiYWNrID0gKCkgPT4geyBmYWlsZWRfY2FsbGJhY2sodGltZW91dCk7IH07XG4gICAgY29uc3Qgd2FpdENhbGxiYWNrID0gKCkgPT4geyBzZXRUaW1lb3V0KGZvcm1DYWxsYmFjaywgYWRkaXRpb25hbF93YWl0KTsgfTtcbiAgICB3YWl0Rm9yRWxlbWVudChmb3JtX3Jlbmdsb25lc19zZWxlY3Rvciwgd2FpdENhbGxiYWNrLCB0aW1lb3V0LCB1bmRlZmluZWQsIGZhaWxDYWxsYmFjayk7XG59XG4vLyBmdW5jdGlvbiB3aGVuX2Zvcm1fcmVuZ2xvbmVzX3JlYWR5X29sZChsaXN0ZW5lcnMpe1xuLy8gICAgIGNvbnN0IGNvbHVtbmEgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NvbHVtbmFfMVwiKTtcbi8vICAgICAgIGlmICghY29sdW1uYSkge1xuLy8gICAgICAgICBjb25zb2xlLmxvZyhcIiNDb2x1bW5hXzEgbm90IGZvdW5kOyBub3QgYSBzdHVkZW50cyBmb3JtLlwiKVxuLy8gICAgICAgICByZXR1cm4gIFxuLy8gICAgIH1cbi8vICAgICBjb25zb2xlLmxvZyhcIlJlZ2lzdGVyaW5nIHRvIGFkZCBzYXZlIGJ1dHRvblwiKVxuLy8gICAgIGNvbnNvbGUubG9nKGNvbHVtbmEpXG4vLyAgICAgb2JzZXJ2ZShjb2x1bW5hLHdoZW5fY29sdW1uYV9jaGFuZ2VzLHtjaGlsZExpc3Q6dHJ1ZSxzdWJ0cmVlOnRydWUgfSxkaXNhYmxlQWZ0ZXJGaXJzdD1mYWxzZSxwYXJhbXM9bGlzdGVuZXJzKVxuLy8gICB9XG4vLyBmdW5jdGlvbiB3aGVuX2NvbHVtbmFfY2hhbmdlcyhvYnNlcnZlcixsaXN0ZW5lcnMpe1xuLy8gICBjb25zdCByZW5nbG9uZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3Jlbmdsb25lc1wiKTtcbi8vICAgaWYgKHJlbmdsb25lcykge1xuLy8gICAgIGNvbnNvbGUubG9nKFwicmVuZ2xvbmVzIGZvdW5kOyBhZGRpbmcgbXV0YXRpb24gb2JzZXJ2ZXJcIilcbi8vICAgICBjb25zb2xlLmxvZyhyZW5nbG9uZXMpXG4vLyAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4vLyAgICAgb2JzZXJ2ZShyZW5nbG9uZXMsd2hlbl9yZW5nbG9uZXNfY2hhbmdlcyx7IHN1YnRyZWU6IHRydWUsY2hpbGRMaXN0OnRydWUgfSx0cnVlLGxpc3RlbmVycykgICAgICAgIFxuLy8gICB9XG4vLyB9XG5leHBvcnQgZnVuY3Rpb24gd2hlbl9yZW5nbG9uZXNfY2hhbmdlcyhvYnNlcnZlciwgbGlzdGVuZXJzKSB7XG4gICAgY29uc3QgZm9ybV9yZW5nbG9uZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmZvcm0tcmVuZ2xvbmVzXCIpO1xuICAgIGlmIChmb3JtX3Jlbmdsb25lcykge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkdVQVJBTkktQ0hST01FOiBGb3JtIHJlbmdsb25lcyBmb3VuZDsgYWRkaW5nIGJ1dHRvblwiKTtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICBsaXN0ZW5lcnMuZm9yRWFjaChsaXN0ZW5lciA9PiBsaXN0ZW5lcihmb3JtX3Jlbmdsb25lcykpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJHVUFSQU5JLUNIUk9NRTogRm9ybSByZW5nbG9uZXMgbm90IGZvdW5kXCIpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3Jlbmdsb25lc1wiKSkgICAgICAgIFxuICAgIH1cbn1cbiIsImltcG9ydCB7IGZyb21IVE1MIH0gZnJvbSBcIi4uL3V0aWxzL2RvbV91dGlsc1wiO1xuZXhwb3J0IGNsYXNzIFN0dWRlbnQge1xuICAgIGdldEZpbGxhYmxlRmllbGRFbGVtZW50KG5hbWUpIHtcbiAgICAgICAgY29uc3QgaSA9IHRoaXMuZmlsbGFibGVGaWVsZHNOYW1lcy5pbmRleE9mKG5hbWUpO1xuICAgICAgICByZXR1cm4gdGhpcy5maWxsYWJsZUZpZWxkc0VsZW1lbnRzW2ldO1xuICAgIH1cbiAgICBnZXRGaWxsYWJsZUZpZWxkKG5hbWUpIHtcbiAgICAgICAgY29uc3QgaSA9IHRoaXMuZmlsbGFibGVGaWVsZHNOYW1lcy5pbmRleE9mKG5hbWUpO1xuICAgICAgICByZXR1cm4gdGhpcy5maWxsYWJsZUZpZWxkc1tpXTtcbiAgICB9XG4gICAgY29uc3RydWN0b3Iocm93KSB7XG4gICAgICAgIHRoaXMucm93ID0gcm93O1xuICAgICAgICB0aGlzLmFkZFJlc3VsdEVtb2ppRWxlbWVudCgpO1xuICAgIH1cbiAgICBhZGRSZXN1bHRFbW9qaUVsZW1lbnQoKSB7XG4gICAgICAgIGlmICh0aGlzLmVtb2ppRWxlbWVudCkge1xuICAgICAgICAgICAgLy8gZG9uJ3QgY3JlYXRlIGVsZW1lbnQgaWYgaXQgYWxyZWFkeSBleGlzdHNcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBhbHVtbm9EaXYgPSB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFwiLmZpY2hhLWFsdW1ub1wiKS5jaGlsZHJlblsxXTtcbiAgICAgICAgY29uc3QgZW1vamlFbGVtZW50ID0gZnJvbUhUTUwoYDxzcGFuIGNsYXNzPVwiJHtTdHVkZW50LkVtb2ppQ2xhc3N9XCI+IDxzcGFuPmApO1xuICAgICAgICBhbHVtbm9EaXYuYXBwZW5kQ2hpbGQoZW1vamlFbGVtZW50KTtcbiAgICB9XG4gICAgZ2V0IGVtb2ppRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudC5FbW9qaVNlbGVjdG9yKTtcbiAgICB9XG4gICAgZ2V0IGRuaUVsZW1lbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJvdy5xdWVyeVNlbGVjdG9yKFN0dWRlbnQuZWxlbWVudFNlbGVjdG9ycy5kbmkpO1xuICAgIH1cbiAgICBnZXQgZG5pKCkgeyByZXR1cm4gdGhpcy5kbmlFbGVtZW50LmlubmVyVGV4dC5zcGxpdChcIiBcIilbMV07IH1cbiAgICBnZXQgbm9tYnJlRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudC5lbGVtZW50U2VsZWN0b3JzLm5vbWJyZSk7XG4gICAgfVxuICAgIGdldCBub21icmUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm5vbWJyZUVsZW1lbnQuaW5uZXJUZXh0O1xuICAgIH1cbiAgICBnZXQgZmVjaGFFbGVtZW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yb3cucXVlcnlTZWxlY3RvcihTdHVkZW50LmVsZW1lbnRTZWxlY3RvcnMuZmVjaGEpO1xuICAgIH1cbiAgICBnZXQgZmVjaGEoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZlY2hhRWxlbWVudC52YWx1ZTtcbiAgICB9XG4gICAgc2V0IGZlY2hhKHYpIHtcbiAgICAgICAgdGhpcy5mZWNoYUVsZW1lbnQudmFsdWUgPSB2O1xuICAgIH1cbiAgICBnZXQgbm90YSgpIHtcbiAgICAgICAgY29uc3QgdiA9IHRoaXMubm90YUVsZW1lbnQudmFsdWU7XG4gICAgICAgIC8vIG5vdGEgdXNlcyAtIGFzIG5vIHZhbHVlXG4gICAgICAgIHJldHVybiAodiA9PT0gXCItXCIpID8gXCJcIiA6IHY7XG4gICAgfVxuICAgIHNldCBub3RhKHYpIHtcbiAgICAgICAgLy8gbm90YSB1c2VzIC0gYXMgbm8gdmFsdWVcbiAgICAgICAgdiA9ICh2ID09PSBcIlwiKSA/IFwiLVwiIDogdjtcbiAgICAgICAgdGhpcy5ub3RhRWxlbWVudC52YWx1ZSA9IHY7XG4gICAgfVxuICAgIGdldCByZXN1bHRhZG9FbGVtZW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5yb3cucXVlcnlTZWxlY3RvcihTdHVkZW50LmVsZW1lbnRTZWxlY3RvcnMucmVzdWx0YWRvKTtcbiAgICB9XG4gICAgZ2V0IHJlc3VsdGFkbygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVzdWx0YWRvRWxlbWVudC52YWx1ZTtcbiAgICB9XG4gICAgc2V0IHJlc3VsdGFkbyh2KSB7XG4gICAgICAgIHRoaXMucmVzdWx0YWRvRWxlbWVudC52YWx1ZSA9IHY7XG4gICAgfVxuICAgIGFkZFRvU3R1ZGVudFRpdGxlKG1lc3NhZ2UpIHtcbiAgICAgICAgZnVuY3Rpb24gYXBwZW5kVG9UaXRsZShlbGVtZW50LCBzKSB7XG4gICAgICAgICAgICBlbGVtZW50LnRpdGxlID0gYCR7ZWxlbWVudC50aXRsZX0ke3N9YDtcbiAgICAgICAgfVxuICAgICAgICBhcHBlbmRUb1RpdGxlKHRoaXMubm9tYnJlRWxlbWVudCwgYFxcbiBBdXRvZmlsbDogJHttZXNzYWdlfWApO1xuICAgICAgICBhcHBlbmRUb1RpdGxlKHRoaXMuZG5pRWxlbWVudCwgYFxcbiBBdXRvZmlsbDogJHttZXNzYWdlfWApO1xuICAgICAgICBhcHBlbmRUb1RpdGxlKHRoaXMuZW1vamlFbGVtZW50LCBgXFxuIEF1dG9maWxsOiAke21lc3NhZ2V9YCk7XG4gICAgfVxuICAgIHNldFN0dWRlbnRDbGFzcyhrbGFzcykge1xuICAgICAgICB0aGlzLnJvdy5jbGFzc0xpc3QucmVtb3ZlKC4uLnRoaXMucm93LmNsYXNzTGlzdCk7XG4gICAgICAgIHRoaXMucm93LmNsYXNzTGlzdC5hZGQoa2xhc3MpO1xuICAgIH1cbiAgICBtYXJrRmlsbGVkU3R1ZGVudCgpIHtcbiAgICAgICAgdGhpcy5zZXRTdHVkZW50Q2xhc3MoXCJhdXRvZmlsbGVkU3R1ZGVudFwiKTtcbiAgICAgICAgdGhpcy5hZGRFbW9qaVN0dWRlbnQoXCLinIVcIik7XG4gICAgICAgIHRoaXMuYWRkVG9TdHVkZW50VGl0bGUoXCJoYSBzaWRvIGNvbXBsZXRhZG8gYXV0b21hdGljYW1lbnRlXCIpO1xuICAgIH1cbiAgICBtYXJrT3ZlcndyaXR0ZW5TdHVkZW50KCkge1xuICAgICAgICB0aGlzLnNldFN0dWRlbnRDbGFzcyhcIm1vZGlmaWVkU3R1ZGVudFwiKTtcbiAgICAgICAgdGhpcy5hZGRFbW9qaVN0dWRlbnQoXCLinI/vuI9cIik7XG4gICAgICAgIHRoaXMuYWRkVG9TdHVkZW50VGl0bGUoXCJoYSBzaWRvIGVkaXRhZG8gYXV0b23DoXRpY2FtZW50ZVwiKTtcbiAgICB9XG4gICAgbWFya1VubWF0Y2hlZFN0dWRlbnQobWF0Y2hlcykge1xuICAgICAgICB0aGlzLnNldFN0dWRlbnRDbGFzcyhcInVubWF0Y2hlZFN0dWRlbnRcIik7XG4gICAgICAgIHRoaXMuYWRkRW1vamlTdHVkZW50KFwi4p2MXCIpO1xuICAgICAgICB0aGlzLmFkZFRvU3R1ZGVudFRpdGxlKFwibm8gc2UgcHVkbyBlbmNvbnRyYXIgZW4gZWwgY3N2XCIpO1xuICAgIH1cbiAgICBhZGRFbW9qaVN0dWRlbnQoZW1vamkpIHtcbiAgICAgICAgdGhpcy5lbW9qaUVsZW1lbnQuaW5uZXJUZXh0ID0gYCR7dGhpcy5lbW9qaUVsZW1lbnQuaW5uZXJUZXh0fSR7ZW1vaml9YDtcbiAgICB9XG4gICAgbWFya0FscmVhZHlGaWxsZWRTdHVkZW50KCkge1xuICAgICAgICB0aGlzLnNldFN0dWRlbnRDbGFzcyhcImFscmVhZHlGaWxsZWRTdHVkZW50XCIpO1xuICAgICAgICB0aGlzLmFkZEVtb2ppU3R1ZGVudChcIuKaoO+4j1wiKTtcbiAgICAgICAgdGhpcy5hZGRUb1N0dWRlbnRUaXRsZShcIk5vIHNlIG1vZGlmaWPDsyBwb3JxdWUgeWEgdGVuw61hIHZhbG9yZXMgY2FyZ2Fkb3NcIik7XG4gICAgfVxuICAgIGdldCBlbXB0eUZpZWxkcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsbGFibGVGaWVsZHMuZmlsdGVyKGYgPT4gZiA9PT0gXCJcIik7XG4gICAgfVxuICAgIGdldCBpc0Z1bGwoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmVtcHR5RmllbGRzLmxlbmd0aCA9PT0gMDtcbiAgICB9XG4gICAgZ2V0IGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmVtcHR5RmllbGRzLmxlbmd0aCA9PSB0aGlzLmZpbGxhYmxlRmllbGRzLmxlbmd0aDtcbiAgICB9XG59XG5TdHVkZW50LkVtb2ppQ2xhc3MgPSBcInJlc3VsdC1lbW9qaVwiO1xuU3R1ZGVudC5FbW9qaVNlbGVjdG9yID0gYC4ke1N0dWRlbnQuRW1vamlDbGFzc31gO1xuU3R1ZGVudC5lbGVtZW50U2VsZWN0b3JzID0ge1xuICAgIGRuaTogXCIuaWRlbnRpZmljYWNpb25cIixcbiAgICBub21icmU6IFwiLm5vbWJyZVwiLFxuICAgIGZlY2hhOiBcIi5mZWNoYVwiLFxuICAgIHJlc3VsdGFkbzogXCIucmVzdWx0YWRvXCIsXG4gICAgY29uZGljaW9uOiBcIi5jb25kaWNpb25cIixcbiAgICBvYnNlcnZhY2lvbjogXCIub2JzZXJ2YWNpb25cIixcbn07XG4iLCJpbXBvcnQgeyBTdHVkZW50IH0gZnJvbSBcIi4vU3R1ZGVudFwiO1xuZXhwb3J0IGNsYXNzIFN0dWRlbnRDdXJzYWRhIGV4dGVuZHMgU3R1ZGVudCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuZmlsbGFibGVGaWVsZHNFbGVtZW50cyA9IFt0aGlzLm5vdGFFbGVtZW50LCB0aGlzLmZlY2hhRWxlbWVudCwgdGhpcy5yZXN1bHRhZG9FbGVtZW50LCB0aGlzLmNvbmRpY2lvbkVsZW1lbnRdO1xuICAgIH1cbiAgICBnZXQgY29uZGljaW9uRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudEN1cnNhZGEuZWxlbWVudFNlbGVjdG9ycy5jb25kaWNpb24pO1xuICAgIH1cbiAgICBnZXQgY29uZGljaW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jb25kaWNpb25FbGVtZW50LnZhbHVlO1xuICAgIH1cbiAgICBzZXQgY29uZGljaW9uKHYpIHtcbiAgICAgICAgdGhpcy5jb25kaWNpb25FbGVtZW50LnZhbHVlID0gdjtcbiAgICB9XG4gICAgZ2V0IG9ic2VydmFjaW9uRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoU3R1ZGVudEN1cnNhZGEuZWxlbWVudFNlbGVjdG9ycy5vYnNlcnZhY2lvbik7XG4gICAgfVxuICAgIGdldCBvYnNlcnZhY2lvbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMub2JzZXJ2YWNpb25FbGVtZW50LnZhbHVlO1xuICAgIH1cbiAgICBzZXQgb2JzZXJ2YWNpb24odikge1xuICAgICAgICB0aGlzLm9ic2VydmFjaW9uRWxlbWVudC52YWx1ZSA9IHY7XG4gICAgfVxuICAgIGFzRGljdCgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRuaTogdGhpcy5kbmksXG4gICAgICAgICAgICBub21icmU6IHRoaXMubm9tYnJlLFxuICAgICAgICAgICAgZmVjaGE6IHRoaXMuZmVjaGEsXG4gICAgICAgICAgICBub3RhOiB0aGlzLm5vdGEsXG4gICAgICAgICAgICByZXN1bHRhZG86IHRoaXMucmVzdWx0YWRvLFxuICAgICAgICAgICAgY29uZGljaW9uOiB0aGlzLmNvbmRpY2lvbixcbiAgICAgICAgICAgIG9ic2VydmFjaW9uOiB0aGlzLm9ic2VydmFjaW9uXG4gICAgICAgIH07XG4gICAgfVxuICAgIGdldCBub3RhRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoXCIubm90YV9jdXJzYWRhXCIpO1xuICAgIH1cbiAgICBnZXQgZmlsbGFibGVGaWVsZHNOYW1lcygpIHtcbiAgICAgICAgcmV0dXJuIFtcIm5vdGFcIiwgXCJmZWNoYVwiLCBcInJlc3VsdGFkb1wiLCBcImNvbmRpY2lvblwiXTtcbiAgICB9XG4gICAgZ2V0IGZpbGxhYmxlRmllbGRzKCkge1xuICAgICAgICByZXR1cm4gW3RoaXMubm90YSwgdGhpcy5mZWNoYSwgdGhpcy5yZXN1bHRhZG8sIHRoaXMuY29uZGljaW9uXTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBTdHVkZW50IH0gZnJvbSBcIi4vU3R1ZGVudFwiO1xuZXhwb3J0IGNsYXNzIFN0dWRlbnRGaW5hbCBleHRlbmRzIFN0dWRlbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmZpbGxhYmxlRmllbGRzRWxlbWVudHMgPSBbdGhpcy5ub3RhRWxlbWVudCwgdGhpcy5mZWNoYUVsZW1lbnQsIHRoaXMucmVzdWx0YWRvRWxlbWVudF07XG4gICAgfVxuICAgIGdldCBub3RhRWxlbWVudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucm93LnF1ZXJ5U2VsZWN0b3IoXCIubm90YVwiKTtcbiAgICB9XG4gICAgZ2V0IGZpbGxhYmxlRmllbGRzTmFtZXMoKSB7XG4gICAgICAgIHJldHVybiBbXCJub3RhXCIsIFwiZmVjaGFcIiwgXCJyZXN1bHRhZG9cIl07XG4gICAgfVxuICAgIGdldCBmaWxsYWJsZUZpZWxkcygpIHtcbiAgICAgICAgcmV0dXJuIFt0aGlzLm5vdGEsIHRoaXMuZmVjaGEsIHRoaXMucmVzdWx0YWRvXTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDU1ZDb25maWcgfSBmcm9tIFwiLi9wYXJzZXJcIjtcbmV4cG9ydCBjbGFzcyBDU1ZDdXJzYWRhQ29uZmlnIGV4dGVuZHMgQ1NWQ29uZmlnIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5pZCA9IFwiY3Vyc2FkYVwiO1xuICAgICAgICB0aGlzLmRhdGFDb2x1bW5zID0gW1wiZmVjaGFcIiwgXCJjb25kaWNpb25cIiwgXCJub3RhXCIsIFwicmVzdWx0YWRvXCJdO1xuICAgICAgICB0aGlzLmtleUNvbHVtbnMgPSBbXCJkbmlcIiwgXCJub21icmVcIl07XG4gICAgICAgIHRoaXMuY3N2U2VwYXJhdG9yID0gXCI7XCI7XG4gICAgICAgIHRoaXMudmFsdWVzID0ge1xuICAgICAgICAgICAgbm90YToge1xuICAgICAgICAgICAgICAgIFwiVVwiOiBcIlVcIixcbiAgICAgICAgICAgICAgICBcIkRcIjogXCJEXCIsXG4gICAgICAgICAgICAgICAgXCJBXCI6IFwiQVwiLFxuICAgICAgICAgICAgICAgIFwiLVwiOiBcIlwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlc3VsdGFkbzoge1xuICAgICAgICAgICAgICAgIFwiQXVzZW50ZVwiOiBcIlVcIixcbiAgICAgICAgICAgICAgICBcIlJlcHJvYmFkb1wiOiBcIlJcIixcbiAgICAgICAgICAgICAgICBcIkFwcm9iYWRvXCI6IFwiQVwiLFxuICAgICAgICAgICAgICAgIFwiLVwiOiBcIlwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbmRpY2lvbjoge1xuICAgICAgICAgICAgICAgIFwiQWJhbmRvbm9cIjogXCIyXCIsXG4gICAgICAgICAgICAgICAgXCJBcHJvYmFkb1wiOiBcIjE3NVwiLFxuICAgICAgICAgICAgICAgIFwiRGVzYXByb2JhZG9cIjogXCIxNzRcIixcbiAgICAgICAgICAgICAgICBcIkluc3VmaWNpZW50ZVwiOiBcIjNcIixcbiAgICAgICAgICAgICAgICBcIkxpYnJlXCI6IFwiMVwiLFxuICAgICAgICAgICAgICAgIFwiTm8gUHJvbW9jaW9ub1wiOiBcIjEwN1wiLFxuICAgICAgICAgICAgICAgIFwiUHJvbW9jaW9ub1wiOiBcIjVcIixcbiAgICAgICAgICAgICAgICBcIlJlZ3VsYXJcIjogXCI0XCIsXG4gICAgICAgICAgICAgICAgXCItXCI6IFwiXCIsXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ1NWQ29uZmlnIH0gZnJvbSBcIi4vcGFyc2VyXCI7XG5leHBvcnQgY2xhc3MgQ1NWRmluYWxDb25maWcgZXh0ZW5kcyBDU1ZDb25maWcge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmlkID0gXCJmaW5hbFwiO1xuICAgICAgICB0aGlzLmRhdGFDb2x1bW5zID0gW1wiZmVjaGFcIiwgXCJub3RhXCIsIFwicmVzdWx0YWRvXCJdO1xuICAgICAgICB0aGlzLmtleUNvbHVtbnMgPSBbXCJkbmlcIiwgXCJub21icmVcIl07XG4gICAgICAgIHRoaXMuY3N2U2VwYXJhdG9yID0gXCI7XCI7XG4gICAgICAgIHRoaXMudmFsdWVzID0ge1xuICAgICAgICAgICAgbm90YToge1xuICAgICAgICAgICAgICAgIFwiMFwiOiBcIjBcIixcbiAgICAgICAgICAgICAgICBcIjFcIjogXCIxXCIsXG4gICAgICAgICAgICAgICAgXCIyXCI6IFwiMlwiLFxuICAgICAgICAgICAgICAgIFwiM1wiOiBcIjNcIixcbiAgICAgICAgICAgICAgICBcIjRcIjogXCI0XCIsXG4gICAgICAgICAgICAgICAgXCI1XCI6IFwiNVwiLFxuICAgICAgICAgICAgICAgIFwiNlwiOiBcIjZcIixcbiAgICAgICAgICAgICAgICBcIjdcIjogXCI3XCIsXG4gICAgICAgICAgICAgICAgXCI4XCI6IFwiOFwiLFxuICAgICAgICAgICAgICAgIFwiOVwiOiBcIjlcIixcbiAgICAgICAgICAgICAgICBcIjEwXCI6IFwiMTBcIixcbiAgICAgICAgICAgICAgICBcIi1cIjogXCJcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXN1bHRhZG86IHtcbiAgICAgICAgICAgICAgICBcIkF1c2VudGVcIjogXCJVXCIsXG4gICAgICAgICAgICAgICAgXCJSZXByb2JhZG9cIjogXCJSXCIsXG4gICAgICAgICAgICAgICAgXCJBcHJvYmFkb1wiOiBcIkFcIixcbiAgICAgICAgICAgICAgICBcIi1cIjogXCJcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTGVmdCwgUmlnaHQsIGRpY3RGcm9tTGlzdHMgfSBmcm9tIFwiLi4vdXRpbHMvdXRpbHNcIjtcbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZUNTVihpbnB1dCwgc2VwYXJhdG9yID0gXCI7XCIpIHtcbiAgICByZXR1cm4gaW5wdXQudHJpbSgpLmxlbmd0aCA+IDA7XG59XG5mdW5jdGlvbiB0b0VudHJpZXMoYSkge1xuICAgIHJldHVybiBhLm1hcCgodmFsdWUsIGluZGV4KSA9PiBbaW5kZXgsIHZhbHVlXSk7XG59XG5leHBvcnQgY2xhc3MgQ1NWUGFyc2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlKSB7XG4gICAgICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnQ1NWUGFyc2VFcnJvcic7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIENTViB7XG4gICAgY29uc3RydWN0b3Iocm93cywgaGVhZGVyKSB7XG4gICAgICAgIHRoaXMucm93cyA9IHJvd3M7XG4gICAgICAgIHRoaXMuaGVhZGVyID0gaGVhZGVyO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUNTVihpbnB1dCwgc2VwYXJhdG9yID0gXCI7XCIsIG5vcm1hbGl6ZV9oZWFkZXIgPSBmYWxzZSkge1xuICAgIGlucHV0ID0gaW5wdXQudHJpbSgpO1xuICAgIGlmIChpbnB1dCA9PT0gXCJcIikge1xuICAgICAgICByZXR1cm4gbmV3IFJpZ2h0KG5ldyBDU1YoW10sIFtdKSk7XG4gICAgfVxuICAgIGNvbnN0IGxpbmVzID0gaW5wdXQuc3BsaXQoL1xcclxcbnxcXG4vKS5tYXAociA9PiByLnRyaW0oKSk7XG4gICAgY29uc3Qgbm9uZW1wdHlMaW5lcyA9IGxpbmVzLmZpbHRlcihyID0+IHIubGVuZ3RoID4gMCk7XG4gICAgY29uc3Qgc3BsaXRMaW5lcyA9IG5vbmVtcHR5TGluZXMubWFwKChsKSA9PiBsLnNwbGl0KHNlcGFyYXRvcikpO1xuICAgIGNvbnN0IGJhc2ljSGVhZGVyID0gc3BsaXRMaW5lcy5zaGlmdCgpO1xuICAgIGNvbnN0IGhlYWRlciA9IG5vcm1hbGl6ZV9oZWFkZXIgPyBiYXNpY0hlYWRlci5tYXAoaCA9PiBoLnRyaW0oKS50b0xvd2VyQ2FzZSgpKSA6IGJhc2ljSGVhZGVyO1xuICAgIGNvbnN0IHJvd3MgPSBbXTtcbiAgICBmb3IgKGNvbnN0IFtpLCB2YWx1ZXNdIG9mIHRvRW50cmllcyhzcGxpdExpbmVzKSkge1xuICAgICAgICBpZiAoaGVhZGVyLmxlbmd0aCAhPSB2YWx1ZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IExlZnQoYE51bWJlciBvZiB2YWx1ZXMgaW4gcm93ICR7aX0gZG9lcyBub3QgbWF0Y2ggbnVtYmVyIG9mIHZhbHVlcyBpbiBoZWFkZXIuXFxuSGVhZGVyOiBcIiR7aGVhZGVyfVwiXFxuUm93ICR7aX06IFwiJHt2YWx1ZXN9XCJgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByb3cgPSBkaWN0RnJvbUxpc3RzKGhlYWRlciwgdmFsdWVzKTtcbiAgICAgICAgcm93cy5wdXNoKHJvdyk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgUmlnaHQobmV3IENTVihyb3dzLCBoZWFkZXIpKTtcbn1cbi8vIHBhcnNlQ1NWKFwiZG5pO2gxXFxuMjM7djFcXG4gIFxcbiAgXFxuXCIpXG4iLCJpbXBvcnQgeyBTb21lLCBOb25lLCBpbnRlcnNlY3Rpb24sIExlZnQsIFJpZ2h0LCB9IGZyb20gXCIuLi91dGlscy91dGlsc1wiO1xuaW1wb3J0IHsgcGFyc2VDU1YgfSBmcm9tIFwiLi9jc3ZcIjtcbmV4cG9ydCBjbGFzcyBDU1ZDb25maWcge1xufVxuZnVuY3Rpb24gY2hlY2tWYWx1ZXMoY29sdW1uLCB2YWx1ZXMsIHJvd3MpIHtcbiAgICBjb25zdCByb3dzV2l0aE51bWJlciA9IHJvd3MubWFwKCh2LCBpLCBhKSA9PiBbdiwgaSArIDJdKTtcbiAgICBjb25zdCByb3dzV2l0aFdyb25nVmFsdWVzID0gcm93c1dpdGhOdW1iZXIuZmlsdGVyKChbcywgaV0sIGopID0+ICF2YWx1ZXMuaW5jbHVkZXMocy5nZXQoY29sdW1uKSkpO1xuICAgIHJldHVybiByb3dzV2l0aFdyb25nVmFsdWVzLmxlbmd0aCA9PT0gMFxuICAgICAgICA/IG5ldyBOb25lKClcbiAgICAgICAgOiBuZXcgU29tZShyb3dzV2l0aFdyb25nVmFsdWVzKTtcbn1cbmZ1bmN0aW9uIHByaW50Um93KHJvd0luZGV4LCBzZXBhcmF0b3IpIHtcbiAgICBjb25zdCBbcm93LCBpbmRleF0gPSByb3dJbmRleDtcbiAgICByZXR1cm4gYEZpbGEgJHtpbmRleH06ICR7QXJyYXkuZnJvbShyb3cudmFsdWVzKCkpLmpvaW4oc2VwYXJhdG9yKX1gO1xufVxuZnVuY3Rpb24gcHJpbnRBdXRvZmlsbERhdGEoZGF0YSwgaGVhZGVyLCBzZXBhcmF0b3IpIHtcbiAgICBsZXQgaGVhZGVyUm93ID0gaGVhZGVyLmpvaW4oc2VwYXJhdG9yKTtcbiAgICBsZXQgcm93cyA9IGRhdGEubWFwKHIgPT4gcHJpbnRSb3cociwgc2VwYXJhdG9yKSkuam9pbihcIlxcblwiKTtcbiAgICByZXR1cm4gYCR7aGVhZGVyUm93fVxcbiR7cm93c31cXG5gO1xufVxuZXhwb3J0IGNsYXNzIEF1dG9maWxsUGFyc2VyIHtcbiAgICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICAgICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgfVxuICAgIHBhcnNlKGRhdGEpIHtcbiAgICAgICAgY29uc3QgcGFyc2VSZXN1bHQgPSBwYXJzZUNTVihkYXRhLCB0aGlzLmNvbmZpZy5jc3ZTZXBhcmF0b3IsIHRydWUpO1xuICAgICAgICBpZiAocGFyc2VSZXN1bHQuaXNMZWZ0KCkpIHtcbiAgICAgICAgICAgIHJldHVybiBwYXJzZVJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjc3YgPSBwYXJzZVJlc3VsdC5nZXQoKTtcbiAgICAgICAgY29uc3Qga2V5Q29sdW1uc1ByZXNlbnQgPSBpbnRlcnNlY3Rpb24odGhpcy5jb25maWcua2V5Q29sdW1ucywgY3N2LmhlYWRlcik7XG4gICAgICAgIGlmIChrZXlDb2x1bW5zUHJlc2VudC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgTGVmdChgRWwgQ1NWIG5vIGNvbnRpZW5lIG5pbmd1bmEgZGUgbGFzIGNvbHVtbmFzIG5lY2VzYXJpYXMgcGFyYSBpZGVudGlmaWNhciBlc3R1ZGlhbnRlcy4gXFxuIC0gQ29sdW1uYXMgZGUgaWRlbnRpZmljYWNpw7NuOiAke3RoaXMuY29uZmlnLmtleUNvbHVtbnN9LiBcXG4gLSBDb2x1bW5hcyBkZWwgY3N2OiAke2Nzdi5oZWFkZXJ9YCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGF0YUNvbHVtbnNQcmVzZW50ID0gaW50ZXJzZWN0aW9uKHRoaXMuY29uZmlnLmRhdGFDb2x1bW5zLCBjc3YuaGVhZGVyKTtcbiAgICAgICAgaWYgKGRhdGFDb2x1bW5zUHJlc2VudC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgTGVmdChgRWwgQ1NWIG5vIGNvbnRpZW5lIG5pbmd1bmEgY29sdW1uYSBkZSBkYXRvcyByZWxldmFudGUgcGFyYSBlbCBsbGVuYWRvLiBcXG4gLSBDb2x1bW5hcyBkZSBkYXRvczogJHt0aGlzLmNvbmZpZy5kYXRhQ29sdW1uc30uXFxuIC0gQ29sdW1uYXMgZGVsIGNzdjogJHtjc3YuaGVhZGVyfWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjc3Yucm93cy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgTGVmdChgRWwgY3N2IHNvbG8gY29udGllbmUgdW4gZW5jYWJlemFkbywgeSBubyBjb250aWVuZSBkYXRvcy5cXG4gLSBFbmNhYmV6YWRvOiAke2Nzdi5oZWFkZXJ9YCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZXNdIG9mIE9iamVjdC5lbnRyaWVzKHRoaXMuY29uZmlnLnZhbHVlcykpIHtcbiAgICAgICAgICAgIGlmIChjc3YuaGVhZGVyLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWxpZFZhbHVlcyA9IE9iamVjdC5rZXlzKHZhbHVlcyk7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWVDaGVjayA9IGNoZWNrVmFsdWVzKGtleSwgdmFsaWRWYWx1ZXMsIGNzdi5yb3dzKTtcbiAgICAgICAgICAgICAgICBpZiAodmFsdWVDaGVjay5pc1NvbWUoKSkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcm93c1dpdGhFcnJvcnMgPSB2YWx1ZUNoZWNrLmdldCgpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IExlZnQoYExhIGNvbHVtbmEgJHtrZXl9IGNvbnRpZW5lIHZhbG9yZXMgaW52w6FsaWRvcy4gVmFsb3JlcyB2w6FsaWRvczogJHt2YWxpZFZhbHVlc30uXFxuIEZpbGFzIGNvbiB2YWxvcmVzIGludsOhbGlkb3M6XFxuJHtwcmludEF1dG9maWxsRGF0YShyb3dzV2l0aEVycm9ycywgY3N2LmhlYWRlciwgdGhpcy5jb25maWcuY3N2U2VwYXJhdG9yKX1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBSaWdodChjc3YpO1xuICAgIH1cbn1cbiIsImV4cG9ydCBjbGFzcyBTZXR0aW5ncyB7XG4gICAgc3RhdGljIENoZWNrVmVyc2lvbihjYWxsYmFjaykge1xuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoU2V0dGluZ3MuS2V5cy5WZXJzaW9uLCBzZXR0aW5ncyA9PiB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VmVyc2lvbiA9IHRoaXMuZGVmYXVsdFNldHRpbmdzW1NldHRpbmdzLktleXMuVmVyc2lvbl07XG4gICAgICAgICAgICBjb25zdCBzZXR0aW5nc1ZlcnNpb24gPSBzZXR0aW5nc1tTZXR0aW5ncy5LZXlzLlZlcnNpb25dO1xuICAgICAgICAgICAgaWYgKHNldHRpbmdzVmVyc2lvbiAhPSBjdXJyZW50VmVyc2lvbikge1xuICAgICAgICAgICAgICAgIC8vIGlmIHZlcnNpb25zIGRvbmB0IG1hdGNoLCBjbGVhciBsb2NhbCBzdG9yYWdlIGFuZCByZXN0YXJ0IHNldHRpbmdzIHRvIHByZXZlbnQgZXJyb3JzXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBOZXcgdmVyc2lvbiAke2N1cnJlbnRWZXJzaW9ufSBmb3VuZCwgZGVsZXRpbmcgc2V0dGluZ3MgZnJvbSAke3NldHRpbmdzVmVyc2lvbn0gYCk7XG4gICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbiAgICAgICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmNsZWFyKCk7XG4gICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NldHRpbmdzLktleXMuVmVyc2lvbl06IGN1cnJlbnRWZXJzaW9uIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHN0YXRpYyBSZXN0b3JlRnJvbVN0b3JhZ2UoY2FsbGJhY2spIHtcbiAgICAgICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBJbml0aWFsaXppbmcgc2V0dGluZ3MuLi4gYCk7XG4gICAgICAgIHRoaXMuQ2hlY2tWZXJzaW9uKCgpID0+IHtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGBJbml0aWFsaXplZCB3aXRoIHNldHRpbmdzOiAke09iamVjdC5lbnRyaWVzKHYpfWApXG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoU2V0dGluZ3MuZGVmYXVsdFNldHRpbmdzLCB2YWx1ZXMgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHMgPSBuZXcgU2V0dGluZ3ModmFsdWVzW1NldHRpbmdzLktleXMuVGhlbWVdLCB2YWx1ZXNbU2V0dGluZ3MuS2V5cy5PdmVyd3JpdGVPbkF1dG9maWxsXSwgdmFsdWVzW1NldHRpbmdzLktleXMuQXV0b2ZpbGxEYXRhQ1NWXSwgdmFsdWVzW1NldHRpbmdzLktleXMuVmVyc2lvbl0pO1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKHMpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdHJ1Y3Rvcih0aGVtZSA9IFwiZGFya1wiLCBvdmVyd3JpdGVPbkF1dG9maWxsID0gdHJ1ZSwgYXV0b2ZpbGxEYXRhLCB2ZXJzaW9uKSB7XG4gICAgICAgIHRoaXMudGhlbWUgPSB0aGVtZTtcbiAgICAgICAgdGhpcy5vdmVyd3JpdGVPbkF1dG9maWxsID0gb3ZlcndyaXRlT25BdXRvZmlsbDtcbiAgICAgICAgdGhpcy5hdXRvZmlsbERhdGEgPSBhdXRvZmlsbERhdGE7XG4gICAgICAgIHRoaXMudmVyc2lvbiA9IHZlcnNpb247XG4gICAgfVxuICAgIHNhdmUoY2FsbGJhY2sgPSAoKSA9PiB7IH0pIHtcbiAgICAgICAgY29uc3QgcyA9IHtcbiAgICAgICAgICAgIFtTZXR0aW5ncy5LZXlzLlRoZW1lXTogdGhpcy50aGVtZSxcbiAgICAgICAgICAgIFtTZXR0aW5ncy5LZXlzLk92ZXJ3cml0ZU9uQXV0b2ZpbGxdOiB0aGlzLm92ZXJ3cml0ZU9uQXV0b2ZpbGwsXG4gICAgICAgICAgICBbU2V0dGluZ3MuS2V5cy5BdXRvZmlsbERhdGFDU1ZdOiB0aGlzLmF1dG9maWxsRGF0YSxcbiAgICAgICAgICAgIFtTZXR0aW5ncy5LZXlzLlZlcnNpb25dOiB0aGlzLnZlcnNpb25cbiAgICAgICAgfTtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHMpLnRoZW4oKCkgPT4gY2FsbGJhY2soKSk7XG4gICAgfVxuICAgIGdldERhdGFJRChvcGVyYXRpb24sIHN1YmplY3QpIHtcbiAgICAgICAgcmV0dXJuIGAke29wZXJhdGlvbn1fJHtzdWJqZWN0fWA7XG4gICAgfVxuICAgIGdldEF1dG9maWxsRGF0YShvcGVyYXRpb24sIHN1YmplY3QgPSBcIlwiKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgcmV0dXJuIChfYSA9IHRoaXMuYXV0b2ZpbGxEYXRhW3RoaXMuZ2V0RGF0YUlEKG9wZXJhdGlvbiwgc3ViamVjdCldKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBcIlwiO1xuICAgIH1cbiAgICBzZXRBdXRvZmlsbERhdGEob3BlcmF0aW9uLCBzdWJqZWN0LCBkYXRhKSB7XG4gICAgICAgIHRoaXMuYXV0b2ZpbGxEYXRhW3RoaXMuZ2V0RGF0YUlEKG9wZXJhdGlvbiwgc3ViamVjdCldID0gZGF0YTtcbiAgICB9XG59XG5TZXR0aW5ncy5LZXlzID0ge1xuICAgIC8vIE1pc3NpbmdTdHVkZW50czpcIm1pc3NpbmdTdHVkZW50c1wiLFxuICAgIFRoZW1lOiBcInRoZW1lXCIsXG4gICAgT3ZlcndyaXRlT25BdXRvZmlsbDogXCJvdmVyd3JpdGVPbkF1dG9maWxsXCIsXG4gICAgQXV0b2ZpbGxEYXRhQ1NWOiBcImF1dG9maWxsRGF0YUNTVlwiLFxuICAgIFZlcnNpb246IFwidmVyc2lvblwiXG4gICAgLy8gVW5tYXRjaGVkOlwidW5tYXRjaGVkXCJcbn07XG5TZXR0aW5ncy5kZWZhdWx0U2V0dGluZ3MgPSB7XG4gICAgW1NldHRpbmdzLktleXMuVGhlbWVdOiBcImRhcmtcIixcbiAgICBbU2V0dGluZ3MuS2V5cy5PdmVyd3JpdGVPbkF1dG9maWxsXTogZmFsc2UsXG4gICAgW1NldHRpbmdzLktleXMuQXV0b2ZpbGxEYXRhQ1NWXToge30sXG4gICAgW1NldHRpbmdzLktleXMuVmVyc2lvbl06IFwiMlwiXG4gICAgLy8gW1NldHRpbmdzMi5LZXlzLlVubWF0Y2hlZF06W10sXG59O1xuIiwiaW1wb3J0IHsgZnJvbUhUTUwsIFVJIH0gZnJvbSBcIi4vdXRpbHMvZG9tX3V0aWxzXCI7XG5pbXBvcnQgeyBtYXBWYWx1ZXMgfSBmcm9tIFwiLi91dGlscy91dGlsc1wiO1xuZnVuY3Rpb24gYWRkQ1NTKGhyZWYpIHtcbiAgICBjb25zdCB0cnVlSHJlZiA9IGNocm9tZS5ydW50aW1lLmdldFVSTChocmVmKTtcbiAgICB2YXIgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgncmVsJywgJ3N0eWxlc2hlZXQnKTtcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgnaHJlZicsIHRydWVIcmVmKTtcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgndHlwZScsIFwidGV4dC9jc3NcIik7XG4gICAgLy8gbGluay5zZXRBdHRyaWJ1dGUoJ2Rpc2FibGVkJywgXCJkaXNhYmxlZFwiKTtcbiAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO1xuICAgIHJldHVybiBsaW5rO1xufVxuY2xhc3MgVGhlbWVzVUkgZXh0ZW5kcyBVSSB7XG4gICAgY29uc3RydWN0b3IodGhlbWVzLCBzZXR0aW5ncykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnRoZW1lcyA9IHRoZW1lcztcbiAgICAgICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICAgICAgICB0aGlzLnJvb3QgPSBmcm9tSFRNTChgPHNlbGVjdCB0eXBlPVwidGV4dFwiIG5hbWU9XCJ0aGVtZVwiIGlkPVwidGhlbWVcIj5cbiAgICA8b3B0aW9uIHZhbHVlPVwibGlnaHRcIj5DbGFybyDwn4yVPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cImRhcmtcIj5Pc2N1cm8g8J+MkTwvb3B0aW9uPlxuICAgIDwvc2VsZWN0PmApO1xuICAgICAgICB0aGlzLnJvb3QudmFsdWUgPSBzZXR0aW5ncy50aGVtZTtcbiAgICAgICAgdGhpcy5yb290LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIChldmVudCkgPT4gdGhpcy51cGRhdGVUaGVtZSgpKTtcbiAgICAgICAgdGhpcy51cGRhdGVUaGVtZSgpO1xuICAgIH1cbiAgICB1cGRhdGVUaGVtZSgpIHtcbiAgICAgICAgY29uc3QgbmV3VGhlbWUgPSB0aGlzLnJvb3QudmFsdWU7XG4gICAgICAgIGNvbnNvbGUubG9nKGBHVUFSQU5JLUNIUk9NRTogQ2hhbmdpbmcgdGhlbWUgdG8gXCIke25ld1RoZW1lfVwiYCk7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MudGhlbWUgPSBuZXdUaGVtZTtcbiAgICAgICAgdGhpcy5zZXR0aW5ncy5zYXZlKCk7XG4gICAgICAgIC8vZGlzYWJsZSBhbGwgdGhlbWVzXG4gICAgICAgIHRoaXMudGhlbWVzLmZvckVhY2goKHYsIGspID0+IHYuZGlzYWJsZWQgPSB0cnVlKTtcbiAgICAgICAgLy9lbmFibGUganVzdCB0aGlzIG9uZVxuICAgICAgICBpZiAodGhpcy50aGVtZXMuaGFzKG5ld1RoZW1lKSkge1xuICAgICAgICAgICAgdGhpcy50aGVtZXMuZ2V0KG5ld1RoZW1lKS5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGluaXRpYWxpemVUaGVtZUNob29zZXIoc2V0dGluZ3MpIHtcbiAgICBjb25zb2xlLmxvZyhgR1VBUkFOSS1DSFJPTUU6IGluaXRpYWxpemluZyB0aGVtZSBjaG9vc2VyYCk7XG4gICAgY29uc3QgdGhlbWVVUkxzID0gbmV3IE1hcChPYmplY3QuZW50cmllcyh7IFwiZGFya1wiOiBcInRoZW1lcy9kYXJrLmNzc1wiLFxuICAgICAgICBcImxpZ2h0XCI6IFwidGhlbWVzL2xpZ2h0LmNzc1wiXG4gICAgfSkpO1xuICAgIGNvbnN0IHRoZW1lcyA9IG1hcFZhbHVlcyh0aGVtZVVSTHMsIGFkZENTUyk7XG4gICAgLy8gd2FpdCBhIGJpdCBmb3IgY3NzIGZpbGVzIHRvIGxvYWQgYmVmb3JlIGNyZWF0aW5nIFRoZW1lc1VJXG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBjb25zdCB0aGVtZXNVSSA9IG5ldyBUaGVtZXNVSSh0aGVtZXMsIHNldHRpbmdzKTtcbiAgICAgICAgbGV0IG5vdGlmaWNhdGlvbnMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLm5vdGlmaWNhY2lvbmVzXCIpO1xuICAgICAgICBpZiAobm90aWZpY2F0aW9ucykge1xuICAgICAgICAgICAgbm90aWZpY2F0aW9ucy5hcHBlbmRDaGlsZCh0aGVtZXNVSS5yb290KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBHVUFSQU5JLUNIUk9NRTogRGlkIG5vdCBmaW5kIGVsZW1lbnQgXCIubm90aWZpY2FjaW9uZXNcIiB0byBhcHBlbmQgdGhlIHRoZW1lIGNob29zZXJgKTtcbiAgICAgICAgfVxuICAgIH0sIDEwMCk7XG59XG4iLCJleHBvcnQgY2xhc3MgVUkge1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlYWR5KGZuKSB7XG4gICAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgIT09ICdsb2FkaW5nJykge1xuICAgICAgICBmbigpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBmbik7XG59XG5leHBvcnQgZnVuY3Rpb24gb2JzZXJ2ZShlbGVtZW50LCBmLCBjb25maWcgPSB7IHN1YnRyZWU6IHRydWUsIGNoaWxkTGlzdDogdHJ1ZSwgYXR0cmlidXRlczogdHJ1ZSB9LCBkaXNhYmxlQWZ0ZXJGaXJzdCA9IHRydWUsIHBhcmFtcyA9IFtdKSB7XG4gICAgY29uc3QgbXV0YXRpb25PYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVBZnRlckZpcnN0KSB7XG4gICAgICAgICAgICBtdXRhdGlvbk9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgfVxuICAgICAgICBmKG11dGF0aW9uT2JzZXJ2ZXIsIHBhcmFtcyk7XG4gICAgfSk7XG4gICAgbXV0YXRpb25PYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQsIGNvbmZpZyk7XG4gICAgcmV0dXJuIG11dGF0aW9uT2JzZXJ2ZXI7XG59XG5leHBvcnQgZnVuY3Rpb24gdG9nZ2xlRWxlbWVudChlbCwgZGlzcGxheSA9IFwiYmxvY2tcIikge1xuICAgIGlmIChlbC5zdHlsZS5kaXNwbGF5ID09PSBcIm5vbmVcIikge1xuICAgICAgICBlbC5zdHlsZS5kaXNwbGF5ID0gZGlzcGxheTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gZnJvbUhUTUwoaHRtbCwgdHJpbSA9IHRydWUpIHtcbiAgICAvLyBQcm9jZXNzIHRoZSBIVE1MIHN0cmluZy5cbiAgICBodG1sID0gdHJpbSA/IGh0bWwgOiBodG1sLnRyaW0oKTtcbiAgICBpZiAoIWh0bWwpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIC8vIFRoZW4gc2V0IHVwIGEgbmV3IHRlbXBsYXRlIGVsZW1lbnQuXG4gICAgY29uc3QgdGVtcGxhdGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZW1wbGF0ZScpO1xuICAgIHRlbXBsYXRlLmlubmVySFRNTCA9IGh0bWw7XG4gICAgY29uc3QgcmVzdWx0ID0gdGVtcGxhdGUuY29udGVudC5jaGlsZHJlbjtcbiAgICAvLyBUaGVuIHJldHVybiBlaXRoZXIgYW4gSFRNTEVsZW1lbnQgb3IgSFRNTENvbGxlY3Rpb24sXG4gICAgLy8gYmFzZWQgb24gd2hldGhlciB0aGUgaW5wdXQgSFRNTCBoYWQgb25lIG9yIG1vcmUgcm9vdHMuXG4gICAgaWYgKHJlc3VsdC5sZW5ndGggIT09IDEpXG4gICAgICAgIHRocm93IEVycm9yKGBmcm9tSFRNTCBtdXN0IGNyZWF0ZSBvbmUgYW5kIG9ubHkgb25lIGVsZW1lbnQgKHBvc3NpYmx5IHdpdGggbWFueSBjaGlsZHJlbiwgZm91bmQgJHtyZXN1bHR9KWApO1xuICAgIHJldHVybiByZXN1bHRbMF07XG59XG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kQ2hpbGRyZW4ocm9vdCwgY2hpbGRyZW4pIHtcbiAgICBjaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IHJvb3QuYXBwZW5kQ2hpbGQoY2hpbGQpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YWl0Rm9yRWxlbWVudChzZWxlY3RvciwgY2FsbGJhY2ssIGNoZWNrRnJlcXVlbmN5SW5NcyA9IDEwLCB0aW1lb3V0SW5NcyA9IDE1MDAwLCBmYWlsdXJlX2NhbGxiYWNrID0gdW5kZWZpbmVkKSB7XG4gICAgdmFyIHN0YXJ0VGltZUluTXMgPSBEYXRlLm5vdygpO1xuICAgIChmdW5jdGlvbiBsb29wU2VhcmNoKCkge1xuICAgICAgICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgICAgICBjYWxsYmFjayhlbGVtZW50KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gc3RhcnRUaW1lSW5NcztcbiAgICAgICAgICAgICAgICBpZiAodGltZW91dEluTXMgJiYgZWxhcHNlZCA+IHRpbWVvdXRJbk1zKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmYWlsdXJlX2NhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlX2NhbGxiYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGxvb3BTZWFyY2goKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCBjaGVja0ZyZXF1ZW5jeUluTXMpO1xuICAgICAgICB9XG4gICAgfSkoKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwcm9wYWdhdGVPbkNoYW5nZShlbGVtZW50KSB7XG4gICAgdmFyIGV2ZW50ID0gbmV3IEV2ZW50KCdjaGFuZ2UnLCB7IGJ1YmJsZXM6IHRydWUgfSk7XG4gICAgZWxlbWVudC5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjbGVhblByb3BhZ2F0ZShlKSB7XG4gICAgZS52YWx1ZSA9IFwiXCI7XG4gICAgcHJvcGFnYXRlT25DaGFuZ2UoZSk7XG59XG4iLCJleHBvcnQgY29uc3QgemlwID0gKGEsIGIpID0+IGEubWFwKChrLCBpKSA9PiBbaywgYltpXV0pO1xuZXhwb3J0IGZ1bmN0aW9uIGludGVyc2VjdGlvbihhLCBiKSB7IHJldHVybiBhLmZpbHRlcih2YWx1ZSA9PiBiLmluY2x1ZGVzKHZhbHVlKSk7IH1cbmV4cG9ydCBmdW5jdGlvbiBkaWN0RnJvbUxpc3RzKGtleXMsIHZhbHMpIHtcbiAgICBjb25zdCBkaWN0ID0gbmV3IE1hcCgpO1xuICAgIHppcChrZXlzLCB2YWxzKS5mb3JFYWNoKGt2ID0+IHtcbiAgICAgICAgY29uc3QgW2ssIHZdID0ga3Y7XG4gICAgICAgIGRpY3Quc2V0KGssIHYpO1xuICAgIH0pO1xuICAgIHJldHVybiBkaWN0O1xufVxuZXhwb3J0IGNsYXNzIE9wdGlvbmFsIHtcbn1cbmV4cG9ydCBjbGFzcyBTb21lIGV4dGVuZHMgT3B0aW9uYWwge1xuICAgIGNvbnN0cnVjdG9yKHgpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy54ID0geDtcbiAgICB9XG4gICAgZ2V0KCkgeyByZXR1cm4gdGhpcy54OyB9XG4gICAgbWFwKGYpIHsgcmV0dXJuIG5ldyBTb21lKGYodGhpcy54KSk7IH1cbiAgICBmbGF0TWFwKGYpIHsgcmV0dXJuIGYodGhpcy54KTsgfVxuICAgIGRvU29tZShmKSB7IGYodGhpcy54KTsgfVxuICAgIGRvTm9uZShmKSB7IH1cbiAgICBpc05vbmUoKSB7IHJldHVybiBmYWxzZTsgfVxuICAgIGlzU29tZSgpIHsgcmV0dXJuIHRydWU7IH1cbn1cbmV4cG9ydCBjbGFzcyBOb25lIGV4dGVuZHMgT3B0aW9uYWwge1xuICAgIG1hcChmKSB7IHJldHVybiBmKHRoaXMpOyB9XG4gICAgZmxhdE1hcChmKSB7IHRoaXM7IH1cbiAgICBkb1NvbWUoZikgeyB9XG4gICAgZG9Ob25lKGYpIHsgZigpOyB9XG4gICAgaXNOb25lKCkgeyByZXR1cm4gdHJ1ZTsgfVxuICAgIGlzU29tZSgpIHsgcmV0dXJuIGZhbHNlOyB9XG59XG5leHBvcnQgY2xhc3MgTGVmdCB7XG4gICAgY29uc3RydWN0b3IodmFsKSB7XG4gICAgICAgIHRoaXMuX3ZhbCA9IHZhbDtcbiAgICB9XG4gICAgaXNMZWZ0KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaXNSaWdodCgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBkbyhmTCwgZlIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZG9MZWZ0KGZMKTtcbiAgICB9XG4gICAgZG9MZWZ0KGYpIHtcbiAgICAgICAgZih0aGlzLl92YWwpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZG9SaWdodChmKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBjaGFpbkFueShmTCwgZlIpIHtcbiAgICAgICAgcmV0dXJuIGZMKHRoaXMuX3ZhbCk7XG4gICAgfVxuICAgIG1hcCgpIHtcbiAgICAgICAgLy8gTGVmdCBpcyB0aGUgc2FkIHBhdGhcbiAgICAgICAgLy8gc28gd2UgZG8gbm90aGluZ1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgam9pbigpIHtcbiAgICAgICAgLy8gT24gdGhlIHNhZCBwYXRoLCB3ZSBkb24ndFxuICAgICAgICAvLyBkbyBhbnl0aGluZyB3aXRoIGpvaW5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNoYWluKCkge1xuICAgICAgICAvLyBCb3Jpbmcgc2FkIHBhdGgsXG4gICAgICAgIC8vIGRvIG5vdGhpbmcuXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWw7XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICBjb25zdCBzdHIgPSB0aGlzLl92YWwudG9TdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIGBMZWZ0KCR7c3RyfSlgO1xuICAgIH1cbn1cbi8qKlxuKlJpZ2h0IHJlcHJlc2VudHMgdGhlIGhhcHB5IHBhdGhcbiovXG5leHBvcnQgY2xhc3MgUmlnaHQge1xuICAgIGNvbnN0cnVjdG9yKHZhbCkge1xuICAgICAgICB0aGlzLl92YWwgPSB2YWw7XG4gICAgfVxuICAgIGlzTGVmdCgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpc1JpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgZG8oZkwsIGZSKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmRvUmlnaHQoZlIpO1xuICAgIH1cbiAgICBkb0xlZnQoZikge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZG9SaWdodChmKSB7XG4gICAgICAgIGYodGhpcy5fdmFsKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNoYWluQW55KGZMLCBmUikge1xuICAgICAgICByZXR1cm4gdGhpcy5jaGFpbihmUik7XG4gICAgfVxuICAgIG1hcChmbikge1xuICAgICAgICByZXR1cm4gbmV3IFJpZ2h0KGZuKHRoaXMuX3ZhbCkpO1xuICAgIH1cbiAgICBqb2luKCkge1xuICAgICAgICBpZiAoKHRoaXMuX3ZhbCBpbnN0YW5jZW9mIExlZnQpXG4gICAgICAgICAgICB8fCAodGhpcy5fdmFsIGluc3RhbmNlb2YgUmlnaHQpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fdmFsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBjaGFpbihmbikge1xuICAgICAgICByZXR1cm4gZm4odGhpcy5fdmFsKTtcbiAgICB9XG4gICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsO1xuICAgIH1cbiAgICB0b1N0cmluZygpIHtcbiAgICAgICAgY29uc3Qgc3RyID0gdGhpcy5fdmFsLnRvU3RyaW5nKCk7XG4gICAgICAgIHJldHVybiBgUmlnaHQoJHtzdHJ9KWA7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIG1hcFZhbHVlcyhtYXAsIGZuKSB7XG4gICAgcmV0dXJuIG5ldyBNYXAoQXJyYXkuZnJvbShtYXAsIChba2V5LCB2YWx1ZV0pID0+IFtrZXksIGZuKHZhbHVlKV0pKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBtYXBLZXlzKG1hcCwgZm4pIHtcbiAgICByZXR1cm4gbmV3IE1hcChBcnJheS5mcm9tKG1hcCwgKFtrZXksIHZhbHVlXSkgPT4gW2ZuKGtleSksIHZhbHVlXSkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1hcE1hcChtYXAsIGZuKSB7XG4gICAgcmV0dXJuIG5ldyBNYXAoQXJyYXkuZnJvbShtYXAsIChba2V5LCB2YWx1ZV0pID0+IGZuKGtleSwgdmFsdWUpKSk7XG59XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsImltcG9ydCB7IFNldHRpbmdzIH0gZnJvbSBcIi4vc2V0dGluZ3NcIjtcbmltcG9ydCB7IGluaXRpYWxpemVUaGVtZUNob29zZXIgfSBmcm9tIFwiLi90aGVtZXNcIjtcbmltcG9ydCB7IHJlYWR5LCB3YWl0Rm9yRWxlbWVudCB9IGZyb20gXCIuL3V0aWxzL2RvbV91dGlsc1wiO1xuaW1wb3J0IHsgd2hlbl9mb3JtX3Jlbmdsb25lc19yZWFkeSB9IGZyb20gXCIuL2Zvcm1fcmVuZ2xvbmVzXCI7XG5pbXBvcnQgeyBhZGRBdXRvZmlsbFVJIH0gZnJvbSBcIi4vYXV0b2ZpbGxfdWkvYXV0b2ZpbGxfdWlcIjtcbmltcG9ydCB7IEF1dG9maWxsQ3Vyc2FkYSwgQXV0b2ZpbGxGaW5hbCB9IGZyb20gXCIuL2F1dG9maWxsL2F1dG9maWxsXCI7XG5pbXBvcnQgeyBBdXRvZmlsbFBhcnNlciB9IGZyb20gXCIuL2lucHV0L3BhcnNlclwiO1xuaW1wb3J0IHsgQ1NWQ3Vyc2FkYUNvbmZpZyB9IGZyb20gXCIuL2lucHV0L0NTVkN1cnNhZGFDb25maWdcIjtcbmltcG9ydCB7IENTVkZpbmFsQ29uZmlnIH0gZnJvbSBcIi4vaW5wdXQvQ1NWRmluYWxDb25maWdcIjtcbmltcG9ydCB7IENvbHVtblN0YXR1c1VJIH0gZnJvbSBcIi4vYXV0b2ZpbGxfdWkvYXV0b2ZpbGxfc3RhdHVzX3VpXCI7XG52YXIgUGFnZVR5cGU7XG4oZnVuY3Rpb24gKFBhZ2VUeXBlKSB7XG4gICAgUGFnZVR5cGVbUGFnZVR5cGVbXCJDdXJzYWRhXCJdID0gMF0gPSBcIkN1cnNhZGFcIjtcbiAgICBQYWdlVHlwZVtQYWdlVHlwZVtcIkZpbmFsXCJdID0gMV0gPSBcIkZpbmFsXCI7XG4gICAgUGFnZVR5cGVbUGFnZVR5cGVbXCJPdGhlclwiXSA9IDJdID0gXCJPdGhlclwiO1xufSkoUGFnZVR5cGUgfHwgKFBhZ2VUeXBlID0ge30pKTtcbmZ1bmN0aW9uIGRldGVjdFBhZ2VUeXBlQnlVUkwoKSB7XG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ob3N0LmluY2x1ZGVzKFwibG9jYWxob3N0XCIpKSB7XG4gICAgICAgIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUuZW5kc1dpdGgoXCJjdXJzYWRhLmh0bWxcIikpIHtcbiAgICAgICAgICAgIHJldHVybiBQYWdlVHlwZS5DdXJzYWRhO1xuICAgICAgICB9XG4gICAgICAgIGlmICh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUuZW5kc1dpdGgoXCJmaW5hbC5odG1sXCIpKSB7XG4gICAgICAgICAgICByZXR1cm4gUGFnZVR5cGUuRmluYWw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFBhZ2VUeXBlLk90aGVyO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSB3aW5kb3cubG9jYXRpb24udG9TdHJpbmcoKTtcbiAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLnN0YXJ0c1dpdGgoXCIvY3Vyc2FkYS9lZGljaW9uXCIpKSB7XG4gICAgICAgIHJldHVybiBQYWdlVHlwZS5DdXJzYWRhO1xuICAgIH1cbiAgICBpZiAod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLnN0YXJ0c1dpdGgoXCIvbm90YXNfbWVzYV9leGFtZW4vZWRpY2lvblwiKSkge1xuICAgICAgICByZXR1cm4gUGFnZVR5cGUuRmluYWw7XG4gICAgfVxuICAgIHJldHVybiBQYWdlVHlwZS5PdGhlcjtcbn1cbmZ1bmN0aW9uIGRldGVjdFBhZ2VUeXBlQnlFbGVtZW50cygpIHtcbiAgICBjb25zdCBjYWJlY2VyYUVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhYmVjZXJhXCIpO1xuICAgIGlmICghY2FiZWNlcmFFbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBQYWdlVHlwZS5PdGhlcjtcbiAgICB9XG4gICAgY29uc3QgdGl0bGVFbGVtZW50Q29udGFpbmVyID0gY2FiZWNlcmFFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoXCJoMlwiKTtcbiAgICBpZiAoIXRpdGxlRWxlbWVudENvbnRhaW5lcikge1xuICAgICAgICByZXR1cm4gUGFnZVR5cGUuT3RoZXI7XG4gICAgfVxuICAgIGNvbnN0IHRpdGxlRWxlbWVudCA9IHRpdGxlRWxlbWVudENvbnRhaW5lci5jaGlsZHJlblswXTtcbiAgICBzd2l0Y2ggKHRpdGxlRWxlbWVudC5pbm5lclRleHQpIHtcbiAgICAgICAgY2FzZSBcIkNhcmdhIGRlIG5vdGFzIGRlIGN1cnNhZGFcIjogcmV0dXJuIFBhZ2VUeXBlLkN1cnNhZGE7XG4gICAgICAgIGNhc2UgXCJDYXJnYSBkZSBub3RhcyBhIG1lc2EgZGUgZXhhbWVuXCI6IHJldHVybiBQYWdlVHlwZS5GaW5hbDtcbiAgICAgICAgZGVmYXVsdDogcmV0dXJuIFBhZ2VUeXBlLk90aGVyO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGdldFN1YmplY3ROYW1lKCkge1xuICAgIGNvbnN0IGRpdkNhYmVjZXJhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJqcy1jb2xhcHNhci1kZXRhbGxlcy16b25hXCIpO1xuICAgIGNvbnN0IG5hbWVTcGFuID0gZGl2Q2FiZWNlcmEuY2hpbGRyZW5bMF0uY2hpbGRyZW5bMF07XG4gICAgcmV0dXJuIG5hbWVTcGFuLmlubmVyVGV4dDtcbn1cbmZ1bmN0aW9uIGFkZENvbHVtbkNvdW50ZXJzKHJvd3MsIGF1dG9maWxsLCBmaWVsZFRvSW5kZXgpIHtcbiAgICBjb25zdCBoZWFkZXJFbGVtZW50cyA9IEFycmF5LmZyb20oZG9jdW1lbnRcbiAgICAgICAgLmdldEVsZW1lbnRCeUlkKFwicmVuZ2xvbmVzXCIpXG4gICAgICAgIC5xdWVyeVNlbGVjdG9yKFwidGhlYWRcIilcbiAgICAgICAgLnF1ZXJ5U2VsZWN0b3JBbGwoXCJ0aFwiKSk7XG4gICAgY29uc3QgY29sdW1uc1N0YXR1c1VJcyA9IE9iamVjdC5lbnRyaWVzKGZpZWxkVG9JbmRleCkubWFwKChlLCBpLCBhKSA9PiB7XG4gICAgICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IGU7XG4gICAgICAgIGNvbnN0IGhlYWRlciA9IGhlYWRlckVsZW1lbnRzW3ZhbHVlXTtcbiAgICAgICAgcmV0dXJuIG5ldyBDb2x1bW5TdGF0dXNVSShyb3dzLCBhdXRvZmlsbCwga2V5LCBoZWFkZXIpO1xuICAgIH0pO1xuICAgIHJldHVybiBjb2x1bW5zU3RhdHVzVUlzO1xufVxuZnVuY3Rpb24gYWRkUGFnZVNwZWNpZmljVUkoc2V0dGluZ3MpIHtcbiAgICBzd2l0Y2ggKGRldGVjdFBhZ2VUeXBlQnlVUkwoKSkge1xuICAgICAgICBjYXNlIFBhZ2VUeXBlLkN1cnNhZGE6IHtcbiAgICAgICAgICAgIHdoZW5fZm9ybV9yZW5nbG9uZXNfcmVhZHkoKGZvcm1fcmVuZ2xvbmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFibGUgPSBmb3JtX3Jlbmdsb25lcy5jaGlsZHJlblsxXTtcbiAgICAgICAgICAgICAgICBjb25zdCB0YWJsZV9ib2R5ID0gdGFibGUuY2hpbGRyZW5bMV07XG4gICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IEFycmF5LmZyb20odGFibGVfYm9keS5yb3dzKTtcbiAgICAgICAgICAgICAgICBjb25zdCBzdWJqZWN0TmFtZSA9IGdldFN1YmplY3ROYW1lKCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYEdVQVJBTkktQ0hST01FOiBTZSBkZXRlY3TDsyBww6FnaW5hIGRlIGNhcmdhIGRlIG5vdGFzIGRlIENVUlNBREEgZGUgbGEgbWF0ZXJpYSAke3N1YmplY3ROYW1lfWApO1xuICAgICAgICAgICAgICAgIGNvbnN0IGF1dG9maWxsID0gbmV3IEF1dG9maWxsQ3Vyc2FkYShuZXcgQXV0b2ZpbGxQYXJzZXIobmV3IENTVkN1cnNhZGFDb25maWcoKSksIHN1YmplY3ROYW1lKTtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFRvSW5kZXggPSB7IFwiZmVjaGFcIjogMywgXCJub3RhXCI6IDQsIFwicmVzdWx0YWRvXCI6IDUsIFwiY29uZGljaW9uXCI6IDYgfTtcbiAgICAgICAgICAgICAgICBhZGRDb2x1bW5Db3VudGVycyhyb3dzLCBhdXRvZmlsbCwgZmllbGRUb0luZGV4KTtcbiAgICAgICAgICAgICAgICBhZGRBdXRvZmlsbFVJKHJvd3MsIHNldHRpbmdzLCBhdXRvZmlsbCk7XG4gICAgICAgICAgICB9LCA0MDAwLCAxMCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIFBhZ2VUeXBlLkZpbmFsOiB7XG4gICAgICAgICAgICB3aGVuX2Zvcm1fcmVuZ2xvbmVzX3JlYWR5KChmb3JtX3Jlbmdsb25lcykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhYmxlID0gZm9ybV9yZW5nbG9uZXMuY2hpbGRyZW5bMV07XG4gICAgICAgICAgICAgICAgY29uc3QgdGFibGVfYm9keSA9IHRhYmxlLmNoaWxkcmVuWzFdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBBcnJheS5mcm9tKHRhYmxlX2JvZHkucm93cyk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3ViamVjdE5hbWUgPSBnZXRTdWJqZWN0TmFtZSgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBHVUFSQU5JLUNIUk9NRTogU2UgZGV0ZWN0w7MgcMOhZ2luYSBkZSBjYXJnYSBkZSBub3RhcyBkZSBGSU5BTCBkZSBsYSBtYXRlcmlhICR7c3ViamVjdE5hbWV9YCk7XG4gICAgICAgICAgICAgICAgY29uc3QgYXV0b2ZpbGwgPSBuZXcgQXV0b2ZpbGxGaW5hbChuZXcgQXV0b2ZpbGxQYXJzZXIobmV3IENTVkZpbmFsQ29uZmlnKCkpLCBzdWJqZWN0TmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRUb0luZGV4ID0geyBcImZlY2hhXCI6IDMsIFwibm90YVwiOiA0LCBcInJlc3VsdGFkb1wiOiA1IH07XG4gICAgICAgICAgICAgICAgYWRkQ29sdW1uQ291bnRlcnMocm93cywgYXV0b2ZpbGwsIGZpZWxkVG9JbmRleCk7XG4gICAgICAgICAgICAgICAgYWRkQXV0b2ZpbGxVSShyb3dzLCBzZXR0aW5ncywgYXV0b2ZpbGwpO1xuICAgICAgICAgICAgfSwgNDAwMCwgMTApO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgZGVmYXVsdDogY29uc29sZS5sb2coXCJHVUFSQU5JLUNIUk9NRTogTm8gc2UgZGV0ZWN0w7MgdW4gdGlwbyBkZSBww6FnaW5hIGVzcGVjaWFsLlwiKTtcbiAgICB9XG59XG5TZXR0aW5ncy5SZXN0b3JlRnJvbVN0b3JhZ2UocyA9PiB7XG4gICAgcmVhZHkoKCkgPT4gaW5pdGlhbGl6ZVRoZW1lQ2hvb3NlcihzKSk7XG4gICAgd2FpdEZvckVsZW1lbnQoXCIjY2FiZWNlcmFcIiwgKCkgPT4ge1xuICAgICAgICBhZGRQYWdlU3BlY2lmaWNVSShzKTtcbiAgICB9KTtcbn0pO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9