"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCSV = exports.validateCSV = void 0;
var utils_1 = require("./utils");
function validateCSV(input, separator) {
    if (separator === void 0) { separator = ";"; }
    return input.trim().length > 0;
}
exports.validateCSV = validateCSV;
function parseCSV(input, separator, normalize_header) {
    if (separator === void 0) { separator = ";"; }
    if (normalize_header === void 0) { normalize_header = false; }
    input = input.trim();
    if (input === "") {
        return [[], []];
    }
    var lines = input.split(/\r\n|\n/).map(function (r) { return r.trim(); });
    var nonemptyLines = lines.filter(function (r) { return r.length > 0; });
    var splitLines = nonemptyLines.map(function (l) { return l.split(separator); });
    var basicHeader = splitLines.shift();
    var header = normalize_header ? basicHeader.map(function (h) { return h.trim().toLowerCase(); }) : basicHeader;
    var rows = [];
    splitLines.forEach(function (values, i) {
        if (header.size != values.size) {
            throw new CSVParseError("Number of values in row ".concat(i, " does not match number of values in header (row: ").concat(values, ", header: ").concat(header));
        }
        var row = (0, utils_1.dictFromLists)(header, values);
        rows.push(row);
    });
    return [rows, header];
}
exports.parseCSV = parseCSV;
// parseCSV("dni;h1\n23;v1\n  \n  \n")
//# sourceMappingURL=csv_utils.js.map