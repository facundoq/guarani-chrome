"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.autofill = void 0;
var utils_1 = require("./utils");
var csv_parser_1 = require("./csv_parser");
var Student = /** @class */ (function () {
    function Student(dni, nombre, fecha, nota) {
    }
    return Student;
}());
function dniMatcher(studentData, allData) {
    var matches = allData.filter(function (s) { return s.get("dni") == studentData.dni; });
    if (matches.length === 1) {
        return utils_1.Either.Right(matches[0]);
    }
    else {
        return utils_1.Either.Left(matches);
    }
}
var elementSelectors = {
    dni: ".identificacion",
    nombre: ".nombre",
    fecha: ".fecha",
    nota: ".nota_cursada",
    resultado: ".resultado",
    condicion: ".condicion",
};
function getStudentData(row) {
    var dni_element_value = row.querySelector(elementSelectors["dni"]).innerText;
    var dni = dni_element_value.split(" ")[1];
    var nombre = row.querySelector(elementSelectors["nombre"]).innerText;
    var fecha = row.querySelector(elementSelectors["fecha"]).value;
    var nota = row.querySelector(elementSelectors["nota"]).value;
    var resultado = row.querySelector(elementSelectors["resultado"]).value;
    var condicion = row.querySelector(elementSelectors["condicion"]).value;
    if (nota === "-") {
        nota = "";
    }
    var studentData = {
        dni: dni,
        nombre: nombre,
        fecha: fecha,
        nota: nota,
        resultado: resultado,
        condicion: condicion,
    };
    return studentData;
}
function isStudentFormEmpty(studentFormData) {
    var s = studentFormData;
    return (s.fecha === "") && (s.nota === "") && (s.condicion === "") && (s.resultado === "");
}
function convertValues(value, column) {
    // TODO test alternative
    if (column in csv_parser_1.csvConfig.values) {
        return csv_parser_1.csvConfig.values[column][value];
    }
    else {
        return value;
    }
}
function autofillStudent(row, studentData) {
    csv_parser_1.csvConfig.dataColumns.forEach(function (column) {
        if (studentData.has(column)) {
            var autofillValue = convertValues(studentData.get(column), column);
            var element = row.querySelector(elementSelectors[column]);
            element.value = autofillValue;
            var event = new Event('change');
            element.dispatchEvent(event);
        }
    });
}
function addToStudentTitle(row, message) {
    var nombre = row.querySelector(elementSelectors["nombre"]);
    var id = row.querySelector(elementSelectors["dni"]);
    var emoji = row.querySelector(".result-emoji:last-child");
    nombre.title = "".concat(nombre.title, "\n Autofill: ").concat(message);
    id.title = "".concat(id.title, "\n Autofill: ").concat(message);
    emoji.title = "".concat(emoji.title, " \n Autofill: ").concat(message);
}
function setStudentClass(row, klass) {
    var _a;
    (_a = row.classList).remove.apply(_a, row.classList);
    row.classList.add(klass);
}
function markFilledStudent(row) {
    setStudentClass(row, "autofilledStudent");
    addEmojiStudent(row, "✅");
    addToStudentTitle(row, "ha sido completado automaticamente");
}
function markOverwrittenStudent(row) {
    setStudentClass(row, "modifiedStudent");
    addEmojiStudent(row, "✏️");
    addToStudentTitle(row, "ha sido editado automáticamente");
}
function markUnmatchedStudent(row, matches) {
    setStudentClass(row, "unmatchedStudent");
    addEmojiStudent(row, "❌");
    addToStudentTitle(row, "no se pudo encontrar en el csv");
}
function addEmojiStudent(row, emoji) {
    var alumnoDiv = row.querySelector(".datos-alumno");
    var emojiElement = fromHTML("<span class=\"result-emoji\"> ".concat(emoji, "<span>"));
    alumnoDiv.appendChild(emojiElement);
    // alumnoDiv.innerText += emoji
}
function markAlreadyFilledStudent(row) {
    setStudentClass(row, "alreadyFilledStudent");
    addEmojiStudent(row, "⚠️");
    addToStudentTitle(row, "No se modificó porque ya tenía valores cargados");
    // let resultImage = document.createElement('img')
    // alumnoDiv.appendChild()
}
//   root.addMissingStudent = (student) => {
//   const missingStudents = getSettings("missingStudents")
//   if (missingStudents) {
//       missingStudents.push(student)
//       setSettings("missingStudents", missingStudents)
//   } else {
//       textarea.value = "No hay datos guardados."
//       deleteButton.disabled = true;
//   }
// }
function autofill(rows, autofillData, overwrite, matcher) {
    if (matcher === void 0) { matcher = dniMatcher; }
    var unmatched = [];
    var _loop_1 = function (row) {
        var studentFormData = getStudentData(row);
        var studentFormEmpty = isStudentFormEmpty(studentFormData);
        if (!overwrite && !studentFormEmpty) {
            markAlreadyFilledStudent(row);
            return "continue";
        }
        var studentDataResult = matcher(studentFormData, autofillData);
        studentDataResult.doRight(function (studentData) {
            autofillStudent(row, studentData);
            if (studentFormEmpty) {
                markFilledStudent(row);
            }
            else {
                markOverwrittenStudent(row);
            }
        });
        studentDataResult.doLeft(function (matches) {
            if (studentFormEmpty) {
                markUnmatchedStudent(row, matches);
                unmatched.push(studentFormData.dni);
            }
            else {
                markAlreadyFilledStudent(row);
            }
        });
    };
    for (var _i = 0, rows_1 = rows; _i < rows_1.length; _i++) {
        var row = rows_1[_i];
        _loop_1(row);
    }
    return unmatched;
}
exports.autofill = autofill;
//# sourceMappingURL=autofill.js.map