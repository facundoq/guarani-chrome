"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.csv2autofillData = exports.csvConfig = void 0;
var utils_1 = require("./utils");
var csv_utils_1 = require("./csv_utils");
exports.csvConfig = {
    dataColumns: ["fecha", "condicion", "nota", "resultado"],
    keyColumns: ["dni", "nombre"],
    csvSeparator: ";",
    values: {
        nota: {
            "U": "U",
            "D": "D",
            "A": "A",
            "-": "",
        },
        resultado: {
            "Ausente": "U",
            "Reprobado": "R",
            "Aprobado": "A",
            "-": "",
        },
        condicion: {
            "Abandono": 2,
            "Aprobado": 175,
            "Desaprobado": 174,
            "Insuficiente": 3,
            "Libre": 1,
            "No Promociono": 107,
            "Promociono": 5,
            "Regular": 4,
            "-": "",
        }
    }
};
function checkValues(column, values, autofillData) {
    var rowsWithWrongValues = autofillData.filter(function (s) { return !values.includes(s.get(column)); });
    return (rowsWithWrongValues.length === 0) ? new utils_1.None() : new utils_1.Some(rowsWithWrongValues);
}
function printRow(row) {
    return Array.from(row.values()).join(exports.csvConfig.csvSeparator);
}
function printAutofillData(data, header) {
    var headerRow = header.join(exports.csvConfig.csvSeparator);
    var rows = data.map(printRow).join("\n");
    return "".concat(headerRow, "\n").concat(rows, "\n");
}
function csv2autofillData(data) {
    var _a = (0, csv_utils_1.parseCSV)(data, exports.csvConfig.csvSeparator, true), autofillData = _a[0], header = _a[1];
    var keyColumnsPresent = (0, utils_1.intersection)(exports.csvConfig.keyColumns, header);
    if (keyColumnsPresent.length === 0) {
        return utils_1.Either.Left("El CSV no contiene ninguna de las columnas necesarias para identificar estudiantes. \n - Columnas de identificaci\u00F3n: ".concat(exports.csvConfig.keyColumns, ". \n - Columnas del csv: ").concat(header));
    }
    var dataColumnsPresent = (0, utils_1.intersection)(exports.csvConfig.dataColumns, header);
    if (dataColumnsPresent.length === 0) {
        return utils_1.Either.Left("El CSV no contiene ninguna columna de datos relevante para el llenado. \n - Columnas de datos: ".concat(exports.csvConfig.dataColumns, ".\n - Columnas del csv: ").concat(header));
    }
    if (autofillData.length === 0) {
        return utils_1.Either.Left("El csv solo contiene un encabezado, y no contiene datos.\n - Encabezado: ".concat(header));
    }
    for (var _i = 0, _b = Object.entries(exports.csvConfig.values); _i < _b.length; _i++) {
        var _c = _b[_i], key = _c[0], values = _c[1];
        if (header.includes(key)) {
            var validValues = Object.keys(values);
            var valueCheck = checkValues(key, validValues, autofillData);
            if (valueCheck.isSome()) {
                var rowsWithErrors = valueCheck.get();
                return utils_1.Either.Left("La columna ".concat(key, " contiene valores inv\u00E1lidos.\n\n Valores v\u00E1lidos: ").concat(validValues, ".\n\n Filas con valores inv\u00E1lidos:\n\n").concat(printAutofillData(rowsWithErrors, header)));
            }
        }
    }
    return utils_1.Either.Right([autofillData, header]);
}
exports.csv2autofillData = csv2autofillData;
//# sourceMappingURL=csv_parser.js.map