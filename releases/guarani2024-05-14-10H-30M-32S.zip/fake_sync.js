// add sync/local map to chrome.storage to fake being in an extension
// Uses localStorage with JSON.stringify to simulate storing JS objects
// Therefore users should be careful since slight differences in behavior
// form chrome.storage may occur
var FakeStorage = /** @class */ (function () {
    function FakeStorage() {
    }
    FakeStorage.prototype.set = function (kv, callback) {
        // console.log(`Setting ${Object.entries(kv)}..`)
        for (var _i = 0, _a = Object.entries(kv); _i < _a.length; _i++) {
            var _b = _a[_i], k = _b[0], v = _b[1];
            // console.log(`Setting key ${k} to ${JSON.stringify(v)}`)
            localStorage.setItem(k, JSON.stringify(v));
        }
        callback();
    };
    FakeStorage.prototype.get = function (kv, callback) {
        // console.log(`Getting ${Object.entries(kv)}..`)
        var result = {};
        for (var _i = 0, _a = Object.entries(kv); _i < _a.length; _i++) {
            var _b = _a[_i], k = _b[0], v = _b[1];
            // console.log(`Found  ${k}:${v} in localStorage`)
            var item = JSON.parse(localStorage.getItem(k)) || v;
            result[k] = item;
        }
        // console.log(`Set ${Object.entries(result)}..`)
        callback(result);
    };
    return FakeStorage;
}());
// @ts-ignore
chrome.storage = { sync: new FakeStorage(), local: new FakeStorage() };
// @ts-ignore
chrome.runtime = { getURL: function (url) { return "/".concat(url); } };
//# sourceMappingURL=fake_sync.js.map